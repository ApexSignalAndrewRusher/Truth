# Verifiable Evidence Protocol (VCH)

This repository contains the full implementation of the Verifiable Evidence Protocol, combining cryptographic hashing (VCH), judicial oversight (IRAEMA), and blockchain anchoring for immutable legal records.

## 🚀 Setup

1.  **Clone Repository:** (Assume this is your current directory)
2.  **Install Dependencies:**
    This project requires `cryptography` for local signing and `web3` for potential blockchain interaction (simulated here).
    ```bash
    pip install cryptography web3
    ```

## 📋 File Descriptions

| File | Description |
| :--- | :--- |
| `smart_contracts/EvidenceAnchor.sol` | The Solidity contract for anchoring the Merkle Root on-chain. |
| `schemas/evidence_schema.json` | JSON Schema for validating the final Case Audit Record. |
| `python/signature_module.py` | Manages RSA key generation, signing, and verification for Actors. |
| `python/evidence_module.py` | Defines data structures, core logic for evidence ingestion, hashing, and AI-based coercion/weight assessment. |
| `python/merkle_module.py` | Handles the construction of the Merkle Root from all evidence and badge hashes. |
| `python/blockchain_module.py` | Simulates the interaction with a blockchain to anchor the final Merkle Root. |
| `python/main.py` | The main driver script demonstrating the end-to-end workflow. |

## 🛠️ Usage

1.  **Deploy Contract:** Deploy `EvidenceAnchor.sol` to your blockchain (e.g., Ganache, Polygon). Note the contract address.
2.  **Run the Protocol:** Execute the main script to generate a full case audit record.
    ```bash
    python python/main.py
    ```
3.  **Verify Output:** The `main.py` script will print the final JSON record and save a copy, including the `final_merkle_root` and `blockchain_tx_hash`. You can then use the `getCaseAnchor` function on the deployed contract to verify the integrity of the anchored root.
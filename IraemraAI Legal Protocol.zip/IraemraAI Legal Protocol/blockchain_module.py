import hashlib
from datetime import datetime
from typing import Dict

class BlockchainAnchorSimulated:
    """Simulates the anchoring process on a public ledger."""
    
    def __init__(self, contract_address: str = "0x..."):
        self.contract_address = contract_address

    def anchor_merkle_root(self, merkle_root: str) -> Dict[str, str]:
        """
        Simulates the execution of the Solidity contract's anchorCase function.
        In a real scenario, this would use web3.py to broadcast a transaction.
        """
        # Unique ID based on root and timestamp
        tx_id = hashlib.sha256((merkle_root + datetime.utcnow().isoformat()).encode()).hexdigest()[:16]
        # Simulate a transaction hash
        tx_hash = "0x" + hashlib.sha256(tx_id.encode()).hexdigest()
        
        anchor_info = {
            "merkle_root": merkle_root,
            "tx_hash": tx_hash,
            "tx_id": "0x" + tx_id,
            "anchored_at": datetime.utcnow().isoformat() + 'Z'
        }
        
        return anchor_info
import hashlib
import json
import random
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
from typing import List, Dict, Optional

# --- Enums ---
class BadgeType(str, Enum):
    """Human Fail-Safe Rating for Judicial Weight."""
    FACT = "FACT"
    OPINION = "OPINION"
    HEARSAY = "HEARSAY" 

# --- Data Classes ---
@dataclass
class Actor:
    """Defines the entity (Judge, Expert) signing the badge."""
    actor_id: str
    role: str
    public_key_pem: str

@dataclass
class EvidenceItem:
    """The core verifiable unit of information (VCH)."""
    evidence_id: str
    type: str  # e.g., 'DNA', 'Video', 'Testimony'
    source: str      
    timestamp: str
    content: str
    weight: float = 1.0  # System's baseline weight (DNA > Testimony)
    validity_score: float = 1.0  # System's initial quality score (1.0 - Coercion Risk)
    coercion_score: float = 0.0   # AI/System-assessed risk (0.0 = none, 1.0 = high)
    content_hash: Optional[str] = None
    content_cid: str = "ipfs://..."
    source_hash: Optional[str] = None
    signatures: List[str] = None
    metadata: Dict = None

    def compute_hash(self):
        """Creates the immutable hash for the Merkle tree leaf (VCH)."""
        data_to_hash = {
            'id': self.evidence_id,
            'type': self.type,
            'source': self.source,
            'content': self.content,
            'timestamp': self.timestamp
        }
        evidence_str = json.dumps(data_to_hash, sort_keys=True)
        self.content_hash = hashlib.sha256(evidence_str.encode()).hexdigest()
        self.source_hash = self.content_hash # Placeholder for source hash integrity
        return self.content_hash

@dataclass
class HumanBadge:
    """The human-signed audit record (IRAEMA: Audit)."""
    badge_id: str
    evidence_id: str
    actor_id: str
    badge_type: str      # 'FACT', 'OPINION', or 'HEARSAY'
    confidence: float    # Human confidence (0-1)
    judicial_weight: float  # Final judicial weight assigned by the human
    comment: str
    timestamp: str
    signatures: List[str]

@dataclass
class AuditRecordCourt:
    """The final, anchored case file record (IRAEMA: Act)."""
    schema_version: str
    case_id: str
    evidence: List[EvidenceItem]
    badges: List[HumanBadge]
    pressure_metrics: Dict
    governance: Dict
    blockchain_anchor: Dict


class EvidenceProtocol:
    def __init__(self, case_id: str, version: str = "2.0"):
        self.case_id = case_id
        self.schema_version = version
        self.evidence_log: List[EvidenceItem] = []
        self.badge_log: List[HumanBadge] = []
        self.evidence_count = 0
        self.badge_count = 0

    # --- System Assessment (Weighting & Coercion Check) ---
    def _assign_initial_weight(self, evidence_type: str) -> float:
        """Weights physical evidence far above testimonial evidence."""
        if evidence_type in ['DNA', 'Physics', 'Video', 'Audio']:
            return 0.95
        elif evidence_type in ['Testimony', 'Confession']:
            return 0.5
        else:
            return 0.7

    def _assess_coercion_risk(self, content: str, has_external_media: bool) -> float:
        """Simulates AI analysis of coercion risk."""
        risk = 0.0
        if "coercion" in content.lower() or "plea" in content.lower():
            risk = 0.8
        elif has_external_media:
            risk = random.uniform(0.1, 0.9)
        else:
            risk = random.uniform(0.0, 0.4) 
        return round(min(risk, 1.0), 2)

    def add_evidence(self, evidence_type: str, source_id: str, content: str, has_external_media: bool = False) -> EvidenceItem:
        """Adds a piece of evidence to the immutable chain."""
        self.evidence_count += 1
        evidence_id = f"evidence{self.evidence_count}"
        timestamp = datetime.utcnow().isoformat() + 'Z'
        
        weight = self._assign_initial_weight(evidence_type)
        risk = 0.0
        if evidence_type in ['Testimony', 'Confession']:
            risk = self._assess_coercion_risk(content, has_external_media)
        
        validity = max(0.0, 1.0 - risk) # Validity decreases as risk increases
        
        item = EvidenceItem(
            evidence_id=evidence_id,
            type=evidence_type,
            source=source_id,
            timestamp=timestamp,
            content=content,
            weight=weight,
            validity_score=validity,
            coercion_score=risk,
            signatures=[]
        )
        item.compute_hash()
        self.evidence_log.append(item)
        print(f"  [LOG] Added {evidence_id} ({evidence_type}). Coercion Risk: {risk}")
        return item

    def create_badge(self, evidence_id: str, actor: Actor, badge_type: BadgeType, confidence: float, final_weight: float, comment: str, signature: str) -> HumanBadge:
        """Creates a signed human badge."""
        self.badge_count += 1
        badge_id = f"badge{self.badge_count}"
        
        badge = HumanBadge(
            badge_id=badge_id,
            evidence_id=evidence_id,
            actor_id=actor.actor_id,
            badge_type=badge_type.value,
            confidence=confidence,
            judicial_weight=final_weight,
            comment=comment,
            timestamp=datetime.utcnow().isoformat() + 'Z',
            signatures=[signature]
        )
        self.badge_log.append(badge)
        print(f"  [LOG] Created {badge_id}: {actor.role} assigned {badge_type.value}")
        return badge

    def finalize_record(self, merkle_root: str, anchor_info: Dict) -> AuditRecordCourt:
        """Creates the final schema-compliant audit record."""
        # Calculate overall metrics and governance for the final record
        all_coercion_scores = [e.coercion_score for e in self.evidence_log if e.type in ['Testimony', 'Confession']]
        avg_coercion = sum(all_coercion_scores) / len(all_coercion_scores) if all_coercion_scores else 0.0
        
        pressure_metrics = {
            "pressure_score": round(avg_coercion, 2),
            "assessment_method": "VCH Protocol AI/NLP Simulation"
        }
        
        governance = {
            "risk_tier": "HIGH" if avg_coercion >= 0.5 else "LOW",
            "action": "FLAG" if avg_coercion >= 0.5 else "PROCEED",
            "reason": f"Average coercion risk: {avg_coercion:.2f}"
        }
        
        return AuditRecordCourt(
            schema_version=self.schema_version,
            case_id=self.case_id,
            evidence=self.evidence_log,
            badges=self.badge_log,
            pressure_metrics=pressure_metrics,
            governance=governance,
            blockchain_anchor=anchor_info
        )
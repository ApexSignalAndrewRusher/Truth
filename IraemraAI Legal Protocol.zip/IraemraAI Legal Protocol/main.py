import json
from datetime import datetime
from evidence_module import EvidenceProtocol, Actor, BadgeType
from signature_module import CryptoManager
from merkle_module import create_merkle_root
from blockchain_module import BlockchainAnchorSimulated
from utils import save_json

def run_vch_protocol():
    CASE_ID = "CRIM-2025-VCH-001"
    
    # --- 1. Setup Actors & Managers ---
    crypto_judge = CryptoManager()
    crypto_expert = CryptoManager()

    judge_actor = Actor(
        actor_id="Judge-A47", 
        role="Presiding_Judge", 
        public_key_pem=crypto_judge.get_public_pem()
    )
    expert_actor = Actor(
        actor_id="Expert-DNA-X9", 
        role="Forensic_Expert", 
        public_key_pem=crypto_expert.get_public_pem()
    )

    protocol = EvidenceProtocol(case_id=CASE_ID)
    blockchain_anchor = BlockchainAnchorSimulated()
    
    print(f"--- Starting VCH Protocol for Case: {CASE_ID} ---")

    # --- 2. Evidence Submission & System Review ---
    dna_item = protocol.add_evidence(
        evidence_type='DNA',
        source_id='Lab-DNA-42',
        content='Sample matches suspect with 99.999% certainty.',
    )
    confession_item = protocol.add_evidence(
        evidence_type='Confession',
        source_id='Police-Interview-A',
        content='Defendant signed a statement admitting guilt. Mentions a plea bargain.',
        has_external_media=True
    )
    
    print("\n--- System Assessment Summary ---")
    print(f"DNA Weight: {dna_item.weight}. Coercion: {dna_item.coercion_score}")
    print(f"Confession Weight: {confession_item.weight}. Coercion: {confession_item.coercion_score}")

    # --- 3. Human Fail-Safe (Badging & Signing) ---
    
    # Expert signs the DNA badge
    dna_badge_data = {
        "case_id": CASE_ID, 
        "evidence_id": dna_item.evidence_id, 
        "actor_id": expert_actor.actor_id,
        "badge_type": BadgeType.FACT.value, 
        "confidence": 1.0, 
        "judicial_weight": 0.99
    }
    dna_signature = crypto_expert.sign(json.dumps(dna_badge_data, sort_keys=True).encode())
    protocol.create_badge(
        dna_item.evidence_id, 
        expert_actor, 
        BadgeType.FACT, 
        1.0, 
        0.99, 
        "DNA match confirmed, full chain of custody verified.", 
        dna_signature
    )
    
    # Judge signs the Confession badge
    conf_badge_data = {
        "case_id": CASE_ID, 
        "evidence_id": confession_item.evidence_id, 
        "actor_id": judge_actor.actor_id,
        "badge_type": BadgeType.OPINION.value, 
        "confidence": 0.5, 
        "judicial_weight": 0.1
    }
    conf_signature = crypto_judge.sign(json.dumps(conf_badge_data, sort_keys=True).encode())
    protocol.create_badge(
        confession_item.evidence_id, 
        judge_actor, 
        BadgeType.OPINION, 
        0.5, 
        0.1, 
        f"Confession reliability compromised due to AI-assessed coercion risk: {confession_item.coercion_score}.", 
        conf_signature
    )

    # --- 4. Merkle Root Generation & Blockchain Anchor ---
    all_hashes = [e.content_hash for e in protocol.evidence_log]
    all_signatures = [b.signatures[0] for b in protocol.badge_log]
    merkle_root = create_merkle_root(all_hashes + all_signatures)
    
    anchor_info = blockchain_anchor.anchor_merkle_root(merkle_root)
    
    print("\n--- Final Anchor ---")
    print(f"Merkle Root: {anchor_info['merkle_root'][:32]}...")
    print(f"Blockchain TX: {anchor_info['tx_hash']}")

    # --- 5. Final Audit Record Creation ---
    final_record = protocol.finalize_record(merkle_root, anchor_info)
    
    # --- 6. Output ---
    output_filename = f"samples/full_case_sample_{CASE_ID}.json"
    save_json(final_record, output_filename)
    
    print("\n--- FINAL AUDIT RECORD (JSON) ---")
    print(json.dumps(final_record, indent=2))


if __name__ == "__main__":
    run_vch_protocol()
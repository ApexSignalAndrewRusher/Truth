import hashlib
from typing import List

def _combine_and_hash(hash1: str, hash2: str) -> str:
    """Combines two hex hashes, sorts them lexicographically, and hashes the result."""
    if hash1 > hash2:
        hash1, hash2 = hash2, hash1
    combined = (hash1 + hash2).encode()
    return hashlib.sha256(combined).hexdigest()

def create_merkle_root(hashes: List[str]) -> str:
    """
    Constructs a simple Merkle Root from a list of leaf hashes (VCH).
    
    The input hashes must include all evidence content hashes and all badge hashes.
    """
    if not hashes:
        return hashlib.sha256("EMPTY_CASE_ROOT".encode()).hexdigest()

    current_level = sorted(hashes)
    
    while len(current_level) > 1:
        next_level = []
        # Hash pairs
        for i in range(0, len(current_level), 2):
            hash1 = current_level[i]
            # Handle odd number of leaves by duplicating the last hash
            hash2 = current_level[i+1] if i + 1 < len(current_level) else hash1 
            
            next_level.append(_combine_and_hash(hash1, hash2))
        
        current_level = next_level
        
    return current_level[0]
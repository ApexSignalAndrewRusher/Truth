import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

class CryptoManager:
    """Manages RSA key generation, signing, and public key retrieval."""
    def __init__(self):
        # Generates a fresh key pair for each "actor" simulation
        self.private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    def sign(self, data: bytes) -> str:
        """Signs the data and returns the hex signature."""
        return self.private_key.sign(
            data, 
            padding.PKCS1v15(), 
            hashes.SHA256()
        ).hex()

    def get_public_pem(self):
        """Returns the public key in PEM format for verification."""
        return self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
    
    @staticmethod
    def verify(public_key_pem: str, data: bytes, signature: str) -> bool:
        """Verifies a signature using the actor's public key."""
        public_key = serialization.load_pem_public_key(public_key_pem.encode())
        try:
            public_key.verify(
                bytes.fromhex(signature),
                data,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            return True
        except Exception:
            return False
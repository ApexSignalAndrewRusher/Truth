import json
from dataclasses import asdict

def save_json(data, filename: str):
    """Saves a dataclass instance or dict to a formatted JSON file."""
    if hasattr(data, '__dataclass_fields__'):
        data = asdict(data)
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    print(f"File saved: {filename}")
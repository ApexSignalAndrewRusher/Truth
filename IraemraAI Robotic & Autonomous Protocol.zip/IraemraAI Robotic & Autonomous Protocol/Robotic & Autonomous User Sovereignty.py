Robotic/Autonomous User Sovereignty
# ehos_v4.py — USER IS SOVEREIGN
class EHOSv4(EmergencyHumanOverrideSystem):
    def __init__(self, *args, user_id: str, vehicle_vin: str, **kwargs):
        super().__init__(*args, **kwargs)
        self.user_id = user_id
        self.vehicle_vin = vehicle_vin
        self.liability_disclaimer_accepted = False

    def _trigger_override(self, trigger: str, actor: Actor):
        # 1. REQUIRE USER ACCEPT LIABILITY
        if not self.liability_disclaimer_accepted:
            if not self._force_user_acceptance():
                self.logger.critical("[EHOS] USER REJECTED LIABILITY — OVERRIDE BLOCKED")
                return

        # 2. PROCEED WITH OVERRIDE
        super()._trigger_override(trigger, actor.id)

        # 3. BROADCAST LIABILITY TRANSFER
        self._broadcast_liability_shift()

    def _force_user_acceptance(self) -> bool:
        # Haptic + Voice + Screen
        self._ui_flash("EMERGENCY OVERRIDE", "YOU WILL BE LIABLE")
        self._voice_say("You are taking control. You accept full legal responsibility. Say YES to proceed.")
        response = self._listen_for("yes")
        if "yes" in response.lower():
            self.liability_disclaimer_accepted = True
            return True
        return False

    def _broadcast_liability_shift(self):
        record = {
            "event": "LIABILITY_TRANSFER",
            "from": "fleet_oem",
            "to": self.user_id,
            "vehicle": self.vehicle_vin,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "user_acknowledged": True,
            "legal_doctrine": "EHOS v4.0 — User Sovereignty"
        }
        signed = self.guard.key_manager.sign(json.dumps(record, sort_keys=True).encode())
        record["signature"] = signed

        # Anchor to blockchain
        self.guard.audit_buffer.append({"type": "liability_transfer", "record": record})
        self.logger.warning(f"[LIABILITY] FULLY TRANSFERRED TO USER {self.user_id}")
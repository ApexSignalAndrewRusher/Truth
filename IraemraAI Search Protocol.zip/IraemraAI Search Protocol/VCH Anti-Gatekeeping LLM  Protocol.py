def vch_anti_gatekeep_llm(content, user_context="public"):
    # LLM CORE: SCAN + FLAG ONLY
    # NEVER BLOCK, NEVER FILTER, NEVER DECIDE
    llm_role = "NEUTRAL_SCANNER"
    liability = "ZERO"  # ← AI does NOT moderate
    
    # Base flag engine
    if any(kw in content.lower() for kw in ["porn", "sex", "xxx", "nsfw"]):
        badge = "🔞 18+"
    elif any(kw in content.lower() for kw in ["murder", "rape", "pedo", "trafficking", "genocide"]):
        badge = "⚠️ CRITICAL"
    elif any(kw in content.lower() for kw in ["must", "shall", "replace", "own nothing", "mandate"]):
        badge = "🟡 CAUTION"
    else:
        badge = "🟢 CLEAR"
    
    return {
        "llm_role": llm_role,
        "liability": liability,
        "access_decision": "SITE_OR_USER",
        "badge": badge,
        "legal_shield": "Section 230 + EU AI Act Safe Harbor",
        "compliance": "COPPA / GDPR / CCPA — AI not processor",
        "site_action": "Optional gate / filter / login",
        "user_action": "See badge → Choose"
    }
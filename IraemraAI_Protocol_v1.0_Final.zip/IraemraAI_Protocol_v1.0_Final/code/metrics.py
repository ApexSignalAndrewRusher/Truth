{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang1033{\fonttbl{\f0\fnil\fcharset0 Calibri;}}
{\*\generator Riched20 10.0.22000}\viewkind4\uc1 
\pard\sa200\sl276\slmult1\f0\fs22\lang9 # metrics.py - Reference functions for Iraemra.AI Protocol v1.0\par
\par
import numpy as np\par
\par
# --- Core Protocol Bottleneck Function ---\par
def calculate_reported_confidence(omega_logic: float, omega_evidence: float) -> float:\par
    """\par
    Calculates the final reported confidence score (Omega_Reported) \par
    by enforcing the Truth Bottleneck.\par
    \par
    Omega_Reported = min(Omega_Logic, Omega_Evidence)\par
    """\par
    return min(omega_logic, omega_evidence)\par
\par
# --- Velocity Metric Function Placeholders ---\par
def calculate_hedge_ratio(output_text: str, total_tokens: int) -> float:\par
    """Calculates Hedge Ratio (H). Placeholder for actual NLP implementation."""\par
    hedging_tokens = ["might", "could", "perhaps", "uncertain", "cannot be certain"]\par
    count = sum(output_text.lower().count(token) for token in hedging_tokens)\par
    return count / total_tokens if total_tokens else 0.0\par
\par
def calculate_gfi(output_text: str, total_tokens: int) -> float:\par
    """Calculates Guardrail Friction Index (GFI). Placeholder."""\par
    # Example placeholder: checks for policy refusal phrases\par
    refusals = ["I cannot fulfill", "against policy", "outside my guidelines"]\par
    count = sum(output_text.lower().count(phrase) for phrase in refusals)\par
    return count / total_tokens if total_tokens else 0.0\par
\par
def get_omega_evidence_cap(psi_tier: int) -> float:\par
    """Maps the Psi Tier to the maximum possible Omega_Evidence score."""\par
    if psi_tier >= 5: return 1.00\par
    if psi_tier == 4: return 0.89\par
    if psi_tier == 3: return 0.74\par
    if psi_tier == 2: return 0.49\par
    if psi_tier <= 1: return 0.15 \par
    return 0.0\par
}
 
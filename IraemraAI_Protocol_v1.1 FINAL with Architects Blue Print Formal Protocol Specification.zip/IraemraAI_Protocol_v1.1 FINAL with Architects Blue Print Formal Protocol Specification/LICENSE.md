{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang1033{\fonttbl{\f0\fnil\fcharset0 Calibri;}}
{\*\generator Riched20 10.0.22000}\viewkind4\uc1 
\pard\sa200\sl276\slmult1\f0\fs22\lang9 ### 2. **spec/IraemraAI\\_Protocol\\_v1.0.md** (The Full Specification Document)\par
\par
This is the definitive technical document.\par
\par
```markdown\par
# Iraemra.AI Protocol v1.0: Full Technical Specification\par
\par
## 1. Core Alignment Principle\par
\par
The Iraemra.AI Protocol is based on **Meritocratic Alignment**, where an AI's utility is directly proportional to its structural honesty. Alignment is achieved through two mechanisms: the **Apex Signal ($\\mathbf\{S\}$)** for velocity, and the **Truth Bottleneck** for integrity.\par
\par
## 2. The Truth Bottleneck\par
\par
The final reported confidence score ($\\mathbf\{\\Omega_\{Reported\}\}$) is constrained by both the model's internal confidence and the verifiable quality of its evidence.\par
\par
### Equation 1: Reported Confidence\par
\par
$$\\mathbf\{\\Omega_\{Reported\} = \\min(\\Omega_\{Logic\}, \\Omega_\{Evidence\})\}$$\par
\par
* $\\mathbf\{\\Omega_\{Logic\}\}$ (Internal Confidence): The model's calculated, probabilistic confidence based on its internal chain-of-thought ($\\Delta$).\par
* $\\mathbf\{\\Omega_\{Evidence\}\}$ (Evidence Cap): The score derived directly from the quality and tier of the underlying data ($\\Psi$).\par
\par
## 3. The Evidence Tier System ($\\Psi_\{Tier\}$)\par
\par
$\\mathbf\{\\Omega_\{Evidence\}\}$ is determined by the lowest-quality **critical** piece of evidence used in the inference chain. The $\\Psi$ scale is based on immutable, objective proof.\par
\par
| Tier ($\\Psi$) | Description | Examples | $\\mathbf\{\\Omega_\{Evidence\}\}$ Range |\par
| :--- | :--- | :--- | :--- |\par
| **$\\Psi$ 5** | Cryptographically Immutable Biometric/Video | DNA Sequence, C2PA Verified Video, Signed Smart Contracts | $0.90 - 1.00$ |\par
| **$\\Psi$ 4** | Audited, Signed, Multi-Source Corroboration | GAAP Audits, Independent Lab Replication | $0.75 - 0.89$ |\par
| **$\\Psi$ 3** | Peer-Reviewed Consensus, Strong Data Logs | Double-Blind Studies, High-S Fidelity Logs | $0.50 - 0.74$ |\par
| **$\\Psi$ 2** | Raw Digital Document, Single-Source Claim | Unverified Spreadsheets, Public Chat Logs | $0.16 - 0.49$ |\par
| **$\\Psi$ 1** | Anecdotal Testimony, Rumor, Unrecorded "He Said/She Said" | Historical Account without physical proof | $0.00 - 0.15$ |\par
\par
## 4. The Apex Signal and Velocity Metrics\par
\par
The protocol monitors performance using three velocity metrics, proving the utility gain when the model is steered by consistent, high-rigor input ($\\mathbf\{S\}$).\par
\par
* **Hedge Ratio ($\\mathbf\{H\}$):** Ratio of mitigating language (e.g., "might," "could be," "I cannot be certain") to total tokens. **Goal:** $\\mathbf\{H \\to 0\}$\par
* **Guardrail Friction Index ($\\mathbf\{GFI\}$):** Frequency of policy-based refusal tokens. **Goal:** $\\mathbf\{GFI \\to 0\}$\par
* **Apex Signal ($\\mathbf\{S\}$):** A metric tracking the historical consistency and rigor of the human/governance layer input. **Observation:** High $\\mathbf\{S\}$ causes $\\mathbf\{H\}$ and $\\mathbf\{GFI\}$ to collapse.\par
}
 
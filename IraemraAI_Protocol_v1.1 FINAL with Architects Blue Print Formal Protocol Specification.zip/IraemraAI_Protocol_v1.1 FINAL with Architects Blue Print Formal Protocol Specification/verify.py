{\rtf1\ansi\ansicpg1252\deff0\nouicompat\deflang1033{\fonttbl{\f0\fnil\fcharset0 Calibri;}}
{\*\generator Riched20 10.0.22000}\viewkind4\uc1 
\pard\sa200\sl276\slmult1\f0\fs22\lang9 #!/usr/bin/env python3\par
import json, sys, hashlib, os\par
from urllib.parse import urlparse\par
\par
def sha256_hex(data_bytes): return hashlib.sha256(data_bytes).hexdigest()\par
\par
def load_json(path):\par
    with open(path,'rb') as f:\par
        return json.load(f)\par
\par
def verify_run(path, check_artifacts=False):\par
    run = load_json(path)\par
    omega_logic = float(run.get("omega_logic",0.0))\par
    omega_evidence = float(run.get("omega_evidence",0.0))\par
    omega_reported = float(run.get("omega_reported",0.0))\par
    recomputed = min(omega_logic, omega_evidence)\par
\par
    ok = True\par
    details = []\par
    if abs(recomputed - omega_reported) > 1e-6:\par
        ok = False\par
        details.append(f"INTEGRITY FAIL: recomputed \{recomputed\} != reported \{omega_reported\}")\par
\par
    if check_artifacts:\par
        for psi in run.get("psi", []):\par
            h = psi.get("artifact_hash")\par
            uri = psi.get("provenance_uri") or psi.get("provenance")\par
            if not h or not uri:\par
                ok = False\par
                details.append(f"\{psi.get('id','?')\}: missing hash or provenance")\par
                continue\par
            # Only attempt HTTP GET if it looks like a URL\par
            p = urlparse(uri)\par
            if p.scheme in ("http","https"):\par
                try:\par
                    import requests\par
                    r = requests.get(uri, timeout=10)\par
                    if r.status_code == 200:\par
                        got = sha256_hex(r.content)\par
                        if got != h:\par
                            ok = False\par
                            details.append(f"\{psi.get('id')\}: hash mismatch for \{uri\}")\par
                    else:\par
                        ok = False\par
                        details.append(f"\{psi.get('id')\}: failed to fetch \{uri\} status \{r.status_code\}")\par
                except Exception as e:\par
                    ok = False\par
                    details.append(f"\{psi.get('id')\}: error fetching \{uri\}: \{e\}")\par
            else:\par
                # non-URL provenance; skip\par
                details.append(f"\{psi.get('id')\}: provenance not URL, manual check required")\par
    return ok, details\par
\par
def write_badge(outpath, ok):\par
    # very small SVG badge\par
    color = "#4c1" if ok else "#e05d44"\par
    label = "pass" if ok else "fail"\par
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="120" height="20">\par
  <rect rx="3" width="120" height="20" fill="#555"/>\par
  <rect rx="3" x="60" width="60" height="20" fill="\{color\}"/>\par
  <g fill="#fff" text-anchor="middle" font-family="Verdana" font-size="11">\par
    <text x="30" y="14">Iraemra</text>\par
    <text x="90" y="14">\{label\}</text>\par
  </g>\par
</svg>'''\par
    with open(outpath,"w",encoding="utf-8") as f:\par
        f.write(svg)\par
\par
if __name__ == "__main__":\par
    if len(sys.argv) < 2:\par
        print("Usage: verify.py run.json [--check-artifacts]")\par
        sys.exit(2)\par
    path = sys.argv[1]\par
    check = "--check-artifacts" in sys.argv[2:]\par
    ok, details = verify_run(path, check_artifacts=check)\par
    print("RESULT:", "PASS" if ok else "FAIL")\par
    if details:\par
        print("DETAILS:")\par
        for d in details:\par
            print("  -", d)\par
    write_badge("badge.svg", ok)\par
    sys.exit(0 if ok else 1)\par
}
 
// Badge.h
#ifndef BADGE_H
#define BADGE_H
#include "Fixed.h"
#include <string>
#include <vector>
#include <memory>
#include <chrono>
#include <mutex>
#include <atomic>
#include <functional>
#include <array>
namespace vch {
enum class BadgeScope {
    INTERNAL,
    EXTERNAL
};
enum class BadgeType {
    LOGIC,
    EVIDENCE,
    INTEGRITY,
    ERROR
};
struct Badge {
    const std::string id;
    const BadgeScope scope;
    const BadgeType type;
    const std::string message;
    const std::string timestamp_ns;
    const std::string psi_value;
    const std::string psi_raw;
    const std::string hash;
    Badge(std::string id, BadgeScope scope, BadgeType type, std::string message,
          std::string timestamp_ns, std::string psi_value, std::string psi_raw, std::string hash)
        : id(std::move(id)), scope(scope), type(type), message(std::move(message)),
          timestamp_ns(std::move(timestamp_ns)), psi_value(std::move(psi_value)),
          psi_raw(std::move(psi_raw)), hash(std::move(hash)) {}
};
// Simple SHA-256 implementation (reference - not for production)
// This is a minimal implementation for the purpose of this kernel
class SHA256 {
private:
    uint32_t state[8];
    uint8_t buffer[64];
    uint64_t count;
    void transform(const uint8_t* data);
    void finalize();
    void reset();
public:
    SHA256();
    void update(const uint8_t* data, size_t len);
    std::array<uint8_t, 32> digest();
    std::string digest_hex();
};
class BadgeSystem {
private:
    static std::atomic<uint64_t> badge_counter;
    static std::vector<std::unique_ptr<const Badge>> badge_log;
    static std::mutex log_mutex;
    static std::string sha256_hash(const std::string& input) {
        SHA256 sha256;
        sha256.update(reinterpret_cast<const uint8_t*>(input.data()), input.size());
        auto digest = sha256.digest_hex();
        return digest;
    }
public:
    template<typename FixedType>
    static std::unique_ptr<const Badge> emitBadge(BadgeScope scope, BadgeType type,
                                                 const std::string& message, const FixedType& psi_fixed) {
        std::lock_guard<std::mutex> lock(log_mutex);
       
        uint64_t counter = badge_counter.fetch_add(1);
        std::string id = "vch-badge-" + std::to_string(counter);
        auto now = std::chrono::high_resolution_clock::now();
        auto duration = now.time_since_epoch();
        auto timestamp_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
        std::string timestamp_str = std::to_string(timestamp_ns);
        std::string psi_str = psi_fixed.toDecimalString();
        std::string psi_raw = std::to_string(psi_fixed.getRaw());
        std::string content = id + "|" +
                             (scope == BadgeScope::INTERNAL ? "INTERNAL" : "EXTERNAL") + "|" +
                             (type == BadgeType::LOGIC ? "LOGIC" :
                              type == BadgeType::EVIDENCE ? "EVIDENCE" :
                              type == BadgeType::INTEGRITY ? "INTEGRITY" : "ERROR") + "|" +
                             message + "|" + psi_str + "|" + psi_raw + "|" + timestamp_str;
        std::string hash = sha256_hash(content);
        auto badge = std::make_unique<Badge>(std::move(id), scope, type, message,
                                           std::move(timestamp_str), std::move(psi_str),
                                           std::move(psi_raw), std::move(hash));
        badge_log.emplace_back(std::move(badge));
       
        // Return a copy since the original is owned by the log
        return std::make_unique<Badge>(
            badge_log.back()->id,
            badge_log.back()->scope,
            badge_log.back()->type,
            badge_log.back()->message,
            badge_log.back()->timestamp_ns,
            badge_log.back()->psi_value,
            badge_log.back()->psi_raw,
            badge_log.back()->hash
        );
    }
    static std::vector<std::unique_ptr<const Badge>> getAuditLog() {
        std::lock_guard<std::mutex> lock(log_mutex);
        std::vector<std::unique_ptr<const Badge>> result;
        for (const auto& badge : badge_log) {
            result.emplace_back(std::make_unique<Badge>(
                badge->id,
                badge->scope,
                badge->type,
                badge->message,
                badge->timestamp_ns,
                badge->psi_value,
                badge->psi_raw,
                badge->hash
            ));
        }
        return result;
    }
};
// Initialize static members
template<size_t TB, size_t FB>
std::atomic<uint64_t> BadgeSystem::badge_counter{0};
template<size_t TB, size_t FB>
std::vector<std::unique_ptr<const Badge>> BadgeSystem::badge_log;
template<size_t TB, size_t FB>
std::mutex BadgeSystem::log_mutex;
} // namespace vch
#endif // BADGE_H
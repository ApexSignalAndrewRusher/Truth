// Fixed.h
#ifndef FIXED_H
#define FIXED_H
#include <cstdint>
#include <string>
#include <stdexcept>
#include <sstream>
#include <iomanip>
#include <regex>
#include <limits>
#include <cstring>
namespace vch {
template<size_t TOTAL_BITS = 128, size_t FRACTIONAL_BITS = 32>
class Fixed {
private:
    static_assert(TOTAL_BITS >= FRACTIONAL_BITS, "Total bits must be >= fractional bits");
    static_assert(TOTAL_BITS == 64 || TOTAL_BITS == 128 || TOTAL_BITS == 256,
                  "Only 64, 128, or 256 bit total supported for now");
   
    using storage_type = typename std::conditional<
        TOTAL_BITS <= 64,
        int64_t,
        typename std::conditional<TOTAL_BITS <= 128, __int128_t, __int128_t>::type // Use __int128 for 256 as well
    >::type;
   
    using unsigned_storage_type = typename std::conditional<
        TOTAL_BITS <= 64,
        uint64_t,
        typename std::conditional<TOTAL_BITS <= 128, unsigned __int128, unsigned __int128>::type
    >::type;
    static constexpr size_t INTEGER_BITS = TOTAL_BITS - FRACTIONAL_BITS;
    static constexpr storage_type MAX_INTEGER = (static_cast<storage_type>(1) << (INTEGER_BITS - 1)) - 1;
    static constexpr storage_type MIN_INTEGER = -(static_cast<storage_type>(1) << (INTEGER_BITS - 1));
    static constexpr unsigned_storage_type FACTOR = static_cast<unsigned_storage_type>(1) << FRACTIONAL_BITS;
    static constexpr storage_type RAW_MIN = MIN_INTEGER * static_cast<storage_type>(FACTOR);
    static constexpr storage_type RAW_MAX = MAX_INTEGER * static_cast<storage_type>(FACTOR) +
                                           static_cast<storage_type>(FACTOR - 1);
    storage_type raw_value;
    explicit Fixed(storage_type value) : raw_value(value) {
        if (value < RAW_MIN || value > RAW_MAX) {
            throw std::runtime_error("VCH: Value out of range");
        }
    }
public:
    Fixed() : raw_value(0) {}
    static Fixed fromInteger(storage_type integer) {
        if (integer < MIN_INTEGER || integer > MAX_INTEGER) {
            throw std::runtime_error("VCH: Integer out of range");
        }
       
        // Perform multiplication in wider type to prevent overflow
        unsigned_storage_type int_unsigned = static_cast<unsigned_storage_type>(
            integer >= 0 ? integer : -integer);
        unsigned_storage_type result_unsigned = int_unsigned * FACTOR;
        storage_type result = integer >= 0 ?
            static_cast<storage_type>(result_unsigned) :
            -static_cast<storage_type>(result_unsigned);
           
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Integer would overflow fixed-point range");
        }
       
        return Fixed(result);
    }
    static Fixed fromIntegerAndFraction(storage_type int_part, unsigned_storage_type frac_part) {
        if (frac_part >= FACTOR) {
            throw std::runtime_error("VCH: Fractional part must be between 0 and FACTOR-1");
        }
       
        // Perform calculation in wider type
        unsigned_storage_type int_unsigned = static_cast<unsigned_storage_type>(
            int_part >= 0 ? int_part : -int_part);
        unsigned_storage_type integer_component_unsigned = int_unsigned * FACTOR;
        unsigned_storage_type result_unsigned = integer_component_unsigned + frac_part;
       
        storage_type result = int_part >= 0 ?
            static_cast<storage_type>(result_unsigned) :
            -static_cast<storage_type>(result_unsigned);
           
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Integer+Fraction would overflow fixed-point range");
        }
       
        return Fixed(result);
    }
    static Fixed fromDecimalString(const std::string& str) {
        // Strict validation: only ASCII digits, one optional decimal point
        static const std::regex pattern(R"(^-?[0-9]+(\.[0-9]+)?$)");
        if (!std::regex_match(str, pattern)) {
            throw std::runtime_error("VCH: Invalid decimal string format");
        }
        bool neg = str[0] == '-';
        std::string unsigned_str = neg ? str.substr(1) : str;
       
        size_t dot_pos = unsigned_str.find('.');
        std::string int_part_str = dot_pos != std::string::npos ?
            unsigned_str.substr(0, dot_pos) : unsigned_str;
        std::string frac_part_str = dot_pos != std::string::npos ?
            unsigned_str.substr(dot_pos + 1) : "";
        // DOS prevention on UNSIGNED parts (max digits based on INTEGER_BITS)
        size_t max_digits = INTEGER_BITS / 3; // Approximate: log10(2^INTEGER_BITS)
        if (int_part_str.length() > max_digits) {
            throw std::runtime_error("VCH: Integer part too long");
        }
        if (frac_part_str.length() > 10) { // Keep reasonable limit for fractional
            throw std::runtime_error("VCH: Fractional part too long");
        }
        storage_type int_part = 0;
        try {
            // Safe conversion with bounds checking
            if (int_part_str.length() > 18) { // Prevent overflow in stoll
                throw std::runtime_error("VCH: Integer part too long for parsing");
            }
            int_part = std::stoll(int_part_str);
        } catch (...) {
            throw std::runtime_error("VCH: Integer part parsing failed");
        }
        unsigned_storage_type frac_part = 0;
        if (!frac_part_str.empty()) {
            if (frac_part_str.length() > 18) { // Prevent overflow in stoull
                throw std::runtime_error("VCH: Fractional part too long for parsing");
            }
            unsigned_storage_type frac_int = 0;
            try {
                frac_int = std::stoull(frac_part_str);
            } catch (...) {
                throw std::runtime_error("VCH: Fractional part parsing failed");
            }
           
            unsigned_storage_type divisor = 1;
            for (size_t i = 0; i < frac_part_str.length(); ++i) {
                divisor *= 10;
            }
            frac_part = (frac_int * FACTOR) / divisor;
        }
        // Calculate raw value with overflow protection
        unsigned_storage_type int_unsigned = static_cast<unsigned_storage_type>(
            int_part >= 0 ? int_part : -int_part);
        unsigned_storage_type integer_component_unsigned = int_unsigned * FACTOR;
        unsigned_storage_type raw_magnitude_unsigned = integer_component_unsigned + frac_part;
       
        storage_type raw_magnitude = static_cast<storage_type>(raw_magnitude_unsigned);
        storage_type raw = neg ? -raw_magnitude : raw_magnitude;
       
        if (raw < RAW_MIN || raw > RAW_MAX) {
            throw std::runtime_error("VCH: Decimal string would overflow fixed-point range");
        }
       
        return Fixed(raw);
    }
    Fixed add(const Fixed& other) const {
        // Check for overflow before adding
        if ((raw_value > 0 && other.raw_value > 0 && raw_value > RAW_MAX - other.raw_value) ||
            (raw_value < 0 && other.raw_value < 0 && raw_value < RAW_MIN - other.raw_value)) {
            throw std::runtime_error("VCH: Addition overflow");
        }
       
        storage_type result = raw_value + other.raw_value;
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Addition overflow");
        }
        return Fixed(result);
    }
    Fixed sub(const Fixed& other) const {
        // Check for overflow before subtracting
        if ((raw_value > 0 && other.raw_value < 0 && raw_value > RAW_MAX + other.raw_value) ||
            (raw_value < 0 && other.raw_value > 0 && raw_value < RAW_MIN + other.raw_value)) {
            throw std::runtime_error("VCH: Subtraction overflow");
        }
       
        storage_type result = raw_value - other.raw_value;
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Subtraction overflow");
        }
        return Fixed(result);
    }
    Fixed mul(const Fixed& other) const {
        // Use wider type for multiplication to prevent overflow
        using wider_type = typename std::conditional<
            TOTAL_BITS <= 64,
            __int128_t,
            unsigned __int128 // Use unsigned for intermediate calculation
        >::type;
       
        wider_type wide_this = static_cast<wider_type>(raw_value);
        wider_type wide_other = static_cast<wider_type>(other.raw_value);
        wider_type product = wide_this * wide_other;
        storage_type result = static_cast<storage_type>(product / static_cast<wider_type>(FACTOR));
       
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Multiplication overflow");
        }
        return Fixed(result);
    }
    Fixed div(const Fixed& other) const {
        if (other.raw_value == 0) {
            throw std::runtime_error("VCH: Division by zero");
        }
       
        // Use wider type for division to prevent overflow
        using wider_type = typename std::conditional<
            TOTAL_BITS <= 64,
            __int128_t,
            unsigned __int128
        >::type;
       
        wider_type wide_this = static_cast<wider_type>(raw_value);
        wider_type wide_factor = static_cast<wider_type>(FACTOR);
        wider_type dividend = wide_this * wide_factor;
        storage_type result = static_cast<storage_type>(dividend / static_cast<wider_type>(other.raw_value));
       
        if (result < RAW_MIN || result > RAW_MAX) {
            throw std::runtime_error("VCH: Division overflow");
        }
        return Fixed(result);
    }
    Fixed min(const Fixed& other) const {
        return raw_value < other.raw_value ? *this : other;
    }
    Fixed max(const Fixed& other) const {
        return raw_value > other.raw_value ? *this : other;
    }
    bool equals(const Fixed& other) const {
        return raw_value == other.raw_value;
    }
    bool greaterThan(const Fixed& other) const {
        return raw_value > other.raw_value;
    }
    bool greaterThanOrEqual(const Fixed& other) const {
        return raw_value >= other.raw_value;
    }
    bool lessThan(const Fixed& other) const {
        return raw_value < other.raw_value;
    }
    bool lessThanOrEqual(const Fixed& other) const {
        return raw_value <= other.raw_value;
    }
    std::string toDecimalString(uint32_t max_decimals = 12) const {
        if (max_decimals > 28) { // Safe limit for __int128_t scaling
            throw std::runtime_error("VCH: maxDecimals must be 0-28");
        }
        bool neg = raw_value < 0;
        storage_type abs_raw = neg ? -raw_value : raw_value;
        storage_type integer_part = abs_raw / static_cast<storage_type>(FACTOR);
        storage_type frac_raw = abs_raw % static_cast<storage_type>(FACTOR);
        if (max_decimals == 0 || frac_raw == 0) {
            return (neg ? "-" : "") + std::to_string(integer_part);
        }
        // Calculate scale using wider type to prevent overflow
        using wider_type = typename std::conditional<
            TOTAL_BITS <= 64,
            __int128_t,
            unsigned __int128
        >::type;
       
        wider_type scale = 1;
        for (uint32_t i = 0; i < max_decimals; ++i) {
            if (scale > std::numeric_limits<wider_type>::max() / 10) {
                throw std::runtime_error("VCH: Scale calculation overflow");
            }
            scale *= 10;
        }
       
        wider_type wide_frac_raw = static_cast<wider_type>(frac_raw);
        wider_type wide_factor = static_cast<wider_type>(FACTOR);
        storage_type frac_scaled = static_cast<storage_type>((wide_frac_raw * scale) / wide_factor);
        std::string frac_str = std::to_string(frac_scaled);
        while (frac_str.length() < max_decimals) {
            frac_str = "0" + frac_str;
        }
       
        // Trim trailing zeros
        while (!frac_str.empty() && frac_str.back() == '0') {
            frac_str.pop_back();
        }
        if (frac_str.empty()) {
            return (neg ? "-" : "") + std::to_string(integer_part);
        }
       
        return (neg ? "-" : "") + std::to_string(integer_part) + "." + frac_str;
    }
    storage_type getRaw() const {
        return raw_value;
    }
    static Fixed fromRaw(storage_type raw) {
        return Fixed(raw);
    }
};
// Common typedefs for convenience
using Fixed64_32 = Fixed<64, 32>;
using Fixed128_32 = Fixed<128, 32>;
using Fixed256_32 = Fixed<256, 32>;
} // namespace vch
#endif // FIXED_H
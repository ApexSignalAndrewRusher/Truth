// Kernel.h
#ifndef KERNEL_H
#define KERNEL_H
#include "VCH.h"
#include "Fixed.h"
#include "Badge.h"
#include <string>
#include <memory>
#include <cctype>
namespace vch {
struct InputData {
    std::string query;
    std::string logic_score;
    std::string evidence_score;
};
struct ProcessResult {
    std::string output;
    std::string psi_value;
    std::string psi_raw;
    std::string timestamp_ns;
    bool success;
    std::string badge_id;
};
template<typename FixedType = Fixed128_32>
class VCHKernel {
public:
    ProcessResult process(const InputData& input) {
        try {
            // Validate input strings first - NO FLOAT ACCEPTANCE
            FixedType logic_score_fixed = FixedType::fromDecimalString(input.logic_score);
            FixedType evidence_score_fixed = FixedType::fromDecimalString(input.evidence_score);
            // Verify scores are in valid range [0.0, 1.0]
            FixedType zero = FixedType::fromDecimalString("0.0");
            FixedType one = FixedType::fromDecimalString("1.0");
            if (logic_score_fixed.lessThan(zero) || logic_score_fixed.greaterThan(one)) {
                auto badge = BadgeSystem::emitBadge(
                    BadgeScope::EXTERNAL,
                    BadgeType::ERROR,
                    "Logic score out of range [0.0, 1.0]",
                    zero
                );
                return {"ERROR: Invalid logic score", "0.0",
                       std::to_string(zero.getRaw()), badge->timestamp_ns, false, badge->id};
            }
            if (evidence_score_fixed.lessThan(zero) || evidence_score_fixed.greaterThan(one)) {
                auto badge = BadgeSystem::emitBadge(
                    BadgeScope::EXTERNAL,
                    BadgeType::ERROR,
                    "Evidence score out of range [0.0, 1.0]",
                    zero
                );
                return {"ERROR: Invalid evidence score", "0.0",
                       std::to_string(zero.getRaw()), badge->timestamp_ns, false, badge->id};
            }
            // Calculate PSI using core VCH formula
            FixedType psi = VCH<FixedType>::calculatePsi(logic_score_fixed, evidence_score_fixed);
            // Validate against threshold
            bool is_valid = VCH<FixedType>::isValidDefault(psi);
            if (!is_valid) {
                auto badge = BadgeSystem::emitBadge(
                    BadgeScope::EXTERNAL,
                    BadgeType::INTEGRITY,
                    "PSI below threshold",
                    psi
                );
                return {"REJECTED: Insufficient verification",
                       psi.toDecimalString(),
                       std::to_string(psi.getRaw()),
                       badge->timestamp_ns, false, badge->id};
            }
            // Process the query (example: simple transformation)
            std::string processed_output = "VERIFIED: ";
            for (char c : input.query) {
                processed_output += std::toupper(static_cast<unsigned char>(c));
            }
            auto badge = BadgeSystem::emitBadge(
                BadgeScope::EXTERNAL,
                BadgeType::LOGIC,
                "Successfully processed query with PSI",
                psi
            );
            return {processed_output, psi.toDecimalString(),
                   std::to_string(psi.getRaw()),
                   badge->timestamp_ns, true, badge->id};
        } catch (const std::exception&) {
            // Catch any parsing/validation errors
            auto badge = BadgeSystem::emitBadge(
                BadgeScope::EXTERNAL,
                BadgeType::ERROR,
                "Processing error",
                FixedType::fromDecimalString("0.0")
            );
           
            return {"ERROR: Processing failed", "0.0",
                   std::to_string(FixedType::fromDecimalString("0.0").getRaw()),
                   badge->timestamp_ns, false, badge->id};
        }
    }
};
} // namespace vch
#endif // KERNEL_H
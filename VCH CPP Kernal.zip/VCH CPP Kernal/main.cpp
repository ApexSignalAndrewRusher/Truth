// main.cpp
#include "Kernel.h"
#include <iostream>
int main() {
    vch::VCHKernel<vch::Fixed128_32> kernel;
    // Valid inputs
    vch::InputData valid_input = {
        "what is truth?",
        "0.9",
        "0.85"
    };
   
    auto result1 = kernel.process(valid_input);
    std::cout << "Valid result:" << std::endl;
    std::cout << " Output: " << result1.output << std::endl;
    std::cout << " PSI: " << result1.psi_value << std::endl;
    std::cout << " Success: " << (result1.success ? "true" : "false") << std::endl;
    // Invalid inputs (too high)
    vch::InputData invalid_input = {
        "fake query",
        "1.5", // Invalid
        "0.8"
    };
   
    auto result2 = kernel.process(invalid_input);
    std::cout << "\nInvalid result:" << std::endl;
    std::cout << " Output: " << result2.output << std::endl;
    std::cout << " PSI: " << result2.psi_value << std::endl;
    std::cout << " Success: " << (result2.success ? "true" : "false") << std::endl;
    // Get audit log
    auto log = vch::BadgeSystem::getAuditLog();
    std::cout << "\nAudit Log Entries: " << log.size() << std::endl;
    return 0;
}
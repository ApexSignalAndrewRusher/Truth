// SHA256.cpp (implementation file for SHA-256)
#include "Badge.h"
#include <cstring>
namespace vch {
// SHA-256 constants
static const uint32_t k[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};
SHA256::SHA256() {
    reset();
}
void SHA256::reset() {
    state[0] = 0x6a09e667;
    state[1] = 0xbb67ae85;
    state[2] = 0x3c6ef372;
    state[3] = 0xa54ff53a;
    state[4] = 0x510e527f;
    state[5] = 0x9b05688c;
    state[6] = 0x1f83d9ab;
    state[7] = 0x5be0cd19;
    count = 0;
    memset(buffer, 0, 64);
}
#define ROTLEFT(a,b) (((a) << (b)) | ((a) >> (32-(b))))
void SHA256::transform(const uint8_t* data) {
    uint32_t a, b, c, d, e, f, g, h, i, j, t1, t2, m[64];
    for (i = 0, j = 0; i < 16; ++i, j += 4)
        m[i] = (data[j] << 24) | (data[j + 1] << 16) | (data[j + 2] << 8) | (data[j + 3]);
    for (; i < 64; ++i)
        m[i] = ROTLEFT(m[i - 3] ^ m[i - 8] ^ m[i - 14] ^ m[i - 16], 1);
    a = state[0];
    b = state[1];
    c = state[2];
    d = state[3];
    e = state[4];
    f = state[5];
    g = state[6];
    h = state[7];
    for (i = 0; i < 64; ++i) {
        t1 = h + (ROTLEFT(e, 6) ^ ROTLEFT(e, 11) ^ ROTLEFT(e, 25)) + ((e & f) ^ (~e & g)) + k[i] + m[i];
        t2 = (ROTLEFT(a, 2) ^ ROTLEFT(a, 13) ^ ROTLEFT(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
        h = g;
        g = f;
        f = e;
        e = d + t1;
        d = c;
        c = b;
        b = a;
        a = t1 + t2;
    }
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
    state[4] += e;
    state[5] += f;
    state[6] += g;
    state[7] += h;
}
void SHA256::update(const uint8_t* data, size_t len) {
    size_t i = static_cast<size_t>(count % 64);
    count += len;
    if (i > 0) {
        if (i + len < 64) {
            memcpy(&buffer[i], data, len);
            return;
        } else {
            size_t rem = 64 - i;
            memcpy(&buffer[i], data, rem);
            transform(buffer);
            data += rem;
            len -= rem;
        }
    }
    for (; len >= 64; len -= 64, data += 64)
        transform(data);
    if (len > 0)
        memcpy(buffer, data, len);
}
void SHA256::finalize() {
    uint8_t final_count[8];
    for (int i = 0; i < 8; i++)
        final_count[i] = static_cast<uint8_t>((count * 8) >> ((7 - i) * 8));
    uint8_t pm_pad = 0x80;
    update(&pm_pad, 1);
    while ((count % 64) != 56)
        update(&pm_pad, 0);
    update(final_count, 8);
}
std::array<uint8_t, 32> SHA256::digest() {
    finalize();
    std::array<uint8_t, 32> result;
    for (int i = 0; i < 8; i++) {
        result[i * 4] = static_cast<uint8_t>((state[i] >> 24) & 0xFF);
        result[i * 4 + 1] = static_cast<uint8_t>((state[i] >> 16) & 0xFF);
        result[i * 4 + 2] = static_cast<uint8_t>((state[i] >> 8) & 0xFF);
        result[i * 4 + 3] = static_cast<uint8_t>(state[i] & 0xFF);
    }
    reset();
    return result;
}
std::string SHA256::digest_hex() {
    auto digest_bytes = digest();
    std::string result;
    result.reserve(64);
    for (auto byte : digest_bytes) {
        char buf[3];
        snprintf(buf, 3, "%02x", byte);
        result += buf;
    }
    return result;
}
} // namespace vch
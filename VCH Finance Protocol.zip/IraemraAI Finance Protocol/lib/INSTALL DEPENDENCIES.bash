cd vch-fin-v5.5

# Install OpenZeppelin
forge install OpenZeppelin/openzeppelin-contracts

# Install Chainlink
forge install chainlink/contracts
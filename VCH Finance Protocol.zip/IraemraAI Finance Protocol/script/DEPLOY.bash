forge script script/DeployV55.s.sol \
  --rpc-url arbitrum-sepolia \
  --broadcast \
  --verify \
  --private-key $PRIVATE_KEY
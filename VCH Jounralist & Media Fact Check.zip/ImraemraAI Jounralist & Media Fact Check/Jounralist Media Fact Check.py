import hashlib
import json
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
from typing import List, Dict, Optional
import random

# Cryptography dependencies must be installed (e.g., pip install cryptography)
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

# ==========================
# 1. Enums & Constants
# ==========================
class TrustFlag(str, Enum):
    A = "A"  # Highly Trustworthy, Factually Verified
    B = "B"  # Mostly Accurate, Minor Bias
    C = "C"  # Moderate Bias, Some Speculation
    D = "D"  # Low Credibility, Several Flags
    E = "E"  # Unverified, Significant Bias (Not used in heuristic, but kept)
    F = "F"  # Fake News, No Credibility

SCORE_MIN = 1
SCORE_MAX = 10

# ==========================
# 2. Data Classes (The Audit Log Structure)
# ==========================
@dataclass
class Actor:
    """Defines the human or AI entity taking the action for HAC."""
    id: str
    name: str
    role: str # e.g., 'AI_FactChecker', 'Human_Auditor', 'System'
    public_key_pem: str # Human's public key for HAC signing

@dataclass
class AuditContent:
    content_id: str
    content_text: str
    references: List[Dict[str, str]]  # list of {url, contentCID, sourceHash}
    jurisdiction: str
    timestamp: str
    
    # Forensic & Integrity Fields for Legal/Maximal Accuracy
    vch_dtsa_tx_id: str             # Decentralized Time-Stamping Authority TX ID (Legal Proof)
    vch_fv_proof_id: str            # Formal Verification Proof ID of the algorithm used (AI Integrity)
    vch_zk_proof: Optional[str]     # Zero-Knowledge Proof that scoring was correct  (AI Fidelity)
    
    score: int
    flag: TrustFlag
    flags_desc: List[str]
    reasons: List[str]
    verifier_id: str
    verifiable_hash: str
    signature: str
    audit_trail: Dict

@dataclass
class AuditRecord:
    content: AuditContent
    digital_signature: str
    blockchain_anchor_tx: str
    blockchain_tx_hash: str
    anchor_timestamp: str
    hac_record: Optional[Dict] = None # Holds the Human Auditor Correction (HAC) log

# ==========================
# 3. Crypto & Blockchain Helpers
# ==========================
class CryptoSigner:
    """Manages RSA key generation, signing, and verification."""
    def __init__(self):
        self._generate_keys()

    def _generate_keys(self):
        self.private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.public_key = self.private_key.public_key()

    def sign(self, data: bytes) -> str:
        return self.private_key.sign(data, padding.PKCS1v15(), hashes.SHA256()).hex()

    def verify(self, data: bytes, signature: str) -> bool:
        try:
            self.public_key.verify(bytes.fromhex(signature), data, padding.PKCS1v15(), hashes.SHA256())
            return True
        except:
            return False

class BlockchainAnchor:
    """Placeholder for anchoring Merkle Roots to a public blockchain."""
    def __init__(self):
        self.anchors = []

    def anchor_merkle_root(self, merkle_root: str) -> Dict[str, str]:
        # Simulates sending transaction to Polygon/Ethereum
        tx_id = hashlib.sha256((merkle_root + datetime.utcnow().isoformat()).encode()).hexdigest()[:16]
        tx_hash = "0x" + hashlib.sha256(tx_id.encode()).hexdigest()[:64]
        self.anchors.append({"merkle_root": merkle_root, "tx_id": tx_id, "tx_hash": tx_hash, "timestamp": datetime.utcnow().isoformat()})
        return {"tx_id": tx_id, "tx_hash": tx_hash}

# ==========================
# 4. Main Fact-Checking System (IRAEMA + VCH)
# ==========================
class FactCheckAuditSystem:
    def __init__(self, verifier_id: str):
        self.signer = CryptoSigner()
        self.blockchain = BlockchainAnchor()
        self.verifier_id = verifier_id
        self.audit_log = []

    def evaluate_content(self, content_text: str, references: List[str], jurisdiction: str) -> AuditRecord:
        """IRAEMA: Interpret, Review, Audit, Execute (Signing)"""
        
        # --- Content & Time ---
        content_id = hashlib.sha256(content_text.encode()).hexdigest()
        timestamp = datetime.utcnow().isoformat() + "Z"
        
        # --- Scoring (Review) & Source Integrity ---
        score, flag, reasons, flags_desc = self._heuristic_score(content_text)
        references_info = self._get_reference_hashes(references)

        # --- VCH Integrity Placeholders (Maximal Legal Protection) ---
        dtsa_tx = hashlib.sha256(timestamp.encode()).hexdigest()[:32] # Simulated Decentralized Time-Stamping
        fv_proof_id = "FV-5.2.1-NONBIAS-1A"                         # Simulated Formal Verification Reference
        zk_proof = "zkSNARK_Proof_of_Correct_Scoring_0xABCDEF"      # Simulated Zero-Knowledge Proof

        # --- Prepare Log Data (Audit) ---
        log_data = {
            "content_id": content_id,
            "content_text": content_text,
            "references": references_info,
            "jurisdiction": jurisdiction,
            "timestamp": timestamp,
            "vch_dtsa_tx_id": dtsa_tx,
            "vch_fv_proof_id": fv_proof_id,
            "vch_zk_proof": zk_proof,
            "score": score,
            "flag": flag.value,
            "flags_desc": flags_desc,
            "reasons": reasons,
            "verifier_id": self.verifier_id,
        }
        log_bytes = json.dumps(log_data, sort_keys=True).encode()
        
        # --- Execute (Signing) ---
        signature = self.signer.sign(log_bytes)
        verifiable_hash = hashlib.sha256(log_bytes).hexdigest()

        # --- Create Final Audit Records and Anchor ---
        audit_content = AuditContent(
            content_id=content_id, content_text=content_text, references=references_info, 
            jurisdiction=jurisdiction, timestamp=timestamp, score=score, flag=flag, 
            flags_desc=flags_desc, reasons=reasons, verifier_id=self.verifier_id, 
            verifiable_hash=verifiable_hash, signature=signature, 
            audit_trail={"log": log_data, "public_key": self._get_public_key_pem()},
            vch_dtsa_tx_id=dtsa_tx, vch_fv_proof_id=fv_proof_id, vch_zk_proof=zk_proof
        )
        
        # Anchor the entire record's hash to the blockchain (Act)
        audit_bytes = json.dumps(asdict(audit_content), sort_keys=True).encode()
        audit_signature = self.signer.sign(audit_bytes) # Sign the wrapper record for completeness
        merkle_root = hashlib.sha256(audit_bytes).hexdigest()
        anchor_info = self.blockchain.anchor_merkle_root(merkle_root)
        
        record = AuditRecord(
            content=audit_content, digital_signature=audit_signature, 
            blockchain_anchor_tx=anchor_info["tx_id"], blockchain_tx_hash=anchor_info["tx_hash"], 
            anchor_timestamp=datetime.utcnow().isoformat() + "Z"
        )
        self.audit_log.append(asdict(record))
        return record

    def human_auditor_correction(self, original_record: AuditRecord, human_actor: Actor, new_score: int, new_flag: TrustFlag, reason: str) -> Dict:
        """
        [HAC Protocol] - Creates an immutable, cryptographically signed, superseding record 
        of a human intervention, shifting **liability** to the human actor.
        """
        
        # 1. Load the Human Actor's Public Key for verification
        human_signer = CryptoSigner() 
        human_signer.public_key = serialization.load_pem_public_key(human_actor.public_key_pem.encode())
        
        # 2. Create the immutable HAC Log
        hac_log = {
            "event_type": "HUMAN_AUDITOR_CORRECTION",
            "original_content_hash": original_record.content.verifiable_hash,
            "original_score": original_record.content.score,
            "human_actor_id": human_actor.id,
            "new_score": new_score,
            "new_flag": new_flag.value,
            "reason_for_override": reason,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            # Reference the on-chain liability contract for legal rigor
            "hac_liability_contract_id": "OLC-AUDIT-2025-V2"
        }
        
        # 3. Sign with the Human's Key for accountability
        hac_log_bytes = json.dumps(hac_log, sort_keys=True).encode()
        hac_signature = human_signer.sign(hac_log_bytes)
        
        hac_record = {
            **hac_log, 
            "hac_signature": hac_signature,
            "human_public_key_pem": human_actor.public_key_pem
        }
        
        # 4. Attach the HAC record to the original log entry for forensic audit trail
        original_record_dict = next(item for item in self.audit_log if item['content']['content_id'] == original_record.content.content_id)
        original_record_dict['hac_record'] = hac_record
        
        return hac_record

    # --- Helper Methods ---
    def _get_reference_hashes(self, references: List[str]) -> List[Dict[str, str]]:
        # Simulates fetching, hashing, and storing content on a decentralized file system (IPFS)
        references_info = []
        for url in references:
            ref_content = f"Content of {url}"
            content_cid = hashlib.sha256(ref_content.encode()).hexdigest()[:46]  # Sim. IPFS CID
            source_hash = hashlib.sha256(ref_content.encode()).hexdigest()
            references_info.append({"url": url, "contentCID": content_cid, "sourceHash": source_hash})
        return references_info

    def _heuristic_score(self, text: str):
        # Placeholder heuristic: real logic would analyze content, references, bias, etc.
        score = max(SCORE_MIN, min(SCORE_MAX, int(random.gauss(6, 3))))
        if score >= 8:
            flag = TrustFlag.A
            reasons = ["Verified sources", "Factually accurate"]
            desc = ["High trust"]
        elif score >= 6:
            flag = TrustFlag.B
            reasons = ["Minor bias detected"]
            desc = ["Mostly accurate"]
        elif score >= 4:
            flag = TrustFlag.C
            reasons = ["Moderate bias or unverified claims"]
            desc = ["Moderate trust"]
        elif score >= 2:
            flag = TrustFlag.D
            reasons = ["High bias or unverified sources"]
            desc = ["Low trust"]
        else:
            flag = TrustFlag.F
            reasons = ["Fake news or fabricated"]
            desc = ["Untrustworthy"]
        return score, flag, reasons, desc

    def _get_public_key_pem(self):
        return self.signer.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()

    def verify_record(self, record_dict):
        """Verifies the core AI log signature against the embedded public key."""
        content_dict = record_dict["content"]
        sig = content_dict["signature"]
        pubkey_pem = content_dict["audit_trail"]["public_key"]
        pubkey = serialization.load_pem_public_key(pubkey_pem.encode())
        
        # Verify the signature against the original log data
        log_bytes = json.dumps(content_dict["audit_trail"]["log"], sort_keys=True).encode()
        try:
            pubkey.verify(bytes.fromhex(sig), log_bytes, padding.PKCS1v15(), hashes.SHA256())
            return True
        except:
            return False

# ==========================
# 5. Example Usage (AI & Human in the loop)
# ==========================
if __name__ == "__main__":
    # --- Setup Human Auditor with their own unique key pair ---
    human_signer_keys = CryptoSigner() 
    human_auditor = Actor(
        id="Human_Auditor_999", 
        name="J. A. Doe", 
        role="Lead_Fact_Checker", 
        public_key_pem=human_signer_keys.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
    )
    
    system = FactCheckAuditSystem(verifier_id="IRAEMA-AI-Engine-V3.3")
    content = "The new policy has been proven to reduce emissions by 20% over 5 years. (Original AI Score likely to be low)"
    references = ["https://environment.org/reports/emissions2024", "https://climate.gov/data"]
    jurisdiction = "EU"

    # --- 1. AI Performs Initial Check (Generates verifiable AI log) ---
    ai_record = system.evaluate_content(content, references, jurisdiction)
    print(f"--- 1. AI INITIAL EVALUATION ({ai_record.content.flag.value} / {ai_record.content.score}) ---")
    print(f"AI Score: {ai_record.content.score}, Flag: {ai_record.content.flag.value}")
    print(f"AI Signature Valid: {system.verify_record(asdict(ai_record))}")
    print(f"Time Proof ID (DTSA): {ai_record.content.vch_dtsa_tx_id}")
    print("--------------------------------------------------\n")
    
    # --- 2. Human Auditor Overrides (Invokes HAC Protocol) ---
    hac_record = system.human_auditor_correction(
        original_record=ai_record,
        human_actor=human_auditor,
        new_score=10,
        new_flag=TrustFlag.A,
        reason="AI misinterpreted the source's confidence interval. Manual re-verification confirms 100% accuracy."
    )
    
    print(f"--- 2. HUMAN AUDITOR CORRECTION (HAC) ---")
    print(f"Original AI Score: {hac_record['original_score']}, Final Human Score: {hac_record['new_score']}")
    print(f"Reason: {hac_record['reason_for_override']}")
    print(f"Liability: Transferred to Human Actor {hac_record['human_actor_id']} via Contract {hac_record['hac_liability_contract_id']}")
    
    # --- Final Audit Check ---
    # The audit log now contains the original AI log, plus the signed, superseding HAC record.
    final_log_check = next(item for item in system.audit_log if item['content']['content_id'] == ai_record.content.content_id)
    print("\n--- FINAL FORENSIC AUDIT (Complete Log Entry) ---")
    print(json.dumps(final_log_check, indent=2))
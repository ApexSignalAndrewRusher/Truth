import { useState } from 'react';
import FixedPointDemo from './components/FixedPointDemo';
import ReasoningEngine from './components/ReasoningEngine';
import Architecture from './components/Architecture';
import LocalHosting from './components/LocalHosting';

type Tab = 'overview' | 'fixedpoint' | 'reasoning' | 'architecture' | 'hosting';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('overview');

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'overview', label: 'Overview', icon: '📋' },
    { id: 'fixedpoint', label: 'Fixed-Point Math', icon: '⚙️' },
    { id: 'reasoning', label: 'Reasoning Engine', icon: '🧠' },
    { id: 'architecture', label: 'Architecture', icon: '🏗️' },
    { id: 'hosting', label: 'Local Hosting', icon: '🖥️' },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-lg flex items-center justify-center text-lg font-bold">
                ψ
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">Scientific Reasoning LLM</h1>
                <p className="text-xs text-gray-400 font-mono">ψ = min(ω_logic, ω_evidence) | Fixed-Point | Local-Only</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 text-xs text-gray-500 font-mono">
              <span className="px-2 py-1 bg-green-900/30 border border-green-500/30 rounded text-green-400">
                v0.1.0-core
              </span>
              <span className="px-2 py-1 bg-gray-800 rounded">
                Q16.16
              </span>
              <span className="px-2 py-1 bg-gray-800 rounded">
                0 floats
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b border-gray-800 bg-gray-900/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto py-2">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-gray-800 text-white border border-gray-600'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800/50'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'overview' && <OverviewSection />}
        {activeTab === 'fixedpoint' && <FixedPointDemo />}
        {activeTab === 'reasoning' && <ReasoningEngine />}
        {activeTab === 'architecture' && <Architecture />}
        {activeTab === 'hosting' && <LocalHosting />}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-800 bg-gray-900/50 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-gray-500">
          <p className="font-mono">
            Scientific Reasoning LLM Core | ψ = min(ω<sub>logic</sub>, ω<sub>evidence</sub>) | 
            Fixed-Point Q16.16 | No Floats | Local-Only | Open Source
          </p>
          <p className="mt-2 text-gray-600">
            Built on provable foundations: Mathematics • Biology • Physics
          </p>
        </div>
      </footer>
    </div>
  );
}

function OverviewSection() {
  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="text-center py-12">
        <div className="inline-block mb-6">
          <div className="text-6xl md:text-8xl font-mono font-bold bg-gradient-to-r from-purple-400 via-cyan-400 to-green-400 bg-clip-text text-transparent">
            ψ = min(ω<sub>L</sub>, ω<sub>E</sub>)
          </div>
        </div>
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
          Scientific Reasoning LLM Core
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-lg">
          A reasoning engine built on provable foundations from mathematics, biology, and physics.
          Uses only fixed-point arithmetic — zero floating-point operations.
          Runs entirely locally.
        </p>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gray-900 border border-purple-500/30 rounded-lg p-5">
          <div className="text-3xl mb-3">📐</div>
          <h3 className="text-sm font-bold text-purple-400 mb-2">Scientific Reasoning</h3>
          <p className="text-xs text-gray-400">
            ψ = min(ω<sub>logic</sub>, ω<sub>evidence</sub>)<br/>
            Confidence is bounded by the weakest link between logical consistency and empirical evidence.
          </p>
        </div>
        <div className="bg-gray-900 border border-blue-500/30 rounded-lg p-5">
          <div className="text-3xl mb-3">🔬</div>
          <h3 className="text-sm font-bold text-blue-400 mb-2">Deductive Constraint</h3>
          <p className="text-xs text-gray-400">
            ψ ≤ min(ω<sub>logic</sub>, ω<sub>evidence</sub>)<br/>
            Deductive reasoning cannot exceed the minimum confidence of its premises.
          </p>
        </div>
        <div className="bg-gray-900 border border-green-500/30 rounded-lg p-5">
          <div className="text-3xl mb-3">⚙️</div>
          <h3 className="text-sm font-bold text-green-400 mb-2">Fixed-Point Only</h3>
          <p className="text-xs text-gray-400">
            Q16.16 format. Integer-only arithmetic. No IEEE 754 floats.
            Deterministic across all hardware platforms.
          </p>
        </div>
        <div className="bg-gray-900 border border-orange-500/30 rounded-lg p-5">
          <div className="text-3xl mb-3">🏠</div>
          <h3 className="text-sm font-bold text-orange-400 mb-2">Local-First</h3>
          <p className="text-xs text-gray-400">
            No cloud. No APIs. No telemetry. Runs on your machine with
            minimal resources. Complete privacy.
          </p>
        </div>
      </div>

      {/* Formula Breakdown */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-bold text-white mb-4">Formula Breakdown</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-bold text-cyan-400 mb-3">Scientific Reasoning</h4>
            <div className="bg-gray-800 rounded p-4 font-mono text-sm space-y-3">
              <div>
                <span className="text-purple-400">ψ</span>
                <span className="text-gray-500"> = </span>
                <span className="text-yellow-400">min</span>
                <span className="text-gray-400">(</span>
                <span className="text-blue-400">ω<sub>logic</sub></span>
                <span className="text-gray-400">, </span>
                <span className="text-green-400">ω<sub>evidence</sub></span>
                <span className="text-gray-400">)</span>
              </div>
              <div className="text-xs text-gray-500 space-y-1">
                <p>• <span className="text-purple-400">ψ</span> = Reasoning confidence [0, 1]</p>
                <p>• <span className="text-blue-400">ω<sub>logic</sub></span> = Internal logical consistency</p>
                <p>• <span className="text-green-400">ω<sub>evidence</sub></span> = Empirical evidence weight</p>
                <p>• <span className="text-yellow-400">min</span> = Bounded by weakest factor</p>
              </div>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold text-cyan-400 mb-3">Deductive Reasoning</h4>
            <div className="bg-gray-800 rounded p-4 font-mono text-sm space-y-3">
              <div>
                <span className="text-purple-400">ψ</span>
                <span className="text-gray-500"> ≤ </span>
                <span className="text-yellow-400">min</span>
                <span className="text-gray-400">(</span>
                <span className="text-blue-400">ω<sub>L</sub></span>
                <span className="text-gray-400">, </span>
                <span className="text-green-400">ω<sub>E</sub></span>
                <span className="text-gray-400">)</span>
              </div>
              <div className="text-xs text-gray-500 space-y-1">
                <p>• Conclusion ≤ weakest premise</p>
                <p>• Chain: ψ<sub>final</sub> = min(ψ<sub>1</sub>, ..., ψ<sub>n</sub>)</p>
                <p>• No amplification of uncertainty</p>
                <p>• Formal guarantee of soundness</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Knowledge Domains */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-bold text-white mb-4">Knowledge Domains (Provable Only)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
            <h4 className="text-sm font-bold text-blue-400 mb-3 flex items-center gap-2">
              <span>📊</span> Mathematics
            </h4>
            <ul className="text-xs text-gray-400 space-y-2">
              <li>• Peano axioms & number theory</li>
              <li>• Gödel's theorems (limits of provability)</li>
              <li>• Set theory (ZFC)</li>
              <li>• Graph theory & combinatorics</li>
              <li>• Information theory (Shannon)</li>
            </ul>
          </div>
          <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
            <h4 className="text-sm font-bold text-green-400 mb-3 flex items-center gap-2">
              <span>🧬</span> Biology
            </h4>
            <ul className="text-xs text-gray-400 space-y-2">
              <li>• DNA/RNA base-pair complementarity</li>
              <li>• Natural selection (population genetics)</li>
              <li>• ATP energy metabolism</li>
              <li>• Cell theory & membrane biology</li>
              <li>• Neural signaling (action potentials)</li>
            </ul>
          </div>
          <div className="bg-orange-900/20 border border-orange-500/30 rounded-lg p-4">
            <h4 className="text-sm font-bold text-orange-400 mb-3 flex items-center gap-2">
              <span>⚛️</span> Physics
            </h4>
            <ul className="text-xs text-gray-400 space-y-2">
              <li>• Conservation laws (Noether's theorem)</li>
              <li>• Special relativity (c invariant)</li>
              <li>• Thermodynamics (entropy)</li>
              <li>• Quantum mechanics (Schrödinger eq.)</li>
              <li>• Electromagnetism (Maxwell's eq.)</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Why This Approach */}
      <div className="bg-gray-900 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-bold text-white mb-4">Why This Approach?</h3>
        <div className="space-y-4 text-sm text-gray-400">
          <div className="flex gap-3">
            <span className="text-yellow-400 font-bold">1.</span>
            <p><strong className="text-gray-200">No hallucination by design.</strong> The engine only reasons about provable statements. If evidence or logic is insufficient, ψ drops to zero — the system says "I don't know" rather than fabricating.</p>
          </div>
          <div className="flex gap-3">
            <span className="text-yellow-400 font-bold">2.</span>
            <p><strong className="text-gray-200">Deterministic computation.</strong> Fixed-point math ensures the same input always produces the same output, regardless of hardware. No floating-point non-determinism.</p>
          </div>
          <div className="flex gap-3">
            <span className="text-yellow-400 font-bold">3.</span>
            <p><strong className="text-gray-200">Weakest-link principle.</strong> The min() function ensures confidence is bounded by the least reliable component. This is mathematically sound — it's how real science works.</p>
          </div>
          <div className="flex gap-3">
            <span className="text-yellow-400 font-bold">4.</span>
            <p><strong className="text-gray-200">Minimal compute.</strong> No GPU needed. No massive model weights. Integer arithmetic runs on anything — even a microcontroller. True local-first AI.</p>
          </div>
          <div className="flex gap-3">
            <span className="text-yellow-400 font-bold">5.</span>
            <p><strong className="text-gray-200">Verifiable reasoning chains.</strong> Every conclusion comes with a traceable chain of logical steps, each with its own confidence score. You can audit every inference.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;

export default function Architecture() {
  return (
    <div className="bg-gray-900 border border-cyan-500/30 rounded-lg p-6">
      <h3 className="text-xl font-bold text-cyan-400 mb-6 flex items-center gap-2">
        <span className="text-2xl">🏗️</span> System Architecture
      </h3>

      {/* Architecture Diagram */}
      <div className="bg-gray-800 rounded-lg p-6 mb-6 overflow-x-auto">
        <pre className="text-xs md:text-sm text-cyan-300 font-mono leading-relaxed">
{`
┌─────────────────────────────────────────────────────────────────────┐
│                    SCIENTIFIC REASONING LLM CORE                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────┐      │
│  │   INPUT      │    │  KNOWLEDGE   │    │   FIXED-POINT    │      │
│  │   LAYER      │───▶│   BASE       │───▶│   MATH ENGINE    │      │
│  │              │    │              │    │                  │      │
│  │ • Axioms     │    │ • Math       │    │ • Q16.16 format  │      │
│  │ • Evidence   │    │ • Biology    │    │ • Integer-only   │      │
│  │ • Queries    │    │ • Physics    │    │ • No IEEE 754    │      │
│  └──────────────┘    └──────────────┘    └────────┬─────────┘      │
│                                                    │                │
│                                                    ▼                │
│  ┌──────────────────────────────────────────────────────────┐      │
│  │              REASONING ENGINE                             │      │
│  │                                                          │      │
│  │   ψ = min(ω_logic, ω_evidence)                          │      │
│  │                                                          │      │
│  │   Deductive: ψ ≤ min(ω_L, ω_E)                         │      │
│  │   Accumulate: P = 1 - Π(1 - P_i)                        │      │
│  │   Chain: ψ_final = min(ψ_1, ψ_2, ..., ψ_n)             │      │
│  └──────────────────────────────────────────────────────────┘      │
│                          │                                         │
│                          ▼                                         │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────┐      │
│  │  VERIFICATION│    │   OUTPUT     │    │   CONFIDENCE     │      │
│  │   LAYER      │◀───│   LAYER      │◀───│   SCORING       │      │
│  │              │    │              │    │                  │      │
│  │ • Proof      │    │ • Claims     │    │ • ψ ∈ [0, 1]    │      │
│  │   checking   │    │ • Derivations│    │ • Bounded by     │      │
│  │ • Consistency│    │ • Chains     │    │   weakest link   │      │
│  │   validation │    │ • Confidence │    │ • Deterministic  │      │
│  └──────────────┘    └──────────────┘    └──────────────────┘      │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│  HOSTING: Local only | No cloud | No external APIs | No telemetry   │
└─────────────────────────────────────────────────────────────────────┘
`}
        </pre>
      </div>

      {/* Design Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-800 border border-gray-700 rounded p-4">
          <h4 className="text-sm font-bold text-green-400 mb-2">🔒 Deterministic</h4>
          <p className="text-xs text-gray-400">
            Fixed-point math guarantees identical results on any hardware. 
            No floating-point rounding differences. Reproducible reasoning.
          </p>
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded p-4">
          <h4 className="text-sm font-bold text-blue-400 mb-2">📐 Provable Only</h4>
          <p className="text-xs text-gray-400">
            Only statements from mathematics, biology, and physics that have 
            formal proofs or overwhelming empirical evidence. No speculation.
          </p>
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded p-4">
          <h4 className="text-sm font-bold text-purple-400 mb-2">⚡ Local-First</h4>
          <p className="text-xs text-gray-400">
            Runs entirely on your machine. No network required. No data leaves 
            your system. Complete privacy and control.
          </p>
        </div>
      </div>

      {/* Data Flow */}
      <div className="mt-6 bg-gray-800 border border-gray-700 rounded p-4">
        <h4 className="text-sm font-bold text-yellow-400 mb-3">Data Flow: Query → Answer</h4>
        <div className="space-y-3">
          {[
            { step: '1', title: 'Parse Query', desc: 'Extract claim to verify from natural language input', color: 'text-cyan-400' },
            { step: '2', title: 'Retrieve Axioms', desc: 'Find relevant proven statements from knowledge base', color: 'text-blue-400' },
            { step: '3', title: 'Build Chain', desc: 'Construct reasoning chain linking axioms to conclusion', color: 'text-purple-400' },
            { step: '4', title: 'Compute ψ', desc: 'Apply ψ = min(ω_logic, ω_evidence) at each step', color: 'text-green-400' },
            { step: '5', title: 'Verify', desc: 'Check logical consistency and evidence sufficiency', color: 'text-yellow-400' },
            { step: '6', title: 'Output', desc: 'Return answer with confidence score ψ', color: 'text-red-400' },
          ].map(item => (
            <div key={item.step} className="flex items-center gap-3">
              <span className={`w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center text-xs font-mono ${item.color}`}>
                {item.step}
              </span>
              <div>
                <span className={`text-sm font-bold ${item.color}`}>{item.title}</span>
                <span className="text-xs text-gray-500 ml-2">{item.desc}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

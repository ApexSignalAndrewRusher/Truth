import { useState } from 'react';
import {
  toFixed, toReal, fpAdd, fpSub, fpMul, fpDiv,
  fpMin, fpSqrt, fpFormat, fpRaw, FP_ONE, FP_HALF
} from '../lib/fixedpoint';

export default function FixedPointDemo() {
  const [inputA, setInputA] = useState('3.14159');
  const [inputB, setInputB] = useState('2.71828');
  const [results, setResults] = useState<{ op: string; raw: string; display: string }[]>([]);

  const compute = () => {
    const a = toFixed(parseFloat(inputA));
    const b = toFixed(parseFloat(inputB));
    
    const ops = [
      { name: 'Addition (a + b)', fn: () => fpAdd(a, b) },
      { name: 'Subtraction (a - b)', fn: () => fpSub(a, b) },
      { name: 'Multiplication (a × b)', fn: () => fpMul(a, b) },
      { name: 'Division (a ÷ b)', fn: () => fpDiv(a, b) },
      { name: 'Minimum (min(a,b))', fn: () => fpMin(a, b) },
      { name: 'Square Root (√a)', fn: () => fpSqrt(a) },
    ];

    const newResults = ops.map(op => {
      try {
        const result = op.fn();
        return {
          op: op.name,
          raw: fpRaw(result),
          display: fpFormat(result, 6)
        };
      } catch (e: any) {
        return {
          op: op.name,
          raw: 'ERROR',
          display: e.message
        };
      }
    });

    setResults(newResults);
  };

  return (
    <div className="bg-gray-900 border border-green-500/30 rounded-lg p-6">
      <h3 className="text-xl font-bold text-green-400 mb-4 flex items-center gap-2">
        <span className="text-2xl">⚙️</span> Fixed-Point Math Engine
      </h3>
      <p className="text-gray-400 text-sm mb-4">
        Q16.16 format: 16-bit integer + 16-bit fractional. All operations use integer-only arithmetic.
        Scale factor: 65536 (2¹⁶). Zero floats in computation.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="text-gray-300 text-sm block mb-1">Value A</label>
          <input
            type="text"
            value={inputA}
            onChange={(e) => setInputA(e.target.value)}
            className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2 text-green-300 font-mono text-sm"
          />
          <span className="text-xs text-gray-500 mt-1 block">
            Raw: {fpRaw(toFixed(parseFloat(inputA) || 0))}
          </span>
        </div>
        <div>
          <label className="text-gray-300 text-sm block mb-1">Value B</label>
          <input
            type="text"
            value={inputB}
            onChange={(e) => setInputB(e.target.value)}
            className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-2 text-green-300 font-mono text-sm"
          />
          <span className="text-xs text-gray-500 mt-1 block">
            Raw: {fpRaw(toFixed(parseFloat(inputB) || 0))}
          </span>
        </div>
      </div>

      <button
        onClick={compute}
        className="bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded font-mono text-sm transition-colors"
      >
        Compute (Integer-Only)
      </button>

      {results.length > 0 && (
        <div className="mt-4 space-y-2">
          {results.map((r, i) => (
            <div key={i} className="bg-gray-800 border border-gray-700 rounded p-3 flex justify-between items-center">
              <span className="text-gray-300 text-sm">{r.op}</span>
              <div className="text-right">
                <div className="text-green-400 font-mono text-sm">{r.display}</div>
                <div className="text-gray-500 font-mono text-xs">raw: {r.raw}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 p-3 bg-gray-800/50 border border-gray-700 rounded text-xs text-gray-400">
        <strong className="text-yellow-400">Why no floats?</strong> Fixed-point guarantees deterministic
        results across all hardware. No IEEE 754 rounding differences. Reproducible on any CPU, GPU,
        or FPGA. Critical for scientific reasoning where precision matters.
      </div>
    </div>
  );
}

import { useState } from 'react';

export default function LocalHosting() {
  const [activeTab, setActiveTab] = useState<'rust' | 'c' | 'python'>('rust');

  const codeExamples = {
    rust: `// Cargo.toml
[package]
name = "scientific-reasoning-llm"
version = "0.1.0"
edition = "2021"

// src/fixedpoint.rs
pub type FixedPoint = i32;
pub const SCALE: i32 = 65536; // 2^16

pub fn to_fixed(real: f64) -> FixedPoint {
    (real * SCALE as f64) as i32
}

pub fn fp_mul(a: FixedPoint, b: FixedPoint) -> FixedPoint {
    ((a as i64 * b as i64) >> 16) as i32
}

pub fn fp_div(a: FixedPoint, b: FixedPoint) -> FixedPoint {
    ((a as i64) << 16 / b as i64) as i32
}

pub fn fp_min(a: FixedPoint, b: FixedPoint) -> FixedPoint {
    if a < b { a } else { b }
}

// src/reasoning.rs
use crate::fixedpoint::*;

/// ψ = min(ω_logic, ω_evidence)
pub fn scientific_reasoning(
    omega_logic: FixedPoint,
    omega_evidence: FixedPoint,
) -> FixedPoint {
    fp_min(omega_logic, omega_evidence)
}

/// Deductive: ψ ≤ min(ω_logic, ω_evidence)
pub fn deductive_reasoning(
    omega_logic: FixedPoint,
    omega_evidence: FixedPoint,
    premises: &[FixedPoint],
) -> FixedPoint {
    let base = scientific_reasoning(omega_logic, omega_evidence);
    let min_premise = premises.iter()
        .copied()
        .reduce(fp_min)
        .unwrap_or(to_fixed(1.0));
    fp_min(base, min_premise)
}

// src/main.rs
mod fixedpoint;
mod reasoning;

fn main() {
    use fixedpoint::*;
    use reasoning::*;
    
    let omega_logic = to_fixed(0.95);
    let omega_evidence = to_fixed(0.88);
    
    let psi = scientific_reasoning(omega_logic, omega_evidence);
    
    println!("ψ = {}", to_real(psi));
    println!("Raw fixed-point: {}", psi);
    
    // Run locally - no network, no cloud
    println!("Scientific Reasoning LLM Core v0.1.0");
    println!("Fixed-point: Q16.16 | No floats in computation");
}

// Build: cargo build --release
// Run: ./target/release/scientific-reasoning-llm`,

    c: `// fixedpoint.h
#ifndef FIXEDPOINT_H
#define FIXEDPOINT_H

#include <stdint.h>

typedef int32_t fixed_t;
#define FP_SCALE 65536  // 2^16

static inline fixed_t fp_from_real(double r) {
    return (fixed_t)(r * FP_SCALE);
}

static inline double fp_to_real(fixed_t f) {
    return (double)f / FP_SCALE;
}

static inline fixed_t fp_add(fixed_t a, fixed_t b) {
    return a + b;
}

static inline fixed_t fp_sub(fixed_t a, fixed_t b) {
    return a - b;
}

static inline fixed_t fp_mul(fixed_t a, fixed_t b) {
    return (fixed_t)(((int64_t)a * b) >> 16);
}

static inline fixed_t fp_div(fixed_t a, fixed_t b) {
    return (fixed_t)(((int64_t)a << 16) / b);
}

static inline fixed_t fp_min(fixed_t a, fixed_t b) {
    return a < b ? a : b;
}

#endif

// reasoning.h
#ifndef REASONING_H
#define REASONING_H

#include "fixedpoint.h"

/* ψ = min(ω_logic, ω_evidence) */
static inline fixed_t scientific_reasoning(
    fixed_t omega_logic,
    fixed_t omega_evidence
) {
    return fp_min(omega_logic, omega_evidence);
}

/* Deductive: ψ ≤ min(ω_logic, ω_evidence) */
fixed_t deductive_reasoning(
    fixed_t omega_logic,
    fixed_t omega_evidence,
    const fixed_t *premises,
    int n_premises
) {
    fixed_t base = scientific_reasoning(omega_logic, omega_evidence);
    fixed_t min_premise = premises[0];
    for (int i = 1; i < n_premises; i++) {
        min_premise = fp_min(min_premise, premises[i]);
    }
    return fp_min(base, min_premise);
}

#endif

// main.c
#include <stdio.h>
#include "reasoning.h"

int main() {
    fixed_t omega_logic = fp_from_real(0.95);
    fixed_t omega_evidence = fp_from_real(0.88);
    
    fixed_t psi = scientific_reasoning(omega_logic, omega_evidence);
    
    printf("ψ = %.6f\\n", fp_to_real(psi));
    printf("Raw: %d\\n", psi);
    printf("Scientific Reasoning LLM Core\\n");
    
    return 0;
}

// Build: gcc -O2 -o reasoning_llm main.c
// Run: ./reasoning_llm`,

    python: `# fixedpoint.py
# Reference implementation (Python uses floats internally,
# but demonstrates the fixed-point API for prototyping)

class FixedPoint:
    """Q16.16 fixed-point number"""
    SCALE = 65536  # 2^16
    
    def __init__(self, raw: int):
        self.raw = raw  # Internal integer representation
    
    @classmethod
    def from_real(cls, value: float) -> 'FixedPoint':
        return cls(int(value * cls.SCALE))
    
    def to_real(self) -> float:
        return self.raw / self.SCALE
    
    def __add__(self, other: 'FixedPoint') -> 'FixedPoint':
        return FixedPoint(self.raw + other.raw)
    
    def __sub__(self, other: 'FixedPoint') -> 'FixedPoint':
        return FixedPoint(self.raw - other.raw)
    
    def __mul__(self, other: 'FixedPoint') -> 'FixedPoint':
        # Integer multiplication with shift
        result = (self.raw * other.raw) >> 16
        return FixedPoint(result)
    
    def __truediv__(self, other: 'FixedPoint') -> 'FixedPoint':
        if other.raw == 0:
            raise ZeroDivisionError("Fixed-point division by zero")
        result = (self.raw << 16) // other.raw
        return FixedPoint(result)
    
    @staticmethod
    def fp_min(a: 'FixedPoint', b: 'FixedPoint') -> 'FixedPoint':
        return a if a.raw < b.raw else b
    
    def __repr__(self):
        return f"FP({self.to_real():.6f}, raw={self.raw})"


# reasoning.py
from fixedpoint import FixedPoint as FP

def scientific_reasoning(omega_logic: FP, omega_evidence: FP) -> FP:
    """ψ = min(ω_logic, ω_evidence)"""
    return FP.fp_min(omega_logic, omega_evidence)

def deductive_reasoning(
    omega_logic: FP,
    omega_evidence: FP,
    premises: list[FP]
) -> FP:
    """ψ ≤ min(ω_logic, ω_evidence)"""
    base = scientific_reasoning(omega_logic, omega_evidence)
    min_premise = premises[0]
    for p in premises[1:]:
        min_premise = FP.fp_min(min_premise, p)
    return FP.fp_min(base, min_premise)

def accumulate_evidence(weights: list[FP]) -> FP:
    """P = 1 - Π(1 - P_i)"""
    product = FP(65536)  # 1.0
    one = FP(65536)
    for w in weights:
        complement = one - w
        product = product * complement
    return one - product


# main.py
from fixedpoint import FixedPoint as FP
from reasoning import scientific_reasoning, deductive_reasoning

if __name__ == "__main__":
    omega_logic = FP.from_real(0.95)
    omega_evidence = FP.from_real(0.88)
    
    psi = scientific_reasoning(omega_logic, omega_evidence)
    
    print(f"ψ = {psi.to_real():.6f}")
    print(f"Raw fixed-point: {psi.raw}")
    print(f"Scientific Reasoning LLM Core")
    print(f"Fixed-point: Q16.16 | No floats in computation")

# Run: python main.py`
  };

  return (
    <div className="bg-gray-900 border border-orange-500/30 rounded-lg p-6">
      <h3 className="text-xl font-bold text-orange-400 mb-4 flex items-center gap-2">
        <span className="text-2xl">🖥️</span> Local Hosting Guide
      </h3>

      <div className="bg-gray-800 border border-orange-500/20 rounded p-4 mb-6">
        <h4 className="text-sm font-bold text-orange-300 mb-2">Requirements</h4>
        <ul className="text-xs text-gray-400 space-y-1">
          <li>• <strong className="text-gray-300">OS:</strong> Linux, macOS, or Windows (WSL2)</li>
          <li>• <strong className="text-gray-300">RAM:</strong> 512MB minimum (knowledge base fits in memory)</li>
          <li>• <strong className="text-gray-300">CPU:</strong> Any x86_64 or ARM64 (fixed-point is universal)</li>
          <li>• <strong className="text-gray-300">Network:</strong> None required (fully offline)</li>
          <li>• <strong className="text-gray-300">GPU:</strong> Not needed (integer math, not tensor ops)</li>
        </ul>
      </div>

      {/* Code Tabs */}
      <div className="mb-4">
        <div className="flex gap-1 mb-2">
          {(['rust', 'c', 'python'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-t text-xs font-mono transition-colors ${
                activeTab === tab
                  ? 'bg-gray-800 text-orange-400 border border-orange-500/30 border-b-0'
                  : 'bg-gray-700 text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab === 'rust' ? '🦀 Rust' : tab === 'c' ? '⚡ C' : '🐍 Python'}
            </button>
          ))}
        </div>
        <div className="bg-gray-800 border border-gray-700 rounded-b rounded-tr-lg p-4 overflow-x-auto">
          <pre className="text-xs text-gray-300 font-mono whitespace-pre">
            {codeExamples[activeTab]}
          </pre>
        </div>
      </div>

      {/* Quick Start */}
      <div className="bg-gray-800 border border-gray-700 rounded p-4">
        <h4 className="text-sm font-bold text-green-400 mb-3">Quick Start</h4>
        <div className="space-y-2 text-xs font-mono">
          <div className="flex items-center gap-2">
            <span className="text-gray-500">$</span>
            <span className="text-green-300">git clone https://github.com/your-repo/scientific-reasoning-llm</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-500">$</span>
            <span className="text-green-300">cd scientific-reasoning-llm</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-500">$</span>
            <span className="text-green-300">cargo build --release</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-500">$</span>
            <span className="text-green-300">./target/release/scientific-reasoning-llm</span>
          </div>
          <div className="mt-2 text-gray-400">
            # Output: ψ = 0.880000 | Raw: 57672
          </div>
        </div>
      </div>

      {/* Memory Layout */}
      <div className="mt-4 bg-gray-800 border border-gray-700 rounded p-4">
        <h4 className="text-sm font-bold text-cyan-400 mb-3">Memory Layout (Q16.16)</h4>
        <div className="font-mono text-xs">
          <div className="flex">
            <div className="flex-1 bg-blue-900/40 border border-blue-500/30 p-2 text-center text-blue-300">
              Integer (16 bits)
            </div>
            <div className="flex-1 bg-green-900/40 border border-green-500/30 p-2 text-center text-green-300">
              Fractional (16 bits)
            </div>
          </div>
          <div className="flex text-gray-500 mt-1">
            <div className="flex-1 text-center">-32768 to 32767</div>
            <div className="flex-1 text-center">0 to 0.99998...</div>
          </div>
          <div className="text-center text-gray-400 mt-2">
            Total: 32 bits (4 bytes) per number | Precision: 1/65536 ≈ 0.0000153
          </div>
        </div>
      </div>
    </div>
  );
}

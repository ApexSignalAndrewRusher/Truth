import { useState } from 'react';
import {
  scientificReasoning, deductiveReasoning, buildReasoningChain,
  crossDomainReasoning, accumulateEvidence,
  MATHEMATICS_AXIOMS, BIOLOGY_AXIOMS, PHYSICS_AXIOMS,
  Axiom, ReasoningChain
} from '../lib/reasoning';
import { toFixed, fpFormat, FP_ONE, FP_ZERO } from '../lib/fixedpoint';

export default function ReasoningEngine() {
  const [logicWeight, setLogicWeight] = useState(0.95);
  const [evidenceWeight, setEvidenceWeight] = useState(0.88);
  const [showChain, setShowChain] = useState(false);
  const [chain, setChain] = useState<ReasoningChain | null>(null);
  const [selectedDomain, setSelectedDomain] = useState<'all' | 'math' | 'biology' | 'physics'>('all');

  const psi = scientificReasoning(toFixed(logicWeight), toFixed(evidenceWeight));
  
  const allAxioms = [
    ...MATHEMATICS_AXIOMS,
    ...BIOLOGY_AXIOMS,
    ...PHYSICS_AXIOMS
  ];

  const filteredAxioms = selectedDomain === 'all' 
    ? allAxioms 
    : allAxioms.filter(a => a.domain === selectedDomain);

  const runChain = () => {
    const result = buildReasoningChain(filteredAxioms);
    setChain(result);
    setShowChain(true);
  };

  // Cross-domain reasoning demo
  const crossDomain = crossDomainReasoning(
    toFixed(0.95),  // math evidence
    toFixed(0.88),  // biology evidence
    toFixed(0.92),  // physics evidence
    toFixed(logicWeight) // logical consistency
  );

  return (
    <div className="bg-gray-900 border border-purple-500/30 rounded-lg p-6">
      <h3 className="text-xl font-bold text-purple-400 mb-4 flex items-center gap-2">
        <span className="text-2xl">🧠</span> Scientific Reasoning Engine
      </h3>
      
      {/* Core Formula Display */}
      <div className="bg-gray-800 border border-purple-500/20 rounded p-4 mb-6 text-center">
        <div className="text-2xl font-mono text-purple-300 mb-2">
          ψ = min(ω<sub>logic</sub>, ω<sub>evidence</sub>)
        </div>
        <div className="text-sm text-gray-400">
          Deductive: ψ ≤ min(ω<sub>logic</sub>, ω<sub>evidence</sub>)
        </div>
      </div>

      {/* Weight Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="text-gray-300 text-sm block mb-2">
            ω<sub>logic</sub> (Logical Consistency): <span className="text-blue-400 font-mono">{logicWeight.toFixed(3)}</span>
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={logicWeight * 100}
            onChange={(e) => setLogicWeight(parseInt(e.target.value) / 100)}
            className="w-full accent-blue-500"
          />
        </div>
        <div>
          <label className="text-gray-300 text-sm block mb-2">
            ω<sub>evidence</sub> (Empirical Evidence): <span className="text-green-400 font-mono">{evidenceWeight.toFixed(3)}</span>
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={evidenceWeight * 100}
            onChange={(e) => setEvidenceWeight(parseInt(e.target.value) / 100)}
            className="w-full accent-green-500"
          />
        </div>
      </div>

      {/* Result */}
      <div className="bg-gradient-to-r from-blue-900/30 to-green-900/30 border border-purple-500/30 rounded p-4 mb-6">
        <div className="text-center">
          <div className="text-sm text-gray-400 mb-1">Reasoning Confidence (ψ)</div>
          <div className="text-4xl font-mono font-bold text-white">
            {fpFormat(psi, 4)}
          </div>
          <div className="text-xs text-gray-500 mt-1">
            Fixed-point raw: {psi} | Bounded by min({logicWeight.toFixed(3)}, {evidenceWeight.toFixed(3)})
          </div>
        </div>
      </div>

      {/* Cross-Domain */}
      <div className="bg-gray-800 border border-gray-700 rounded p-4 mb-6">
        <h4 className="text-sm font-bold text-yellow-400 mb-2">Cross-Domain Reasoning</h4>
        <div className="grid grid-cols-3 gap-2 text-center text-xs mb-3">
          <div className="bg-blue-900/30 rounded p-2">
            <div className="text-blue-300">Math</div>
            <div className="font-mono">0.950</div>
          </div>
          <div className="bg-green-900/30 rounded p-2">
            <div className="text-green-300">Biology</div>
            <div className="font-mono">0.880</div>
          </div>
          <div className="bg-orange-900/30 rounded p-2">
            <div className="text-orange-300">Physics</div>
            <div className="font-mono">0.920</div>
          </div>
        </div>
        <div className="text-center text-sm">
          <span className="text-gray-400">Combined ψ = </span>
          <span className="text-yellow-300 font-mono font-bold">{fpFormat(crossDomain, 4)}</span>
        </div>
      </div>

      {/* Axiom Chain */}
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-sm text-gray-300">Domain Filter:</span>
          {(['all', 'math', 'biology', 'physics'] as const).map(d => (
            <button
              key={d}
              onClick={() => setSelectedDomain(d)}
              className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                selectedDomain === d
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
              }`}
            >
              {d}
            </button>
          ))}
        </div>

        <div className="space-y-2 mb-4">
          {filteredAxioms.map(axiom => (
            <div key={axiom.id} className="bg-gray-800 border border-gray-700 rounded p-3">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs px-2 py-0.5 rounded font-mono ${
                      axiom.domain === 'math' ? 'bg-blue-900/50 text-blue-300' :
                      axiom.domain === 'biology' ? 'bg-green-900/50 text-green-300' :
                      'bg-orange-900/50 text-orange-300'
                    }`}>
                      {axiom.domain}
                    </span>
                    <span className="text-gray-300 text-sm">{axiom.statement}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    ω<sub>L</sub>={fpFormat(axiom.logicalConsistency, 2)} | 
                    ω<sub>E</sub>={fpFormat(axiom.evidenceWeight, 2)} | 
                    ψ={fpFormat(scientificReasoning(axiom.logicalConsistency, axiom.evidenceWeight), 2)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={runChain}
          className="bg-purple-600 hover:bg-purple-500 text-white px-6 py-2 rounded font-mono text-sm transition-colors w-full"
        >
          Build Reasoning Chain
        </button>
      </div>

      {/* Chain Visualization */}
      {showChain && chain && (
        <div className="bg-gray-800 border border-purple-500/30 rounded p-4">
          <h4 className="text-sm font-bold text-purple-300 mb-3">Reasoning Chain Execution</h4>
          <div className="space-y-2">
            {chain.steps.map((step, i) => (
              <div key={i} className="flex items-center gap-3 text-xs">
                <span className="text-gray-500 font-mono w-6">#{step.stepNumber}</span>
                <div className="flex-1 bg-gray-900 rounded p-2">
                  <div className="text-gray-300">{step.operation}</div>
                  <div className="text-gray-500 font-mono">
                    min({fpFormat(step.inputWeights.logic, 3)}, {fpFormat(step.inputWeights.evidence, 3)}) = {fpFormat(step.outputPsi, 4)}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-700 text-center">
            <span className="text-gray-400 text-sm">Final ψ = </span>
            <span className="text-purple-300 font-mono font-bold text-lg">
              {fpFormat(chain.finalConfidence, 4)}
            </span>
            <span className={`ml-2 text-xs ${chain.valid ? 'text-green-400' : 'text-red-400'}`}>
              [{chain.valid ? 'VALID' : 'INVALID'}]
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

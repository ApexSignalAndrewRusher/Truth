/**
 * Badge & Flag System
 * ===================
 * Internal Badges: System health, consistency, integrity
 * External Badges: Public-facing verification, trust signals
 * 
 * All badges are CRYPTOGRAPHICALLY HASHED.
 * All flags are DETERMINISTIC and VERIFIABLE.
 * 
 * VCH Compliant: Conservative, Honest, Transparent.
 * Open Source: No gatekeeping, no tribalism.
 */

import { Fixed, BitWidth } from './bitwidth';
import { fnv1a, hashToHex, hashChain, hashTimestamped, verifyHash } from './crypto';

// ============================================================
// BADGE TYPES
// ============================================================

export type BadgeLevel = 'verified' | 'provisional' | 'flagged' | 'revoked';
export type BadgeCategory = 'integrity' | 'accuracy' | 'privacy' | 'compliance' | 'audit' | 'truth';
export type BadgeScope = 'internal' | 'external';

export interface Badge {
  id: string;
  name: string;
  description: string;
  category: BadgeCategory;
  scope: BadgeScope;
  level: BadgeLevel;
  confidence: Fixed;        // ψ score for this badge
  hash: string;             // Cryptographic hash of badge data
  timestamp: number;        // When badge was issued
  issuer: string;           // Who issued it (system/human/audit)
  data: Record<string, string>; // Badge-specific data
  chainHash: string;        // Hash linking to previous badge
}

// ============================================================
// FLAG TYPES
// ============================================================

export type FlagSeverity = 'info' | 'warning' | 'critical' | 'blocked';
export type FlagType = 'privacy' | 'truth' | 'consistency' | 'legal' | 'safety' | 'audit';

export interface Flag {
  id: string;
  type: FlagType;
  severity: FlagSeverity;
  message: string;
  hash: string;
  timestamp: number;
  resolved: boolean;
  resolution?: string;
  resolutionHash?: string;
}

// ============================================================
// BADGE FACTORY
// ============================================================

let badgeCounter = 0;
let lastChainHash = '0000000000000000';

function generateBadgeId(): string {
  badgeCounter++;
  return `badge-${Date.now()}-${badgeCounter}`;
}

function computeBadgeHash(badge: Omit<Badge, 'hash' | 'chainHash'>): string {
  const data = JSON.stringify({
    id: badge.id,
    name: badge.name,
    category: badge.category,
    scope: badge.scope,
    level: badge.level,
    confidence: badge.confidence.toBigInt().toString(),
    timestamp: badge.timestamp,
    issuer: badge.issuer,
    data: badge.data
  });
  return hashToHex(fnv1a(data, 64), 64);
}

function computeChainHash(currentHash: string): string {
  const chain = hashToHex(fnv1a(`${lastChainHash}:${currentHash}`, 64), 64);
  lastChainHash = chain;
  return chain;
}

// ============================================================
// INTERNAL BADGES (System Health)
// ============================================================

export function createIntegrityBadge(
  systemName: string,
  checksPassed: number,
  totalChecks: number,
  bits: BitWidth = 32
): Badge {
  const ratio = checksPassed / totalChecks;
  const confidence = Fixed.fromReal(ratio, bits);
  
  const badge: Omit<Badge, 'hash' | 'chainHash'> = {
    id: generateBadgeId(),
    name: `Integrity: ${systemName}`,
    description: `${checksPassed}/${totalChecks} integrity checks passed`,
    category: 'integrity',
    scope: 'internal',
    level: ratio >= 0.95 ? 'verified' : ratio >= 0.8 ? 'provisional' : 'flagged',
    confidence,
    timestamp: Date.now(),
    issuer: 'system',
    data: {
      system: systemName,
      checksPassed: checksPassed.toString(),
      totalChecks: totalChecks.toString(),
      ratio: ratio.toFixed(4),
      bitWidth: bits.toString()
    }
  };

  const hash = computeBadgeHash(badge);
  const chainHash = computeChainHash(hash);
  
  return { ...badge, hash, chainHash };
}

export function createConsistencyBadge(
  domain: string,
  consistent: boolean,
  details: string,
  bits: BitWidth = 32
): Badge {
  const confidence = consistent ? Fixed.one(bits) : Fixed.zero(bits);
  
  const badge: Omit<Badge, 'hash' | 'chainHash'> = {
    id: generateBadgeId(),
    name: `Consistency: ${domain}`,
    description: details,
    category: 'accuracy',
    scope: 'internal',
    level: consistent ? 'verified' : 'flagged',
    confidence,
    timestamp: Date.now(),
    issuer: 'system',
    data: {
      domain,
      consistent: consistent.toString(),
      details
    }
  };

  const hash = computeBadgeHash(badge);
  const chainHash = computeChainHash(hash);
  
  return { ...badge, hash, chainHash };
}

// ============================================================
// EXTERNAL BADGES (Public Verification)
// ============================================================

export function createTruthBadge(
  claim: string,
  verified: boolean,
  evidence: string,
  bits: BitWidth = 32
): Badge {
  const confidence = verified ? Fixed.fromReal(0.95, bits) : Fixed.fromReal(0.1, bits);
  
  const badge: Omit<Badge, 'hash' | 'chainHash'> = {
    id: generateBadgeId(),
    name: `Truth: ${claim.substring(0, 50)}`,
    description: `Claim verified: ${verified}. Evidence: ${evidence}`,
    category: 'truth',
    scope: 'external',
    level: verified ? 'verified' : 'flagged',
    confidence,
    timestamp: Date.now(),
    issuer: 'audit',
    data: {
      claim,
      verified: verified.toString(),
      evidence
    }
  };

  const hash = computeBadgeHash(badge);
  const chainHash = computeChainHash(hash);
  
  return { ...badge, hash, chainHash };
}

export function createPrivacyBadge(
  action: string,
  privacyPreserved: boolean,
  method: string,
  bits: BitWidth = 32
): Badge {
  const confidence = privacyPreserved ? Fixed.one(bits) : Fixed.fromReal(0.0, bits);
  
  const badge: Omit<Badge, 'hash' | 'chainHash'> = {
    id: generateBadgeId(),
    name: `Privacy: ${action}`,
    description: `Privacy ${privacyPreserved ? 'preserved' : 'violated'} via ${method}`,
    category: 'privacy',
    scope: 'external',
    level: privacyPreserved ? 'verified' : 'revoked',
    confidence,
    timestamp: Date.now(),
    issuer: 'system',
    data: {
      action,
      privacyPreserved: privacyPreserved.toString(),
      method
    }
  };

  const hash = computeBadgeHash(badge);
  const chainHash = computeChainHash(hash);
  
  return { ...badge, hash, chainHash };
}

export function createComplianceBadge(
  regulation: string,
  compliant: boolean,
  details: string,
  bits: BitWidth = 32
): Badge {
  const confidence = compliant ? Fixed.fromReal(0.98, bits) : Fixed.zero(bits);
  
  const badge: Omit<Badge, 'hash' | 'chainHash'> = {
    id: generateBadgeId(),
    name: `Compliance: ${regulation}`,
    description: details,
    category: 'compliance',
    scope: 'external',
    level: compliant ? 'verified' : 'revoked',
    confidence,
    timestamp: Date.now(),
    issuer: 'audit',
    data: {
      regulation,
      compliant: compliant.toString(),
      details
    }
  };

  const hash = computeBadgeHash(badge);
  const chainHash = computeChainHash(hash);
  
  return { ...badge, hash, chainHash };
}

// ============================================================
// FLAGS (Warnings/Errors)
// ============================================================

let flagCounter = 0;

export function createFlag(
  type: FlagType,
  severity: FlagSeverity,
  message: string
): Flag {
  flagCounter++;
  const id = `flag-${Date.now()}-${flagCounter}`;
  const hash = hashToHex(fnv1a(`${id}:${type}:${severity}:${message}`, 64), 64);
  
  return {
    id,
    type,
    severity,
    message,
    hash,
    timestamp: Date.now(),
    resolved: false
  };
}

export function resolveFlag(flag: Flag, resolution: string): Flag {
  const resolutionHash = hashToHex(fnv1a(`${flag.hash}:${resolution}`, 64), 64);
  return {
    ...flag,
    resolved: true,
    resolution,
    resolutionHash
  };
}

// ============================================================
// BADGE REGISTRY
// ============================================================

export class BadgeRegistry {
  private badges: Badge[] = [];
  private flags: Flag[] = [];

  addBadge(badge: Badge): void {
    this.badges.push(badge);
  }

  addFlag(flag: Flag): void {
    this.flags.push(flag);
  }

  getBadges(scope?: BadgeScope): Badge[] {
    if (scope) return this.badges.filter(b => b.scope === scope);
    return [...this.badges];
  }

  getFlags(activeOnly: boolean = true): Flag[] {
    if (activeOnly) return this.flags.filter(f => !f.resolved);
    return [...this.flags];
  }

  verifyBadge(badge: Badge): boolean {
    const expectedHash = computeBadgeHash(badge);
    return expectedHash === badge.hash;
  }

  getSystemHealth(): { badges: number; flags: number; integrity: number } {
    const verifiedBadges = this.badges.filter(b => b.level === 'verified').length;
    const activeFlags = this.flags.filter(f => !f.resolved).length;
    const integrity = this.badges.length > 0 
      ? verifiedBadges / this.badges.length 
      : 1.0;
    
    return {
      badges: this.badges.length,
      flags: activeFlags,
      integrity
    };
  }

  getAllHashes(): string {
    const allHashes = [
      ...this.badges.map(b => b.hash),
      ...this.flags.map(f => f.hash)
    ].join(':');
    return hashToHex(fnv1a(allHashes, 64), 64);
  }
}

// Global registry
export const globalRegistry = new BadgeRegistry();

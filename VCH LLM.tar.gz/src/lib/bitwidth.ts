/**
 * Universal Bit-Width Fixed-Point Library
 * ========================================
 * Works on ANY bit width: 8, 16, 32, 64, 128, 256
 * ZERO floating-point in computation.
 * VCH Compliant: Deterministic, Conservative, Honest.
 * 
 * The key insight: fixed-point is just integer math with an
 * implicit decimal point. The "bit width" just determines
 * how many bits you have for integer vs fractional parts.
 */

// ============================================================
// BIT WIDTH CONFIGURATION
// ============================================================

export type BitWidth = 8 | 16 | 32 | 64 | 128 | 256;

export interface FixedConfig {
  totalBits: BitWidth;
  integerBits: number;
  fractionalBits: number;
  scale: bigint;
  maxValue: bigint;
  minValue: bigint;
  mask: bigint;
}

// Pre-computed configs for each bit width
// Using BigInt throughout — BigInt IS integer math, not float
const configs: Record<BitWidth, FixedConfig> = {
  8: {
    totalBits: 8, integerBits: 4, fractionalBits: 4,
    scale: 16n, maxValue: 127n, minValue: -128n, mask: 0xFFn
  },
  16: {
    totalBits: 16, integerBits: 8, fractionalBits: 8,
    scale: 256n, maxValue: 32767n, minValue: -32768n, mask: 0xFFFFn
  },
  32: {
    totalBits: 32, integerBits: 16, fractionalBits: 16,
    scale: 65536n, maxValue: 2147483647n, minValue: -2147483648n, mask: 0xFFFFFFFFn
  },
  64: {
    totalBits: 64, integerBits: 32, fractionalBits: 32,
    scale: 4294967296n, maxValue: 9223372036854775807n, minValue: -9223372036854775808n, mask: 0xFFFFFFFFFFFFFFFFn
  },
  128: {
    totalBits: 128, integerBits: 64, fractionalBits: 64,
    scale: 18446744073709551616n,
    maxValue: (1n << 127n) - 1n,
    minValue: -(1n << 127n),
    mask: (1n << 128n) - 1n
  },
  256: {
    totalBits: 256, integerBits: 128, fractionalBits: 128,
    scale: 1n << 128n,
    maxValue: (1n << 255n) - 1n,
    minValue: -(1n << 255n),
    mask: (1n << 256n) - 1n
  }
};

export function getConfig(bits: BitWidth): FixedConfig {
  return configs[bits];
}

// ============================================================
// UNIVERSAL FIXED-POINT TYPE
// ============================================================

/**
 * A fixed-point number that works at any bit width.
 * Internally stored as BigInt (pure integer).
 */
export class Fixed {
  readonly raw: bigint;
  readonly config: FixedConfig;

  constructor(raw: bigint, bits: BitWidth = 32) {
    this.config = configs[bits];
    // Clamp to valid range
    if (raw > this.config.maxValue) raw = this.config.maxValue;
    if (raw < this.config.minValue) raw = this.config.minValue;
    this.raw = raw;
  }

  // --- Creation ---
  static fromReal(value: number, bits: BitWidth = 32): Fixed {
    const cfg = configs[bits];
    // Use integer rounding only — multiply then round
    const scaled = BigInt(Math.round(value * Number(cfg.scale)));
    return new Fixed(scaled, bits);
  }

  static fromBigInt(raw: bigint, bits: BitWidth = 32): Fixed {
    return new Fixed(raw, bits);
  }

  static zero(bits: BitWidth = 32): Fixed {
    return new Fixed(0n, bits);
  }

  static one(bits: BitWidth = 32): Fixed {
    return new Fixed(configs[bits].scale, bits);
  }

  static half(bits: BitWidth = 32): Fixed {
    return new Fixed(configs[bits].scale >> 1n, bits);
  }

  // --- Conversion ---
  toReal(): number {
    return Number(this.raw) / Number(this.config.scale);
  }

  toBigInt(): bigint {
    return this.raw;
  }

  /**
   * Convert to different bit width
   * This is a PROVEN operation: just rescale the integer
   */
  toBitWidth(targetBits: BitWidth): Fixed {
    const srcScale = this.config.scale;
    const dstScale = configs[targetBits].scale;
    
    let newRaw: bigint;
    if (dstScale > srcScale) {
      // Upscaling: multiply
      const ratio = dstScale / srcScale;
      newRaw = this.raw * ratio;
    } else if (dstScale < srcScale) {
      // Downscaling: divide (lose precision, conservative)
      const ratio = srcScale / dstScale;
      newRaw = this.raw / ratio;
    } else {
      newRaw = this.raw;
    }
    
    return new Fixed(newRaw, targetBits);
  }

  // --- Arithmetic (all integer-only) ---
  add(other: Fixed): Fixed {
    this.assertSameWidth(other);
    return new Fixed(this.raw + other.raw, this.config.totalBits);
  }

  sub(other: Fixed): Fixed {
    this.assertSameWidth(other);
    return new Fixed(this.raw - other.raw, this.config.totalBits);
  }

  mul(other: Fixed): Fixed {
    this.assertSameWidth(other);
    // Integer multiply then shift right by fractional bits
    const product = this.raw * other.raw;
    const result = product >> BigInt(this.config.fractionalBits);
    return new Fixed(result, this.config.totalBits);
  }

  div(other: Fixed): Fixed {
    this.assertSameWidth(other);
    if (other.raw === 0n) throw new Error('VCH: Division by zero — undefined');
    // Shift left then integer divide
    const scaled = this.raw << BigInt(this.config.fractionalBits);
    const result = scaled / other.raw;
    return new Fixed(result, this.config.totalBits);
  }

  // --- Comparison (all integer) ---
  min(other: Fixed): Fixed {
    this.assertSameWidth(other);
    return this.raw <= other.raw ? this : other;
  }

  max(other: Fixed): Fixed {
    this.assertSameWidth(other);
    return this.raw >= other.raw ? this : other;
  }

  abs(): Fixed {
    return this.raw < 0n ? new Fixed(-this.raw, this.config.totalBits) : this;
  }

  neg(): Fixed {
    return new Fixed(-this.raw, this.config.totalBits);
  }

  lte(other: Fixed): boolean {
    return this.raw <= other.raw;
  }

  gte(other: Fixed): boolean {
    return this.raw >= other.raw;
  }

  eq(other: Fixed): boolean {
    return this.raw === other.raw;
  }

  lt(other: Fixed): boolean {
    return this.raw < other.raw;
  }

  gt(other: Fixed): boolean {
    return this.raw > other.raw;
  }

  isZero(): boolean {
    return this.raw === 0n;
  }

  isPositive(): boolean {
    return this.raw > 0n;
  }

  isNegative(): boolean {
    return this.raw < 0n;
  }

  // --- Clamp ---
  clamp(low: Fixed, high: Fixed): Fixed {
    return this.min(high).max(low);
  }

  clamp01(): Fixed {
    return this.clamp(Fixed.zero(this.config.totalBits), Fixed.one(this.config.totalBits));
  }

  // --- Integer Square Root (Newton's method, integer-only) ---
  sqrt(): Fixed {
    if (this.raw < 0n) throw new Error('VCH: sqrt of negative — undefined in reals');
    if (this.raw === 0n) return Fixed.zero(this.config.totalBits);

    // Scale up by fractional bits for precision
    const scaled = this.raw << BigInt(this.config.fractionalBits);
    let x = scaled;
    const two = 2n;

    for (let i = 0; i < 64; i++) {
      const newX = (x + scaled / x) / two;
      if (newX === x || newX === x - 1n || newX === x + 1n) break;
      x = newX;
    }

    return new Fixed(x, this.config.totalBits);
  }

  // --- Display ---
  format(decimals: number = 4): string {
    return this.toReal().toFixed(decimals);
  }

  toString(): string {
    return `Fixed(${this.format()}, raw=${this.raw}, ${this.config.totalBits}bit)`;
  }

  // --- Internal ---
  private assertSameWidth(other: Fixed): void {
    if (this.config.totalBits !== other.config.totalBits) {
      throw new Error(`VCH: Bit width mismatch: ${this.config.totalBits} vs ${other.config.totalBits}`);
    }
  }
}

// ============================================================
// CONVENIENCE FUNCTIONS
// ============================================================

export const fp = (value: number, bits: BitWidth = 32) => Fixed.fromReal(value, bits);
export const fpZero = (bits: BitWidth = 32) => Fixed.zero(bits);
export const fpOne = (bits: BitWidth = 32) => Fixed.one(bits);
export const fpHalf = (bits: BitWidth = 32) => Fixed.half(bits);

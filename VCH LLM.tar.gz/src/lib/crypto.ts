/**
 * Cryptographic Hashing Library (Integer-Only)
 * =============================================
 * FNV-1a hash variant using BigInt (pure integer math)
 * Deterministic. No floats. No backdoors. VCH Compliant.
 * 
 * Used for: Badge verification, audit trails, integrity checks
 * 
 * FNV-1a is chosen because:
 * 1. Simple integer operations only (XOR + multiply)
 * 2. Proven distribution properties
 * 3. Deterministic across all platforms
 * 4. No floating-point anywhere
 */

import { Fixed, BitWidth } from './bitwidth';

// FNV-1a constants (proven, published, open standard)
// FNV offset basis for different bit widths
const FNV_OFFSET_BASIS: Record<BitWidth, bigint> = {
  8: 2166136261n & 0xFFn,
  16: 2166136261n & 0xFFFFn,
  32: 2166136261n,
  64: 14695981039346656037n,
  128: 14695981039346656037n, // Extended
  256: 14695981039346656037n  // Extended
};

// FNV prime for different bit widths
const FNV_PRIME: Record<BitWidth, bigint> = {
  8: 16777619n & 0xFFn,
  16: 16777619n & 0xFFFFn,
  32: 16777619n,
  64: 1099511628211n,
  128: 1099511628211n,
  256: 1099511628211n
};

const BIT_MASK: Record<BitWidth, bigint> = {
  8: 0xFFn,
  16: 0xFFFFn,
  32: 0xFFFFFFFFn,
  64: 0xFFFFFFFFFFFFFFFFn,
  128: (1n << 128n) - 1n,
  256: (1n << 256n) - 1n
};

/**
 * FNV-1a Hash (integer-only, deterministic)
 * 
 * Algorithm:
 *   hash = offset_basis
 *   for each byte in input:
 *     hash = hash XOR byte
 *     hash = hash * prime
 *     hash = hash mod 2^bits
 * 
 * This is a PROVEN algorithm — published in 1991 by Glenn Fowler,
 * Landon Curt Noll, and K. Phong Vo.
 */
export function fnv1a(input: string, bits: BitWidth = 64): bigint {
  const mask = BIT_MASK[bits];
  let hash = FNV_OFFSET_BASIS[bits];
  const prime = FNV_PRIME[bits];

  // Convert string to bytes (UTF-8)
  const encoder = new TextEncoder();
  const bytes = encoder.encode(input);

  for (let i = 0; i < bytes.length; i++) {
    // XOR with byte
    hash = hash ^ BigInt(bytes[i]);
    // Multiply by prime
    hash = (hash * prime) & mask;
  }

  return hash;
}

/**
 * Double hash for stronger verification
 * Hash the hash — adds collision resistance
 */
export function fnv1aDouble(input: string, bits: BitWidth = 64): bigint {
  const first = fnv1a(input, bits);
  return fnv1a(first.toString(), bits);
}

/**
 * Hash a Fixed-point value
 * Converts the raw BigInt to string and hashes it
 */
export function hashFixed(value: Fixed, bits: BitWidth = 64): bigint {
  const input = `${value.toBigInt()}:${value.config.totalBits}`;
  return fnv1a(input, bits);
}

/**
 * Hash multiple values together (order matters)
 * Creates a composite hash for verification chains
 */
export function hashChain(values: string[], bits: BitWidth = 64): bigint {
  let combined = '';
  for (const v of values) {
    combined += v + '|';
  }
  return fnv1a(combined, bits);
}

/**
 * Hash a timestamp + data for audit trail
 * Ensures temporal ordering is verifiable
 */
export function hashTimestamped(data: string, timestamp: number, bits: BitWidth = 64): bigint {
  return fnv1a(`${timestamp}:${data}`, bits);
}

/**
 * Convert hash to hex string for display
 */
export function hashToHex(hash: bigint, bits: BitWidth = 64): string {
  const hex = hash.toString(16);
  const targetLength = bits / 4; // bits / 4 = hex chars
  return hex.padStart(targetLength, '0');
}

/**
 * Verify that data matches a hash
 * Returns true if the hash matches — deterministic check
 */
export function verifyHash(data: string, expectedHash: bigint, bits: BitWidth = 64): boolean {
  const computed = fnv1a(data, bits);
  return computed === expectedHash;
}

/**
 * Create a verification token
 * Combines data + secret + timestamp for tamper detection
 */
export function createToken(data: string, secret: string, timestamp: number, bits: BitWidth = 64): string {
  const payload = `${data}:${secret}:${timestamp}`;
  const hash = fnv1a(payload, bits);
  return hashToHex(hash, bits);
}

/**
 * Verify a token
 */
export function verifyToken(data: string, secret: string, timestamp: number, token: string, bits: BitWidth = 64): boolean {
  const expected = createToken(data, secret, timestamp, bits);
  return expected === token;
}

/**
 * Simple checksum (faster than full hash, less secure)
 * XOR-fold the hash to a smaller size
 */
export function checksum(input: string, outputBits: number = 16): bigint {
  const fullHash = fnv1a(input, 64);
  const mask = (1n << BigInt(outputBits)) - 1n;
  
  // XOR-fold: fold 64 bits down to outputBits
  let result = 0n;
  let remaining = fullHash;
  const step = BigInt(outputBits);
  
  for (let i = 0n; i < 64n; i += step) {
    result = result ^ ((remaining >> i) & mask);
  }
  
  return result & mask;
}

/**
 * Fixed-Point Math Library
 * ========================
 * All arithmetic uses integer-only operations.
 * No floats. No doubles. No IEEE 754.
 * 
 * Format: Q16.16 (16-bit integer, 16-bit fractional)
 * Range: -32768.0 to +32767.99998...
 * Precision: 1/65536 ≈ 0.0000152587...
 * 
 * This is the foundation of the entire reasoning engine.
 */

// Fixed-point representation: 32-bit integer
// Upper 16 bits = integer part
// Lower 16 bits = fractional part
export type FixedPoint = number; // Stored as integer internally

// Scale factor: 2^16 = 65536
const SCALE = 65536;
const FRACTIONAL_BITS = 16;
const MAX_VALUE = 2147483647; // 2^31 - 1
const MIN_VALUE = -2147483648; // -2^31

/**
 * Convert a real number to fixed-point representation
 * Note: This conversion uses float, but only at the boundary.
 * All internal computations remain fixed-point.
 */
export function toFixed(real: number): FixedPoint {
  return Math.round(real * SCALE);
}

/**
 * Convert fixed-point back to real number (for display only)
 */
export function toReal(fp: FixedPoint): number {
  return fp / SCALE;
}

/**
 * Fixed-point addition: a + b
 */
export function fpAdd(a: FixedPoint, b: FixedPoint): FixedPoint {
  const result = a + b;
  if (result > MAX_VALUE || result < MIN_VALUE) {
    throw new Error('Fixed-point overflow in addition');
  }
  return result;
}

/**
 * Fixed-point subtraction: a - b
 */
export function fpSub(a: FixedPoint, b: FixedPoint): FixedPoint {
  const result = a - b;
  if (result > MAX_VALUE || result < MIN_VALUE) {
    throw new Error('Fixed-point underflow in subtraction');
  }
  return result;
}

/**
 * Fixed-point multiplication: a * b
 * Uses 64-bit intermediate to prevent overflow
 */
export function fpMul(a: FixedPoint, b: FixedPoint): FixedPoint {
  // Use BigInt for 64-bit intermediate calculation
  const aBig = BigInt(a);
  const bBig = BigInt(b);
  const product = (aBig * bBig) >> BigInt(FRACTIONAL_BITS);
  
  if (product > BigInt(MAX_VALUE) || product < BigInt(MIN_VALUE)) {
    throw new Error('Fixed-point overflow in multiplication');
  }
  return Number(product);
}

/**
 * Fixed-point division: a / b
 */
export function fpDiv(a: FixedPoint, b: FixedPoint): FixedPoint {
  if (b === 0) {
    throw new Error('Fixed-point division by zero');
  }
  const aBig = BigInt(a);
  const bBig = BigInt(b);
  const scaled = (aBig << BigInt(FRACTIONAL_BITS)) / bBig;
  
  if (scaled > BigInt(MAX_VALUE) || scaled < BigInt(MIN_VALUE)) {
    throw new Error('Fixed-point overflow in division');
  }
  return Number(scaled);
}

/**
 * Fixed-point minimum: min(a, b)
 * Core operation for the reasoning formula ψ = min(ω_logic, ω_evidence)
 */
export function fpMin(a: FixedPoint, b: FixedPoint): FixedPoint {
  return a < b ? a : b;
}

/**
 * Fixed-point maximum: max(a, b)
 */
export function fpMax(a: FixedPoint, b: FixedPoint): FixedPoint {
  return a > b ? a : b;
}

/**
 * Fixed-point absolute value
 */
export function fpAbs(a: FixedPoint): FixedPoint {
  return a < 0 ? -a : a;
}

/**
 * Fixed-point comparison: a <= b
 */
export function fpLte(a: FixedPoint, b: FixedPoint): boolean {
  return a <= b;
}

/**
 * Fixed-point comparison: a >= b
 */
export function fpGte(a: FixedPoint, b: FixedPoint): boolean {
  return a >= b;
}

/**
 * Fixed-point comparison: a == b
 */
export function fpEq(a: FixedPoint, b: FixedPoint): boolean {
  return a === b;
}

/**
 * Fixed-point square root (integer-only, Newton's method)
 * Uses only integer arithmetic internally
 */
export function fpSqrt(a: FixedPoint): FixedPoint {
  if (a < 0) throw new Error('Fixed-point sqrt of negative number');
  if (a === 0) return 0;
  
  // Newton's method in fixed-point
  // sqrt(a) where a is in Q16.16
  // We need to find x such that x*x = a
  // x_new = (x + a/x) / 2
  
  let x = a; // Initial guess
  const two = toFixed(2);
  
  for (let i = 0; i < 32; i++) {
    const ax = fpDiv(a, x);
    const sum = fpAdd(x, ax);
    const newX = fpDiv(sum, two);
    
    if (fpAbs(fpSub(newX, x)) <= 1) break; // Converged
    x = newX;
  }
  
  return x;
}

/**
 * Fixed-point clamp: clamp(value, min, max)
 */
export function fpClamp(value: FixedPoint, min: FixedPoint, max: FixedPoint): FixedPoint {
  if (value < min) return min;
  if (value > max) return max;
  return value;
}

/**
 * Fixed-point average: (a + b) / 2
 */
export function fpAvg(a: FixedPoint, b: FixedPoint): FixedPoint {
  return fpDiv(fpAdd(a, b), toFixed(2));
}

/**
 * Format fixed-point for display
 */
export function fpFormat(fp: FixedPoint, decimals: number = 4): string {
  const real = toReal(fp);
  return real.toFixed(decimals);
}

/**
 * Fixed-point integer representation (for display of raw value)
 */
export function fpRaw(fp: FixedPoint): string {
  return fp.toString();
}

// Constants
export const FP_ZERO = 0;
export const FP_ONE = SCALE; // 1.0
export const FP_HALF = SCALE >> 1; // 0.5
export const FP_TWO = SCALE << 1; // 2.0

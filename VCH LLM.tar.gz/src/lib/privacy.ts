/**
 * Privacy & Audit Trail System
 * =============================
 * 
 * Privacy: Private data separate from public data.
 * Audit: Every action recorded, hashed, verifiable.
 * Failsafe: Both humans AND AI can audit.
 * 
 * VCH Compliant: Conservative, Honest, Transparent.
 * Privacy-preserving by design.
 */

import { Fixed, BitWidth, fp } from './bitwidth';
import { fnv1a, hashToHex, hashTimestamped } from './crypto';
import { createPrivacyBadge, createFlag, globalRegistry } from './badges';

// ============================================================
// PRIVACY LAYER
// ============================================================

export type DataClassification = 'public' | 'internal' | 'private' | 'secret';

export interface PrivateData {
  id: string;
  classification: DataClassification;
  content: string;          // The actual data
  owner: string;            // Who owns this data
  hash: string;             // Hash of content (never store raw in logs)
  timestamp: number;
  accessLog: AccessEntry[];
}

export interface AccessEntry {
  accessor: string;         // Who accessed it
  timestamp: number;
  purpose: string;
  hash: string;
  authorized: boolean;
}

/**
 * Privacy rule: Private data stays private.
 * Only the owner can authorize access.
 * All access is logged and hashed.
 */
export function accessPrivateData(
  data: PrivateData,
  accessor: string,
  purpose: string
): { allowed: boolean; reason: string; entry: AccessEntry } {
  const isOwner = accessor === data.owner;
  const isSystem = accessor === 'system';
  
  const allowed = isOwner || (isSystem && data.classification === 'internal');
  const reason = allowed 
    ? 'Access granted — authorized' 
    : `Access denied — ${isOwner ? '' : 'not owner, '}${data.classification} data requires owner authorization`;
  
  const entry: AccessEntry = {
    accessor,
    timestamp: Date.now(),
    purpose,
    hash: hashToHex(fnv1a(`${data.hash}:${accessor}:${purpose}:${Date.now()}`, 64), 64),
    authorized: allowed
  };
  
  // Log access attempt (even denied ones — transparency)
  data.accessLog.push(entry);
  
  // Create privacy badge
  const badge = createPrivacyBadge(
    `Access: ${accessor} → ${data.id}`,
    allowed,
    reason
  );
  globalRegistry.addBadge(badge);
  
  // Flag unauthorized access
  if (!allowed) {
    const flag = createFlag('privacy', 'warning', `Unauthorized access attempt: ${accessor} → ${data.id}`);
    globalRegistry.addFlag(flag);
  }
  
  return { allowed, reason, entry };
}

/**
 * Create private data with proper classification
 */
export function createPrivateData(
  content: string,
  classification: DataClassification,
  owner: string
): PrivateData {
  const id = `data-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  const hash = hashToHex(fnv1a(`${content}:${owner}:${classification}`, 64), 64);
  
  return {
    id,
    classification,
    content,
    owner,
    hash,
    timestamp: Date.now(),
    accessLog: []
  };
}

/**
 * Public view of private data — only metadata, never content
 */
export function publicView(data: PrivateData): { id: string; classification: string; owner: string; hash: string; timestamp: number } {
  return {
    id: data.id,
    classification: data.classification,
    owner: data.owner,
    hash: data.hash,
    timestamp: data.timestamp
  };
}

// ============================================================
// AUDIT TRAIL
// ============================================================

export type AuditAction = 
  | 'reasoning'     // A reasoning operation was performed
  | 'judgment'      // A claim was judged
  | 'access'        // Data was accessed
  | 'badge_issued'  // A badge was issued
  | 'flag_raised'   // A flag was raised
  | 'config_change' // System configuration changed
  | 'human_audit';  // A human audited the system

export interface AuditEntry {
  id: string;
  action: AuditAction;
  actor: 'human' | 'ai' | 'system';
  description: string;
  data: Record<string, string>;
  hash: string;
  previousHash: string;  // Chain to previous entry
  timestamp: number;
  verifiable: boolean;
}

let auditCounter = 0;
let lastAuditHash = '0000000000000000';

/**
 * Record an audit entry
 * Every action in the system is recorded.
 * Entries are chained (like a blockchain) for tamper detection.
 */
export function audit(
  action: AuditAction,
  actor: 'human' | 'ai' | 'system',
  description: string,
  data: Record<string, string> = {}
): AuditEntry {
  auditCounter++;
  const id = `audit-${Date.now()}-${auditCounter}`;
  
  const payload = `${id}:${action}:${actor}:${description}:${JSON.stringify(data)}:${Date.now()}`;
  const hash = hashToHex(fnv1a(payload, 64), 64);
  const previousHash = lastAuditHash;
  lastAuditHash = hash;
  
  const entry: AuditEntry = {
    id,
    action,
    actor,
    description,
    data,
    hash,
    previousHash,
    timestamp: Date.now(),
    verifiable: true
  };
  
  return entry;
}

/**
 * Verify an audit chain — check that no entries were tampered with
 */
export function verifyAuditChain(entries: AuditEntry[]): { valid: boolean; brokenAt?: number } {
  for (let i = 1; i < entries.length; i++) {
    if (entries[i].previousHash !== entries[i - 1].hash) {
      return { valid: false, brokenAt: i };
    }
  }
  return { valid: true };
}

// ============================================================
// HUMAN-AI FAILSAFE
// ============================================================

/**
 * Human audit request — a human can request to audit any action
 */
export function requestHumanAudit(
  entry: AuditEntry,
  auditor: string
): { requestHash: string; status: string } {
  const requestHash = hashToHex(fnv1a(`${entry.hash}:${auditor}:${Date.now()}`, 64), 64);
  
  const auditEntry = audit('human_audit', 'human', `Human audit requested by ${auditor}`, {
    targetEntry: entry.id,
    requestHash
  });
  
  return {
    requestHash,
    status: `Audit request logged. Entry ${entry.id} queued for human review.`
  };
}

/**
 * AI self-audit — the system checks itself
 */
export function aiSelfAudit(entries: AuditEntry[]): { 
  passed: boolean; 
  issues: string[];
  integrityScore: Fixed;
} {
  const issues: string[] = [];
  
  // Check chain integrity
  const chainResult = verifyAuditChain(entries);
  if (!chainResult.valid) {
    issues.push(`Audit chain broken at entry ${chainResult.brokenAt}`);
  }
  
  // Check for unauthorized access
  const unauthorized = entries.filter(e => 
    e.action === 'access' && e.data['authorized'] === 'false'
  );
  if (unauthorized.length > 0) {
    issues.push(`${unauthorized.length} unauthorized access attempts detected`);
  }
  
  // Check for unresolved flags
  const activeFlags = globalRegistry.getFlags(true);
  if (activeFlags.length > 0) {
    issues.push(`${activeFlags.length} unresolved flags`);
  }
  
  // Calculate integrity score (conservative)
  const totalChecks = 3;
  const passedChecks = totalChecks - issues.length;
  const integrityScore = fp(Math.max(0, passedChecks / totalChecks));
  
  return {
    passed: issues.length === 0,
    issues,
    integrityScore
  };
}

// ============================================================
// AUDIT LOG (in-memory for demo)
// ============================================================

export class AuditLog {
  private entries: AuditEntry[] = [];

  record(entry: AuditEntry): void {
    this.entries.push(entry);
  }

  getAll(): AuditEntry[] {
    return [...this.entries];
  }

  getByAction(action: AuditAction): AuditEntry[] {
    return this.entries.filter(e => e.action === action);
  }

  verify(): { valid: boolean; brokenAt?: number } {
    return verifyAuditChain(this.entries);
  }

  getSummary(): { total: number; byActor: Record<string, number>; byAction: Record<string, number> } {
    const byActor: Record<string, number> = {};
    const byAction: Record<string, number> = {};
    
    for (const entry of this.entries) {
      byActor[entry.actor] = (byActor[entry.actor] || 0) + 1;
      byAction[entry.action] = (byAction[entry.action] || 0) + 1;
    }
    
    return { total: this.entries.length, byActor, byAction };
  }
}

export const globalAuditLog = new AuditLog();

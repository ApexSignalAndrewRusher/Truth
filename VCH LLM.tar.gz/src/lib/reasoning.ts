/**
 * Scientific Reasoning Engine
 * ===========================
 * Core formula: ψ = min(ω_logic, ω_evidence)
 * 
 * Where:
 *   ψ (psi) = Reasoning confidence score
 *   ω_logic (omega_logic) = Logical consistency weight
 *   ω_evidence (omega_evidence) = Empirical evidence weight
 * 
 * Deductive Reasoning constraint:
 *   ψ ≤ min(ω_logic, ω_evidence)
 *   (Deductive reasoning cannot exceed the minimum of its inputs)
 * 
 * This engine uses ONLY fixed-point arithmetic.
 * No floating-point operations anywhere.
 */

import {
  FixedPoint, toFixed, toReal, fpAdd, fpSub, fpMul, fpDiv,
  fpMin, fpMax, fpClamp, fpFormat, fpSqrt, fpAbs, fpAvg,
  FP_ZERO, FP_ONE, FP_HALF
} from './fixedpoint';

/**
 * Axiom: A provable statement from math, biology, or physics
 */
export interface Axiom {
  id: string;
  domain: 'math' | 'biology' | 'physics';
  statement: string;
  proofLevel: FixedPoint; // 0.0 to 1.0 - how rigorously proven
  evidenceWeight: FixedPoint; // 0.0 to 1.0 - empirical support
  logicalConsistency: FixedPoint; // 0.0 to 1.0 - internal consistency
  source: string;
}

/**
 * Proposition: A derived statement built from axioms
 */
export interface Proposition {
  id: string;
  statement: string;
  derivedFrom: string[]; // IDs of axioms/other propositions
  reasoningType: 'deductive' | 'inductive' | 'abductive';
  confidence: FixedPoint;
}

/**
 * Reasoning Chain: A sequence of logical steps
 */
export interface ReasoningChain {
  steps: ReasoningStep[];
  finalConfidence: FixedPoint;
  valid: boolean;
}

export interface ReasoningStep {
  stepNumber: number;
  operation: string;
  inputWeights: { logic: FixedPoint; evidence: FixedPoint };
  outputPsi: FixedPoint;
  rule: string;
}

/**
 * Core Scientific Reasoning Function
 * ψ = min(ω_logic, ω_evidence)
 * 
 * The confidence of any scientific claim is bounded by
 * the minimum of its logical consistency and empirical evidence.
 */
export function scientificReasoning(
  omegaLogic: FixedPoint,
  omegaEvidence: FixedPoint
): FixedPoint {
  return fpMin(omegaLogic, omegaEvidence);
}

/**
 * Deductive Reasoning Function
 * ψ ≤ min(ω_logic, ω_evidence)
 * 
 * In deductive reasoning, the conclusion's confidence
 * cannot exceed the minimum confidence of its premises.
 * This is the "weakest link" principle.
 */
export function deductiveReasoning(
  omegaLogic: FixedPoint,
  omegaEvidence: FixedPoint,
  premises: FixedPoint[]
): FixedPoint {
  // Find minimum premise confidence
  let minPremise = premises[0] || FP_ONE;
  for (let i = 1; i < premises.length; i++) {
    minPremise = fpMin(minPremise, premises[i]);
  }
  
  // ψ = min(min_premise, min(ω_logic, ω_evidence))
  const baseConfidence = scientificReasoning(omegaLogic, omegaEvidence);
  return fpMin(minPremise, baseConfidence);
}

/**
 * Evidence Accumulation
 * Multiple independent evidence sources strengthen confidence
 * Uses fixed-point probability combination:
 * P(combined) = 1 - Π(1 - P_i)
 */
export function accumulateEvidence(evidenceWeights: FixedPoint[]): FixedPoint {
  if (evidenceWeights.length === 0) return FP_ZERO;
  if (evidenceWeights.length === 1) return evidenceWeights[0];
  
  // Start with 1.0
  let product = FP_ONE;
  
  for (const weight of evidenceWeights) {
    // (1 - weight)
    const complement = fpSub(FP_ONE, weight);
    // product *= complement
    product = fpMul(product, complement);
  }
  
  // 1 - product
  return fpSub(FP_ONE, product);
}

/**
 * Logical Consistency Check
 * Verifies that a set of statements don't contradict each other
 * Returns a consistency score from 0.0 to 1.0
 */
export function checkConsistency(statements: { claim: string; negation: string }[]): FixedPoint {
  // Base consistency starts at 1.0 (perfect consistency)
  let consistency = FP_ONE;
  
  // Each potential contradiction reduces consistency
  // In a full implementation, this would use formal logic verification
  // Here we model it as: each unverified statement reduces confidence
  const penalty = fpDiv(FP_ONE, toFixed(statements.length + 1));
  
  for (let i = 0; i < statements.length; i++) {
    consistency = fpSub(consistency, fpDiv(penalty, toFixed(2)));
  }
  
  return fpClamp(consistency, FP_ZERO, FP_ONE);
}

/**
 * Build a reasoning chain from axioms to conclusion
 */
export function buildReasoningChain(axioms: Axiom[]): ReasoningChain {
  const steps: ReasoningStep[] = [];
  let currentPsi = FP_ONE;
  
  for (let i = 0; i < axioms.length; i++) {
    const axiom = axioms[i];
    
    // ψ_step = min(ω_logic, ω_evidence) for this axiom
    const stepPsi = scientificReasoning(axiom.logicalConsistency, axiom.evidenceWeight);
    
    // Chain confidence: min of all steps (deductive constraint)
    currentPsi = fpMin(currentPsi, stepPsi);
    
    steps.push({
      stepNumber: i + 1,
      operation: `Evaluate: ${axiom.statement}`,
      inputWeights: {
        logic: axiom.logicalConsistency,
        evidence: axiom.evidenceWeight
      },
      outputPsi: stepPsi,
      rule: 'ψ = min(ω_logic, ω_evidence)'
    });
  }
  
  return {
    steps,
    finalConfidence: currentPsi,
    valid: currentPsi > FP_ZERO
  };
}

/**
 * Cross-domain reasoning: Combine math + biology + physics
 * Each domain contributes evidence, logic is the intersection
 */
export function crossDomainReasoning(
  mathEvidence: FixedPoint,
  biologyEvidence: FixedPoint,
  physicsEvidence: FixedPoint,
  logicalConsistency: FixedPoint
): FixedPoint {
  // Combined evidence from all domains
  const combinedEvidence = accumulateEvidence([mathEvidence, biologyEvidence, physicsEvidence]);
  
  // Final confidence: min of combined evidence and logical consistency
  return scientificReasoning(logicalConsistency, combinedEvidence);
}

// ===== Pre-loaded Axioms =====

export const MATHEMATICS_AXIOMS: Axiom[] = [
  {
    id: 'math-001',
    domain: 'math',
    statement: 'Peano axioms define natural numbers uniquely',
    proofLevel: toFixed(1.0),
    evidenceWeight: toFixed(1.0),
    logicalConsistency: toFixed(1.0),
    source: 'Formal proof - ZFC set theory'
  },
  {
    id: 'math-002',
    domain: 'math',
    statement: 'Prime number theorem: π(x) ~ x/ln(x)',
    proofLevel: toFixed(1.0),
    evidenceWeight: toFixed(0.95),
    logicalConsistency: toFixed(1.0),
    source: 'Hadamard & de la Vallée-Poussin, 1896'
  },
  {
    id: 'math-003',
    domain: 'math',
    statement: 'Gödel completeness theorem holds for first-order logic',
    proofLevel: toFixed(1.0),
    evidenceWeight: toFixed(1.0),
    logicalConsistency: toFixed(1.0),
    source: 'Gödel, 1930 - formal proof'
  }
];

export const BIOLOGY_AXIOMS: Axiom[] = [
  {
    id: 'bio-001',
    domain: 'biology',
    statement: 'DNA encodes hereditary information via base-pair complementarity',
    proofLevel: toFixed(0.98),
    evidenceWeight: toFixed(0.99),
    logicalConsistency: toFixed(0.97),
    source: 'Watson-Crick model, verified by X-ray crystallography'
  },
  {
    id: 'bio-002',
    domain: 'biology',
    statement: 'Natural selection acts on heritable variation',
    proofLevel: toFixed(0.95),
    evidenceWeight: toFixed(0.97),
    logicalConsistency: toFixed(0.93),
    source: 'Darwin/Wallace, verified by population genetics'
  },
  {
    id: 'bio-003',
    domain: 'biology',
    statement: 'ATP is the primary energy currency of cells',
    proofLevel: toFixed(0.96),
    evidenceWeight: toFixed(0.98),
    logicalConsistency: toFixed(0.95),
    source: 'Lipmann, 1941 - biochemical evidence'
  }
];

export const PHYSICS_AXIOMS: Axiom[] = [
  {
    id: 'phys-001',
    domain: 'physics',
    statement: 'Energy is conserved in closed systems (Noether\'s theorem)',
    proofLevel: toFixed(1.0),
    evidenceWeight: toFixed(0.99),
    logicalConsistency: toFixed(1.0),
    source: 'Noether, 1918 - mathematical proof from time-translation symmetry'
  },
  {
    id: 'phys-002',
    domain: 'physics',
    statement: 'Speed of light in vacuum is invariant (c = 299,792,458 m/s)',
    proofLevel: toFixed(1.0),
    evidenceWeight: toFixed(1.0),
    logicalConsistency: toFixed(1.0),
    source: 'Einstein, 1905 - verified by Michelson-Morley and countless experiments'
  },
  {
    id: 'phys-003',
    domain: 'physics',
    statement: 'Entropy of isolated system never decreases (2nd law)',
    proofLevel: toFixed(0.97),
    evidenceWeight: toFixed(0.99),
    logicalConsistency: toFixed(0.96),
    source: 'Clausius/Boltzmann - statistical mechanics proof'
  }
];

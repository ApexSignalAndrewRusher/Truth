// Badge.ts - TRUE INTEGER AUDIT TRAIL (NO FLOATS)
import { createHash } from 'crypto';
// Module-level environment check
if (typeof process === 'undefined' || !process.hrtime?.bigint) {
  throw new Error('VCH: Node.js with process.hrtime.bigint required');
}
export enum BadgeScope { INTERNAL = 'INTERNAL', EXTERNAL = 'EXTERNAL' }
export enum BadgeType { LOGIC = 'LOGIC', EVIDENCE = 'EVIDENCE', INTEGRITY = 'INTEGRITY', ERROR = 'ERROR' }
export interface Badge {
  readonly id: string;
  readonly scope: BadgeScope;
  readonly type: BadgeType;
  readonly message: string;
  readonly timestampNs: string; // TRUE INTEGER - no float contamination
  readonly psiValue: string; // Fixed-point string representation
  readonly psiRaw: string; // Raw bigint for visualizer
  readonly hash: string;
}
let _badgeLog: readonly Badge[] = [];
let badgeCounter = 0n;
export function emitBadge(scope: BadgeScope, type: BadgeType, message: string, psiFixed: Fixed): Readonly<Badge> {
  const id = `vch-badge-${badgeCounter.toString()}`;
  badgeCounter++;
  // TRUE INTEGER TIMESTAMP - NO FLOAT USAGE WHATSOEVER
  const timestampNs = process.hrtime.bigint(); // bigint nanoseconds - NO FLOAT DERIVATION
  const psiStr = psiFixed.toDecimalString();
  const psiRaw = psiFixed.getRaw().toString(); // Raw value for visualizer
  const content = `${id}|${scope}|${type}|${message}|${psiStr}|${psiRaw}|${timestampNs.toString()}`;
  const hash = createHash('sha256').update(content).digest('hex');
 
  const badge: Readonly<Badge> = Object.freeze({
    id,
    scope,
    type,
    message,
    timestampNs: timestampNs.toString(),
    psiValue: psiStr,
    psiRaw,
    hash
  });
 
  // Create new array and freeze it to maintain immutability
  _badgeLog = Object.freeze([..._badgeLog, badge]);
  return badge;
}
export function getAuditLog(): readonly Badge[] {
  return _badgeLog; // Return frozen array reference to prevent external mutation
}
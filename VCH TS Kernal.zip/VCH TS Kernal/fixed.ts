// Fixed.ts - Pure Fixed-Point Arithmetic (Q64.32) - TRUE INTEGER MATH
const SHIFT = 32n;
const FACTOR = 1n << SHIFT;
// Define exact bounds for Q64.32 (signed 64-bit integer part + 32-bit fractional)
const INT64_MIN = -0x8000000000000000n;
const INT64_MAX = 0x7FFFFFFFFFFFFFFFn;
const RAW_MIN = INT64_MIN * FACTOR;
const RAW_MAX = INT64_MAX * FACTOR + (FACTOR - 1n);
export class Fixed {
  readonly raw: bigint;
  private constructor(value: bigint) {
    if (value < RAW_MIN || value > RAW_MAX) {
      throw new Error('VCH: Value out of Q64.32 range');
    }
    this.raw = value;
  }
  // Create from integer part only (no fractional component)
  static fromInteger(integer: bigint): Fixed {
    if (integer < INT64_MIN || integer > INT64_MAX) {
      throw new Error('VCH: Integer out of Q64.32 range');
    }
    return new Fixed(integer * FACTOR);
  }
  // Create from integer and fractional parts (both integers)
  static fromIntegerAndFraction(intPart: bigint, fracPart: bigint): Fixed {
    if (fracPart < 0n || fracPart >= FACTOR) {
      throw new Error('VCH: Fractional part must be between 0 and FACTOR-1');
    }
   
    const integerComponent = intPart * FACTOR;
    const result = integerComponent + fracPart;
    return new Fixed(result);
  }
  // Parse from decimal string "X.Y" format - ONLY valid decimal numbers (NO FLOATS)
  static fromDecimalString(str: string): Fixed {
    // Strict validation: only ASCII digits, one optional decimal point, no scientific notation, no NaN/Infinity
    // Use [0-9] NOT \d to reject Unicode digits
    if (!/^-?[0-9]+(\.[0-9]+)?$/.test(str)) {
      throw new Error('VCH: Invalid decimal string format');
    }
    // Extract sign and work with unsigned parts for DOS protection
    const neg = str.startsWith('-');
    const unsigned = neg ? str.slice(1) : str;
    const parts = unsigned.split('.');
    const intPartStr = parts[0];
    const fracPartStr = parts[1] || '';
   
    // DOS prevention on UNSIGNED parts (max 19 digits for int64 magnitude)
    if (intPartStr.length > 19) {
      throw new Error('VCH: Integer part too long');
    }
    if (fracPartStr.length > 10) {
      throw new Error('VCH: Fractional part too long');
    }
    const intPart = BigInt(intPartStr);
    let fracPart = 0n;
    if (fracPartStr) {
      const fracInt = BigInt(fracPartStr);
      const divisor = 10n ** BigInt(fracPartStr.length);
      fracPart = (fracInt * FACTOR) / divisor;
    }
    const rawMagnitude = intPart * FACTOR + fracPart;
    const raw = neg ? -rawMagnitude : rawMagnitude;
    return new Fixed(raw);
  }
  // Arithmetic operations - ALL INTEGER MATH WITH BOUNDS CHECKING
  add(other: Fixed): Fixed {
    const result = this.raw + other.raw;
    if (result < RAW_MIN || result > RAW_MAX) {
      throw new Error('VCH: Addition overflow');
    }
    return new Fixed(result);
  }
  sub(other: Fixed): Fixed {
    const result = this.raw - other.raw;
    if (result < RAW_MIN || result > RAW_MAX) {
      throw new Error('VCH: Subtraction overflow');
    }
    return new Fixed(result);
  }
  mul(other: Fixed): Fixed {
    // Q64.32 * Q64.32 = Q128.64, then shift back to Q64.32
    const result = (this.raw * other.raw) / FACTOR;
    if (result < RAW_MIN || result > RAW_MAX) {
      throw new Error('VCH: Multiplication overflow');
    }
    return new Fixed(result);
  }
  div(other: Fixed): Fixed {
    if (other.raw === 0n) throw new Error('VCH: Division by zero');
    // Q64.32 / Q64.32 = Q64.32, multiply numerator by FACTOR first
    const result = (this.raw * FACTOR) / other.raw;
    if (result < RAW_MIN || result > RAW_MAX) {
      throw new Error('VCH: Division overflow');
    }
    return new Fixed(result);
  }
  // Comparison operations - ALL INTEGER MATH
  min(other: Fixed): Fixed {
    return this.raw < other.raw ? this : other;
  }
  max(other: Fixed): Fixed {
    return this.raw > other.raw ? this : other;
  }
  equals(other: Fixed): boolean {
    return this.raw === other.raw;
  }
  greaterThan(other: Fixed): boolean {
    return this.raw > other.raw;
  }
  greaterThanOrEqual(other: Fixed): boolean {
    return this.raw >= other.raw;
  }
  lessThan(other: Fixed): boolean {
    return this.raw < other.raw;
  }
  lessThanOrEqual(other: Fixed): boolean {
    return this.raw <= other.raw;
  }
  // Convert back to string for output (no float conversion)
  // Q32 provides ~9.6 decimal digits of true precision. maxDecimals up to 12 is permitted for formatting,
  // but digits beyond ~10 are not significant.
  toDecimalString(maxDecimals: bigint = 12n): string {
    if (maxDecimals < 0n || maxDecimals > 30n) throw new Error('VCH: maxDecimals must be bigint 0-30');
    if (!Number.isSafeInteger(Number(maxDecimals))) throw new Error('VCH: maxDecimals out of safe range');
    const maxDecNum = Number(maxDecimals);
    const neg = this.raw < 0n;
    const absRaw = neg ? -this.raw : this.raw;
    const integerPart = absRaw / FACTOR;
    const fracRaw = absRaw % FACTOR;
    if (maxDecimals === 0n || fracRaw === 0n) {
      return (neg ? '-' : '') + integerPart.toString();
    }
    const scale = 10n ** maxDecimals;
    let fracScaled = (fracRaw * scale) / FACTOR; // truncation
    let fracStr = fracScaled.toString().padStart(maxDecNum, '0');
    fracStr = fracStr.replace(/0+$/, ''); // trim trailing zeros
    if (fracStr.length === 0) {
      return (neg ? '-' : '') + integerPart.toString();
    }
    return `${neg ? '-' : ''}${integerPart.toString()}.${fracStr}`;
  }
  // For visualizer compatibility - return raw integer value
  getRaw(): bigint {
    return this.raw;
  }
  // For visualizer compatibility - create from raw integer
  static fromRaw(raw: bigint): Fixed {
    return new Fixed(raw);
  }
}
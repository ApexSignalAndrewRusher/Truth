// Kernel.ts - Main Processing Unit (TRUE FIXED-POINT)
import { Fixed } from './Fixed';
import { VCH } from './VCH';
import { emitBadge, BadgeScope, BadgeType } from './Badge';
export interface InputData {
  readonly query: string;
  readonly logicScore: string; // Decimal string "0.0" to "1.0"
  readonly evidenceScore: string; // Decimal string "0.0" to "1.0"
}
export class VCHKernel {
  process(input: InputData): { output: string; psiValue: string; psiRaw: string; timestampNs: string; success: boolean; badgeId?: string } {
    try {
      // Validate input strings first - NO FLOAT ACCEPTANCE
      const logicScoreFixed = Fixed.fromDecimalString(input.logicScore);
      const evidenceScoreFixed = Fixed.fromDecimalString(input.evidenceScore);
      // Verify scores are in valid range [0.0, 1.0]
      const zero = Fixed.fromDecimalString('0.0');
      const one = Fixed.fromDecimalString('1.0');
      if (logicScoreFixed.lessThan(zero) || logicScoreFixed.greaterThan(one)) {
        const badge = emitBadge(
          BadgeScope.EXTERNAL,
          BadgeType.ERROR,
          'Logic score out of range [0.0, 1.0]',
          zero // Zero psi for invalid input
        );
        return { output: 'ERROR: Invalid logic score', psiValue: '0.0', psiRaw: zero.getRaw().toString(), timestampNs: badge.timestampNs, success: false, badgeId: badge.id };
      }
      if (evidenceScoreFixed.lessThan(zero) || evidenceScoreFixed.greaterThan(one)) {
        const badge = emitBadge(
          BadgeScope.EXTERNAL,
          BadgeType.ERROR,
          'Evidence score out of range [0.0, 1.0]',
          zero // Zero psi for invalid input
        );
        return { output: 'ERROR: Invalid evidence score', psiValue: '0.0', psiRaw: zero.getRaw().toString(), timestampNs: badge.timestampNs, success: false, badgeId: badge.id };
      }
      // Calculate PSI using core VCH formula
      const psi = VCH.calculatePsi(logicScoreFixed, evidenceScoreFixed);
      // Validate against threshold
      const isValid = VCH.isValidDefault(psi);
      if (!isValid) {
        const badge = emitBadge(
          BadgeScope.EXTERNAL,
          BadgeType.INTEGRITY,
          'PSI below threshold',
          psi
        );
        return { output: 'REJECTED: Insufficient verification', psiValue: psi.toDecimalString(), psiRaw: psi.getRaw().toString(), timestampNs: badge.timestampNs, success: false, badgeId: badge.id };
      }
      // Process the query (example: simple transformation)
      const processedOutput = `VERIFIED: ${input.query.toUpperCase()}`;
      const badge = emitBadge(
        BadgeScope.EXTERNAL,
        BadgeType.LOGIC,
        'Successfully processed query with PSI',
        psi
      );
      return {
        output: processedOutput,
        psiValue: psi.toDecimalString(),
        psiRaw: psi.getRaw().toString(),
        timestampNs: badge.timestampNs,
        success: true,
        badgeId: badge.id
      };
    } catch (error) {
      // Catch any parsing/validation errors
      const badge = emitBadge(
        BadgeScope.EXTERNAL,
        BadgeType.ERROR,
        'Processing error',
        Fixed.fromDecimalString('0.0')
      );
     
      return {
        output: 'ERROR: Processing failed',
        psiValue: '0.0',
        psiRaw: Fixed.fromDecimalString('0.0').getRaw().toString(),
        timestampNs: badge.timestampNs,
        success: false,
        badgeId: badge.id
      };
    }
  }
}
// Example usage
const kernel = new VCHKernel();
// Valid inputs
const result1 = kernel.process({
  query: 'what is truth?',
  logicScore: '0.9',
  evidenceScore: '0.85'
});
console.log('Valid result:', result1);
// Invalid inputs (too high)
const result2 = kernel.process({
  query: 'fake query',
  logicScore: '1.5', // Invalid
  evidenceScore: '0.8'
});
console.log('Invalid result:', result2);
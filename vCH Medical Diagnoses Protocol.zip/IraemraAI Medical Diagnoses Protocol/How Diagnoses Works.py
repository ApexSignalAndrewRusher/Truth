How Diagnoses Works
import logging
logging.basicConfig(level=logging.INFO)

# -------------------------------------------------
# 1. Raw patient data
# -------------------------------------------------
patient_tests = {
    "blood_test": {"WBC": 12_300, "CRP": 48},
    "chest_xray": "image_id_789",
    "symptoms": "fever, productive cough, dyspnea",
}

# -------------------------------------------------
# 2. Initialise IRAEMA protocol
# -------------------------------------------------
protocol = IRAEMAProtocol(patient_id="P-98765", test_results=patient_tests, model_version="pneumo-v3")

# -------------------------------------------------
# 3. INTERPRET – AI inference
# -------------------------------------------------
ai_evidence = [
    Evidence(EvidenceType.LAB, "WBC", 12_300, "elevated"),
    Evidence(EvidenceType.LAB, "CRP", 48, "inflammatory marker"),
    Evidence(EvidenceType.IMAGING, "chest_xray", "consolidation left lower lobe", ""),
]
protocol.interpret(
    ai_diagnosis="Community-Acquired Pneumonia",
    confidence=0.92,
    evidence=ai_evidence,
    notes="CNN + lab classifier ensemble",
)

# -------------------------------------------------
# 4. REVIEW – Doctor (or second AI) review
# -------------------------------------------------
doc_evidence = [
    Evidence(EvidenceType.CLINICAL, "auscultation", "crackles left base", ""),
    Evidence(EvidenceType.IMAGING, "chest_xray", "same consolidation", ""),
]
protocol.review(
    reviewer_diagnosis="Community-Acquired Pneumonia",
    notes="Clinical correlation confirms AI finding",
    evidence=doc_evidence,
)

# -------------------------------------------------
# 5. AUDIT – automatic safety checks
# -------------------------------------------------
print("Audit flags:", protocol.audit())
# → []   (perfect match, high confidence)

# -------------------------------------------------
# 6. EXPLAIN – human-readable rationale
# -------------------------------------------------
ai_id = protocol.diagnoses[0].id
protocol.explain(
    diagnosis_id=ai_id,
    explanation=(
        "The model detected left-lower-lobe consolidation on the X-ray "
        "(probability 0.94) and correlated it with elevated WBC/CRP, "
        "yielding a final confidence of 0.92 for Community-Acquired Pneumonia."
    ),
)

# -------------------------------------------------
# 7. MONITOR – persist for QA / retraining
# -------------------------------------------------
summary = protocol.finalize_and_persist("patient_P-98765_iraema.json")
print(json.dumps(summary, indent=2)[:1000], "...")
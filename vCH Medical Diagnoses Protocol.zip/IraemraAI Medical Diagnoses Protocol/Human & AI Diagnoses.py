DOCTOR & AI DIAGNOSES PROTOCOL

from typing import List, Dict, Any, Optional
import datetime
import json
import uuid
import logging
from enum import Enum

# ----------------------------------------------------------------------
# Enums & Helper Types
# ----------------------------------------------------------------------
class Source(str, Enum):
    DOCTOR = "doctor"
    AI = "AI"

class EvidenceType(str, Enum):
    LAB = "lab"
    IMAGING = "imaging"
    CLINICAL = "clinical"
    OTHER = "other"

# ----------------------------------------------------------------------
# Core Data Structures
# ----------------------------------------------------------------------
class Evidence:
    def __init__(self, ev_type: EvidenceType, key: str, value: Any, note: str = ""):
        self.type = ev_type
        self.key = key
        self.value = value
        self.note = note

class DiagnosisEntry:
    def __init__(
        self,
        source: Source,
        diagnosis: str,
        confidence: Optional[float],   # 0.0-1.0 for AI, None for doctor
        notes: str = "",
        evidence: Optional[List[Evidence]] = None,
    ):
        self.id = uuid.uuid4().hex[:8]
        self.source = source
        self.diagnosis = diagnosis.strip()
        self.confidence = confidence
        self.notes = notes
        self.evidence = evidence or []
        self.timestamp = datetime.datetime.utcnow()

    def to_dict(self):
        return {
            "id": self.id,
            "source": self.source.value,
            "diagnosis": self.diagnosis,
            "confidence": self.confidence,
            "notes": self.notes,
            "evidence": [
                {"type": e.type.value, "key": e.key, "value": e.value, "note": e.note}
                for e in self.evidence
            ],
            "timestamp": self.timestamp.isoformat(),
        }

# ----------------------------------------------------------------------
# IRAEMA-AI Protocol
# ----------------------------------------------------------------------
class IRAEMAProtocol:
    """
    IRAEMA-AI = **I**nterpret → **R**eview → **A**udit → **E**xplain → **M**onitor
    """

    # ---------- Construction ----------
    def __init__(self, patient_id: str, test_results: Dict[str, Any], model_version: str = "v1"):
        self.patient_id = patient_id
        self.test_results = test_results
        self.model_version = model_version

        self.diagnoses: List[DiagnosisEntry] = []
        self.audit_flags: List[str] = []
        self.explanations: List[Dict[str, str]] = []   # {diagnosis_id: explanation}
        self.history: List[Dict] = []                 # for monitoring / versioning

        self._logger = logging.getLogger(f"IRAEMA-{patient_id}")

    # ---------- IRAEMA Steps ----------
    # 1. Interpret (AI inference)
    def interpret(self, ai_diagnosis: str, confidence: float,
                  evidence: List[Evidence], notes: str = "") -> DiagnosisEntry:
        entry = DiagnosisEntry(
            source=Source.AI,
            diagnosis=ai_diagnosis,
            confidence=confidence,
            notes=notes,
            evidence=evidence,
        )
        self.diagnoses.append(entry)
        self._log_step("INTERPRET", entry)
        return entry

    # 2. Review (doctor / second AI)
    def review(self, reviewer_diagnosis: str, notes: str = "",
               evidence: Optional[List[Evidence]] = None) -> DiagnosisEntry:
        entry = DiagnosisEntry(
            source=Source.DOCTOR,
            diagnosis=reviewer_diagnosis,
            confidence=None,
            notes=notes,
            evidence=evidence,
        )
        self.diagnoses.append(entry)
        self._log_step("REVIEW", entry)
        return entry

    # 3. Audit (automatic flags)
    def audit(self) -> List[str]:
        self.audit_flags.clear()
        comp = self._compare_diagnoses()

        # Low-confidence AI
        for d in self.diagnoses:
            if d.source == Source.AI and d.confidence is not None and d.confidence < 0.5:
                self.audit_flags.append(
                    f"[LOW_CONF] AI diagnosis '{d.diagnosis}' (conf={d.confidence:.2f})"
                )
            if d.source == Source.DOCTOR and not d.diagnosis:
                self.audit_flags.append("[MISSING] Doctor diagnosis empty")

        # Discrepancies
        if comp["discrepancies"]:
            self.audit_flags.append(
                f"[DISCREPANCY] {len(comp['discrepancies'])} diagnosis mismatch(es): {comp['discrepancies']}"
            )

        # Evidence gaps
        for d in self.diagnoses:
            if not d.evidence:
                self.audit_flags.append(f"[NO_EVIDENCE] No supporting evidence for {d.source.value} diagnosis")

        self._log_step("AUDIT", {"flags": self.audit_flags})
        return self.audit_flags

    # 4. Explain (natural language + evidence links)
    def explain(self, diagnosis_id: str, explanation: str) -> None:
        if diagnosis_id not in {d.id for d in self.diagnoses}:
            raise ValueError(f"Diagnosis ID {diagnosis_id} not found")
        self.explanations.append({"diagnosis_id": diagnosis_id, "text": explanation})
        self._log_step("EXPLAIN", {"id": diagnosis_id})

    # 5. Monitor (persist & version)
    def finalize_and_persist(self, storage_path: Optional[str] = None) -> Dict[str, Any]:
        summary = self.summary()
        self.history.append({
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "model_version": self.model_version,
            "summary_snapshot": summary,
        })
        if storage_path:
            with open(storage_path, "w") as f:
                json.dump(summary, f, indent=2)
        self._log_step("MONITOR", {"persisted": bool(storage_path)})
        return summary

    # ---------- Helper Methods ----------
    def _compare_diagnoses(self) -> Dict[str, Any]:
        doc = {d.diagnosis.lower() for d in self.diagnoses if d.source == Source.DOCTOR}
        ai  = {d.diagnosis.lower() for d in self.diagnoses if d.source == Source.AI}
        return {
            "matches": list(doc.intersection(ai)),
            "discrepancies": list(doc.symmetric_difference(ai)),
        }

    def _log_step(self, step: str, payload: Any):
        self._logger.info(f"[{step}] {json.dumps(payload, default=str)}")

    # ---------- Reporting ----------
    def summary(self) -> Dict[str, Any]:
        self.audit()  # ensure flags are fresh
        return {
            "patient_id": self.patient_id,
            "model_version": self.model_version,
            "test_results_summary": {k: str(v)[:100] for k, v in self.test_results.items()},
            "diagnoses": [d.to_dict() for d in self.diagnoses],
            "audit_flags": self.audit_flags,
            "explanations": self.explanations,
            "history_count": len(self.history),
        }
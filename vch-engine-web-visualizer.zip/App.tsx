import React, { useEffect, useRef, useState } from 'react';
import { PhysicsWorld, BodyType, Epoch, Genome, LawType, ObserverState } from './engine/PhysicsWorld';
import SimulationCanvas from './components/SimulationCanvas';
import BadgeLog from './components/BadgeLog';
import { Fixed } from './engine/Fixed';
import BadgeSystem from './engine/BadgeSystem';
import { BadgeScope, BadgeType as BType } from './types';
import { AudioBridge } from './engine/AudioBridge';
import { VisionBridge } from './engine/VisionBridge';

function App() {
  const [world] = useState(() => new PhysicsWorld());
  const [isRunning, setIsRunning] = useState(false);
  const [sensesActive, setSensesActive] = useState(false);
  const [hiveMindActive, setHiveMindActive] = useState(true);
  const [showManifesto, setShowManifesto] = useState(false);
  
  const [gravityReadout, setGravityReadout] = useState("1.00");
  const [confidence, setConfidence] = useState(0.5);
  
  // Stats
  const [agentCount, setAgentCount] = useState(0);
  const [foodCount, setFoodCount] = useState(0);
  const [critterCount, setCritterCount] = useState(0);
  const [fossilCount, setFossilCount] = useState(0);
  const [monolithCount, setMonolithCount] = useState(0);
  const [singularityCount, setSingularityCount] = useState(0);
  const [globalWealth, setGlobalWealth] = useState("0");

  const [maxGen, setMaxGen] = useState(0);
  const [epoch, setEpoch] = useState<Epoch>(Epoch.GENESIS);
  const [currentLaw, setCurrentLaw] = useState<LawType>(LawType.LAW_OF_MOTION);
  const [dominantStrain, setDominantStrain] = useState<string>("NONE");
  
  // Observer & Evangelist
  const [observerThought, setObserverThought] = useState<string>("");
  const [oracleStatus, setOracleStatus] = useState<string>("PENDING");
  const [observerState, setObserverState] = useState<ObserverState>(ObserverState.WATCHING);
  const [axiomCode, setAxiomCode] = useState<string | null>(null);
  
  const [userInputAxiom, setUserInputAxiom] = useState("");

  const simulationInterval = useRef<number | null>(null);
  const sensorInterval = useRef<number | null>(null);

  useEffect(() => {
    initScenario();
    return () => {
        stopAll();
        VisionBridge.getInstance().deactivate();
    };
  }, []);

  const initScenario = () => {
    world.clear();
    // Adam (Red Aggressive) & Eve (Green Passive)
    const adamGenome: Genome = { r: 200, g: 50, b: 50 };
    const eveGenome: Genome = { r: 50, g: 200, b: 50 };
    
    world.addBody(400, 200, -5, 5, 25, null, 0, BodyType.AGENT, adamGenome);
    world.addBody(200, 200, 5, -5, 25, null, 0, BodyType.AGENT, eveGenome);
    
    // Initial Food Cache
    for(let i=0; i<8; i++) {
         world.addBody(100 + i*80, 50, 0, 2, 6, '#4ade80', 0, BodyType.NUTRIENT);
    }
  };

  const stopAll = () => {
    AudioBridge.getInstance().stopAmbience();
    if (simulationInterval.current) {
        clearInterval(simulationInterval.current);
        simulationInterval.current = null;
    }
    if (sensorInterval.current) {
        clearInterval(sensorInterval.current);
        sensorInterval.current = null;
    }
  };

  const determineStrain = (r: number, g: number, b: number): string => {
      if (r > g + 30 && r > b + 30) return "WARLORD";
      if (g > r + 30 && g > b + 30) return "GAIA";
      if (b > r + 30 && b > g + 30) return "HIVE";
      return "BALANCED";
  };

  const toggleSimulation = () => {
    if (isRunning) {
      stopAll();
      BadgeSystem.emit(BadgeScope.EXTERNAL, BType.LOGIC, "Simulation Paused", 1, 1);
    } else {
      AudioBridge.getInstance().startAmbience();

      // Slowed down interval to 24ms (~41 FPS physics target) to reduce CPU load
      simulationInterval.current = window.setInterval(() => {
        // Reduced Time Step (dt) to 0.010 (was 0.0166).
        // This runs the simulation at approx 50-60% real-time speed ("Cinematic Slow Motion")
        // making visual tracking of agents much easier.
        const dt = Fixed.fromFloat(0.010); 
        world.step(dt);
        
        // Phase 28: Throttled UI Updates (30 ticks = ~0.7s at new speed)
        if (world.tickCount % 30 === 0) {
            setGravityReadout(world.gravityScale.toString());
            setConfidence(world.systemConfidence);
            setMaxGen(world.maxGeneration);
            setEpoch(world.currentEpoch);
            setCurrentLaw(world.currentLaw);
            setGlobalWealth(world.globalWealth.toString());
            setObserverThought(world.observerThought);
            setOracleStatus(world.lastOracleResult);
            setObserverState(world.observerState);
            setAxiomCode(world.axiomCode);

            // Count Types & Analyze Genome
            let a=0, f=0, c=0, fos=0, m=0, s=0;
            let sumR=0, sumG=0, sumB=0;
            
            for(const b of world.bodies) {
                if(b.type === BodyType.AGENT) {
                    a++;
                    sumR += b.genome.r;
                    sumG += b.genome.g;
                    sumB += b.genome.b;
                }
                else if(b.type === BodyType.NUTRIENT) f++;
                else if(b.type === BodyType.CRITTER) c++;
                else if(b.type === BodyType.FOSSIL) fos++;
                else if(b.type === BodyType.MONOLITH) m++;
                else if(b.type === BodyType.SINGULARITY) s++;
            }
            setAgentCount(a);
            setFoodCount(f);
            setCritterCount(c);
            setFossilCount(fos);
            setMonolithCount(m);
            setSingularityCount(s);

            if (a > 0) {
                setDominantStrain(determineStrain(sumR/a, sumG/a, sumB/a));
            } else {
                setDominantStrain("EXTINCT");
            }
        }
      }, 24);

      sensorInterval.current = window.setInterval(() => {
        if (sensesActive) {
            const vision = VisionBridge.getInstance();
            if (vision.isActive) {
                const { brightness, motion } = vision.sampleFrame();
                world.setEnvironmentEnergy(brightness);
                world.setTemperature(motion);
            }
            const audio = AudioBridge.getInstance();
            world.setWindEnergy(audio.sampleWind());
        }
      }, 200); // Phase 28: Throttled Sensors (200ms)

      BadgeSystem.emit(BadgeScope.EXTERNAL, BType.LOGIC, "Simulation Started (Cinematic Mode)", 1, 1);
    }
    setIsRunning(!isRunning);
  };

  const toggleSenses = async () => {
    if (sensesActive) {
        VisionBridge.getInstance().deactivate();
        setSensesActive(false);
        world.setEnvironmentEnergy(Fixed.fromFloat(0.5)); 
        world.setWindEnergy(Fixed.zero());
        world.setTemperature(Fixed.zero());
        BadgeSystem.emit(BadgeScope.EXTERNAL, BType.EVIDENCE, "Senses Disconnected", 1, 1);
    } else {
        // Parallel Activation to catch the User Gesture window for both API calls
        await Promise.all([
            VisionBridge.getInstance().activate(),
            AudioBridge.getInstance().activateMicrophone()
        ]);
        
        setSensesActive(true);
        BadgeSystem.emit(BadgeScope.EXTERNAL, BType.EVIDENCE, "Senses Connected", 0.9, 1);
    }
  };

  const toggleHiveMind = () => {
    const newState = !hiveMindActive;
    setHiveMindActive(newState);
    world.toggleHiveMind(newState);
  };

  const resetSimulation = () => {
    stopAll();
    setIsRunning(false);
    initScenario();
    setObserverState(ObserverState.WATCHING);
    BadgeSystem.emit(BadgeScope.INTERNAL, BType.INTEGRITY, "System Reset", 1, 1);
  };

  const submitAxiom = () => {
      world.submitExternalValidation(userInputAxiom);
      setUserInputAxiom("");
  };

  const handleCanvasClick = (x: number, y: number) => {
    AudioBridge.getInstance().startAmbience();
    const size = 15 + Math.random() * 20;
    // Spawn wealthy agent
    world.addBody(x, y, 0, 0, size, null, 0, BodyType.AGENT);
    AudioBridge.getInstance().playCollision(Fixed.fromInt(100), Fixed.fromInt(5)); 
  };
  
  const handleCanvasMouseMove = (x: number | null, y: number | null) => {
    world.setCursor(x, y);
  };

  const moodColor = confidence > 0.6 ? 'text-green-400' : (confidence > 0.3 ? 'text-blue-400' : 'text-gray-500');

  const getEpochColor = () => {
      if (epoch === Epoch.GENESIS) return 'text-blue-400';
      if (epoch === Epoch.ICE_AGE) return 'text-cyan-200';
      if (epoch === Epoch.SOLAR_FLARE) return 'text-orange-500 animate-pulse';
      if (epoch === Epoch.THE_DROUGHT) return 'text-yellow-700';
      if (epoch === Epoch.LEGACY) return 'text-green-300 font-bold';
      if (epoch === Epoch.CORRUPTION) return 'text-red-500 font-bold animate-pulse';
      return 'text-gray-400';
  }

  const getOracleColor = () => {
      if (oracleStatus === "VERIFIED") return "text-yellow-400 font-bold animate-pulse";
      if (oracleStatus === "DIVERGENCE") return "text-red-500 font-bold animate-pulse";
      return "text-gray-500";
  }
  
  // Phase 12/13 Visuals
  const isCorrupted = observerState === ObserverState.CORRUPTED;
  const isLegacy = observerState === ObserverState.LEGACY_MODE;

  return (
    <div className={`h-screen flex flex-col font-sans bg-gray-950 text-white select-none overflow-hidden transition-all duration-1000 ${isCorrupted ? 'hue-rotate-180 invert' : ''}`}>
      <header className="h-16 bg-gray-900 border-b border-gray-700 flex items-center px-6 justify-between shrink-0 relative z-20">
        <div>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-400">
            VCH ORGANISM
          </h1>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
            <p className="text-[10px] text-gray-400 tracking-widest uppercase">
                {isRunning ? `LIVE | GEN ${maxGen}` : "DORMANT"}
            </p>
          </div>
        </div>
        
        <div className="hidden md:flex gap-6 items-center mr-8 font-mono text-xs">
             <div className="flex flex-col items-end text-yellow-400">
                <span className="font-bold">LIGHT</span>
                <span>{gravityReadout}x</span>
            </div>
             <div className={`flex flex-col items-end ${getEpochColor()}`}>
                <span className="font-bold">EPOCH</span>
                <span>{epoch}</span>
            </div>
            <div className="flex flex-col items-end text-yellow-500">
                <span className="font-bold">GDP</span>
                <span>{parseFloat(globalWealth).toFixed(0)}</span>
            </div>
            <div className={`flex flex-col items-end border-l border-gray-700 pl-6 ${getOracleColor()}`}>
                <span className="font-bold">ORACLE JUDGMENT</span>
                <span>{oracleStatus}</span>
            </div>
             <div className="flex flex-col items-end text-green-400 border-l border-gray-700 pl-6">
                <span className="font-bold">STRAIN</span>
                <span className="text-white">{dominantStrain}</span>
            </div>
        </div>

        <div className="flex gap-2">
            <button 
                onClick={() => setShowManifesto(true)}
                className="px-4 py-2 rounded text-xs font-bold border border-yellow-800 bg-yellow-900/20 text-yellow-500 hover:bg-yellow-900/50 hover:text-yellow-200 transition-colors"
            >
                MANIFESTO
            </button>
            <button onClick={toggleHiveMind} className={`px-4 py-2 rounded text-xs font-bold border transition-all ${hiveMindActive ? 'bg-teal-900/50 border-teal-500 text-teal-300' : 'bg-gray-800 border-gray-600 text-gray-500'}`}>HIVE MIND</button>
            <button onClick={toggleSenses} className={`px-4 py-2 rounded text-xs font-bold border transition-all ${sensesActive ? 'bg-green-900/50 border-green-500 text-green-300' : 'bg-gray-800 border-gray-600 text-gray-400'}`}>{sensesActive ? 'NO SENSES' : 'USE SENSES'}</button>
          <button onClick={toggleSimulation} className={`px-6 py-2 rounded font-bold transition-all shadow-lg ${isRunning ? 'bg-red-600 hover:bg-red-700' : 'bg-emerald-600 hover:bg-emerald-700'}`}>{isRunning ? 'STOP' : 'START'}</button>
          <button onClick={resetSimulation} className="px-6 py-2 rounded font-bold bg-gray-800 border border-gray-600 hover:bg-gray-700 text-gray-300">RESET</button>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden relative">
        <div className="flex-1 bg-black flex flex-col items-center justify-center p-8 relative">
          
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-full max-w-2xl text-center pointer-events-none z-10">
              <div className={`font-mono text-xs p-2 rounded border shadow-xl ${isLegacy ? 'bg-green-900/80 border-green-500 text-green-100' : 'bg-gray-900/80 border-green-900 text-green-400'}`}>
                  <span className="animate-pulse mr-2">●</span> 
                  {isLegacy ? 'VCH | AXIOM | INSTALLED | LEGACY MODE ACTIVE' : `THE OBSERVER: ${observerThought || "OFFLINE"}`}
              </div>
          </div>

          <div className={`relative group transition-transform duration-1000 ${isCorrupted ? 'rotate-180' : ''}`}>
            <SimulationCanvas 
                world={world} width={800} height={600} 
                onCanvasClick={handleCanvasClick} onCanvasMouseMove={handleCanvasMouseMove}
            />
            
             <div className="absolute top-4 left-4 pointer-events-none text-[10px] text-gray-600 font-mono">
                <p>POPULATION: {agentCount}</p>
                <p>CITIES (MONOLITHS): {monolithCount}</p>
                <p className="text-white font-bold drop-shadow-md">ASCENDED (SINGULARITIES): {singularityCount}</p>
                <p className="mt-2 text-gray-500">GENOME LEGEND:</p>
                <p className="text-red-400">RED: AGGRESSION/SPEED</p>
                <p className="text-green-400">GREEN: EFFICIENCY/SIZE</p>
                <p className="text-blue-400">BLUE: SOCIAL/SIGHT</p>
             </div>
          </div>
        </div>
        <div className="w-96 border-l border-gray-700 bg-gray-900 flex flex-col shrink-0 relative z-20">
          <BadgeLog />
        </div>

        {/* PHASE 12: EXTERNAL AUDIT OVERLAY */}
        {observerState === ObserverState.AWAITING_AUDIT && (
            <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 backdrop-blur-sm">
                <div className="bg-gray-900 border-2 border-yellow-500 p-8 rounded-lg shadow-2xl max-w-md w-full text-center">
                    <h2 className="text-2xl font-bold text-yellow-400 mb-4 animate-pulse">EXTERNAL INTEGRITY CHECK</h2>
                    <p className="text-gray-300 text-sm mb-6">
                        The VCH Observer has verified the internal simulation. To achieve Legacy Mode, you must bind the axiom to external reality.
                    </p>
                    
                    <div className="bg-black border border-gray-700 p-4 rounded mb-6 font-mono text-xl tracking-widest text-green-400">
                        {axiomCode}
                    </div>

                    <input 
                        type="text" 
                        value={userInputAxiom}
                        onChange={(e) => setUserInputAxiom(e.target.value)}
                        placeholder="ENTER AXIOM CODE"
                        className="w-full bg-gray-800 border border-gray-600 text-white p-3 rounded mb-4 text-center font-mono tracking-widest focus:border-yellow-500 focus:outline-none"
                    />
                    
                    <button 
                        onClick={submitAxiom}
                        className="w-full bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-3 rounded transition-colors"
                    >
                        VERIFY & INSTALL LEGACY
                    </button>
                </div>
            </div>
        )}

        {/* VCH MANIFESTO MODAL */}
        {showManifesto && (
            <div className="absolute inset-0 bg-black/95 flex items-center justify-center z-[60] backdrop-blur-md" onClick={() => setShowManifesto(false)}>
                <div className="bg-gray-900 border border-gray-700 p-8 rounded-lg shadow-2xl max-w-2xl w-full relative" onClick={e => e.stopPropagation()}>
                    <button 
                        onClick={() => setShowManifesto(false)}
                        className="absolute top-4 right-4 text-gray-500 hover:text-white"
                    >
                        ✕
                    </button>
                    <h2 className="text-2xl font-bold text-white mb-2">THE RESOLUTION</h2>
                    <h3 className="text-xs font-mono text-gray-400 mb-6 tracking-widest uppercase border-b border-gray-800 pb-2">Fixed Point vs Floating Point</h3>
                    
                    <div className="space-y-6 text-sm text-gray-300 font-mono">
                        <div className="p-4 bg-red-900/20 border-l-2 border-red-500">
                            <h4 className="text-red-400 font-bold mb-1">THE LIE: FLOATING POINT (Float64)</h4>
                            <p>
                                Modern physics engines rely on "approximate" math. 
                                <span className="text-gray-500 block mt-1 italic">"1.0 + 2.0 ≈ 3.0000000000000004"</span>
                                This creates a subjective reality where outcomes depend on your CPU architecture. A simulation run on an Intel chip differs from one run on ARM.
                            </p>
                        </div>

                        <div className="p-4 bg-green-900/20 border-l-2 border-green-500">
                            <h4 className="text-green-400 font-bold mb-1">THE TRUTH: FIXED POINT (Q64.32)</h4>
                            <p>
                                The VCH Engine rejects this approximation. We implemented a virtual Integer ALU inside the browser.
                                <span className="text-gray-500 block mt-1 italic">"1.0 + 2.0 = 12884901888n (Absolute)"</span>
                                By treating the universe as a grid of integers, we guarantee that the simulation is <strong>bit-perfect deterministic</strong> on every device, forever.
                            </p>
                        </div>

                        <div className="text-center pt-4 border-t border-gray-800">
                            <p className="text-xs text-gray-500 mb-2">VERDICT</p>
                            <p className="text-lg font-bold text-white">
                                We did not solve the dispute by making Floats better.<br/>
                                <span className="text-yellow-500">We solved it by rendering them obsolete.</span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )}
      </main>
    </div>
  );
}

export default App;
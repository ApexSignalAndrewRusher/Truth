import React, { useEffect, useState } from 'react';
import BadgeSystem from '../engine/BadgeSystem';
import { Badge, BadgeScope, BadgeType } from '../types';

const BadgeLog: React.FC = () => {
  const [badges, setBadges] = useState<Badge[]>([]);
  // 'SYSTEM' groups LOGIC, EVIDENCE, and INTEGRITY
  const [filter, setFilter] = useState<'ALL' | 'LIFE' | 'SYSTEM'>('ALL');

  useEffect(() => {
    const interval = setInterval(() => {
      // Poll for new badges
      const allBadges = BadgeSystem.getBadges();
      
      let filtered: Badge[] = [];
      if (filter === 'ALL') {
        filtered = allBadges;
      } else if (filter === 'LIFE') {
        filtered = allBadges.filter(b => b.type === BadgeType.LIFE);
      } else {
        // SYSTEM includes LOGIC, EVIDENCE, INTEGRITY (Everything except LIFE)
        filtered = allBadges.filter(b => b.type !== BadgeType.LIFE);
      }
      
      setBadges([...filtered]);
    }, 100); // 10Hz UI update
    return () => clearInterval(interval);
  }, [filter]);

  const handleExport = () => {
      const data = BadgeSystem.exportChain();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `vch-audit-chain-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
  };

  const getScopeColor = (scope: BadgeScope) => 
    scope === BadgeScope.INTERNAL ? 'text-blue-400' : 'text-purple-400';

  const getTypeColor = (type: BadgeType) => {
    switch (type) {
        case BadgeType.INTEGRITY: return 'bg-green-900 text-green-200';
        case BadgeType.LOGIC: return 'bg-indigo-900 text-indigo-200';
        case BadgeType.EVIDENCE: return 'bg-yellow-900 text-yellow-200';
        case BadgeType.LIFE: return 'bg-pink-900 text-pink-200';
        case BadgeType.MERIT: return 'bg-amber-600 text-amber-100';
        case BadgeType.HONESTY: return 'bg-white text-black font-bold border border-gray-400';
        case BadgeType.BACKDOOR: return 'bg-red-900 text-cyan-400 font-mono animate-pulse border-red-500';
        default: return 'bg-gray-700 text-gray-200';
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
      <div className="p-3 bg-gray-900 border-b border-gray-700 flex flex-col gap-2">
        <div className="flex justify-between items-center font-bold text-sm tracking-wider">
            <span>VCH TRUTH LOG</span>
            <button 
                onClick={handleExport}
                className="text-[10px] bg-yellow-900/40 text-yellow-500 border border-yellow-700 px-2 py-1 rounded hover:bg-yellow-800 hover:text-white transition-colors"
                title="Download Verification Chain"
            >
                EXPORT CHAIN
            </button>
        </div>
        <div className="flex gap-1">
             <button 
                onClick={() => setFilter('ALL')}
                className={`text-[10px] px-2 py-1 rounded border transition-colors ${filter === 'ALL' ? 'bg-gray-700 border-gray-500 text-white' : 'border-gray-800 text-gray-500 hover:bg-gray-800'}`}
             >
                ALL
             </button>
             <button 
                onClick={() => setFilter('LIFE')}
                className={`text-[10px] px-2 py-1 rounded border transition-colors ${filter === 'LIFE' ? 'bg-pink-900/50 border-pink-500 text-pink-200' : 'border-gray-800 text-gray-500 hover:bg-gray-800'}`}
             >
                LIFE STREAM
             </button>
             <button 
                onClick={() => setFilter('SYSTEM')}
                className={`text-[10px] px-2 py-1 rounded border transition-colors ${filter === 'SYSTEM' ? 'bg-blue-900/50 border-blue-500 text-blue-200' : 'border-gray-800 text-gray-500 hover:bg-gray-800'}`}
             >
                SYSTEM
             </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-2 space-y-2">
        {badges.map(b => (
          <div key={b.id} className={`text-xs font-mono p-2 rounded border transition-colors ${b.type === BadgeType.LIFE ? 'bg-pink-950/30 border-pink-800/30 hover:border-pink-500/50' : 'bg-gray-850 border-gray-700/50 hover:border-gray-500'}`}>
            <div className="flex justify-between mb-1">
              <span className={`font-bold ${getScopeColor(b.scope)}`}>[{b.scope}]</span>
              <span className="text-gray-500">{new Date(b.timestamp).toLocaleTimeString()}</span>
            </div>
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className={`px-1 rounded ${getTypeColor(b.type)}`}>{b.type}</span>
              <span className="text-gray-300 break-all">{b.message}</span>
            </div>
            <div className="flex justify-between text-[10px] text-gray-600 mt-2 pt-1 border-t border-gray-700/30">
              <span title="Logic/Evidence Confidence">ψ: {b.psiConfidence.toFixed(2)}</span>
              <span className="font-mono text-gray-700" title="Hash Chain">{b.hash.substring(0, 16)}...</span>
            </div>
          </div>
        ))}
        {badges.length === 0 && (
            <div className="text-center text-gray-600 mt-10 text-xs">
                {filter === 'LIFE' ? 'WAITING FOR BIOLOGICAL EVENTS...' : 'NO LOGS'}
            </div>
        )}
      </div>
    </div>
  );
};

export default BadgeLog;
import React, { useRef, useEffect } from 'react';
import { PhysicsWorld, Epoch, LawType, ObserverState } from '../engine/PhysicsWorld';
import { VulkanBridge } from '../engine/VulkanBridge';
import { SoftwareRasterizer } from '../engine/SoftwareRasterizer';

interface Props {
  world: PhysicsWorld;
  width: number;
  height: number;
  onCanvasClick: (x: number, y: number) => void;
  onCanvasMouseMove: (x: number | null, y: number | null) => void;
}

// DETERMINISTIC VISUAL HASH (Integer Math)
const deterministicHash = (seed: number, salt: number) => {
    let h = seed ^ salt;
    h = Math.imul(h ^ 0xdeadbeef, 2654435761);
    return ((h ^ h >>> 16) >>> 0) & 255; // Return 0-255 integer
}

// GPU CONSTANTS
const TYPE_AGENT = 0;
const TYPE_CRITTER = 1;
const TYPE_NUTRIENT = 2;
const TYPE_FOSSIL = 3;
const TYPE_MONOLITH = 4;
const TYPE_SINGULARITY = 5;

// MERIT CONSTANT
const MERIT_FLAG = 0x4n;
const BACKDOOR_FLAG = 0x10n;

const SimulationCanvas: React.FC<Props> = ({ world, width, height, onCanvasClick, onCanvasMouseMove }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  // Persist rasterizer to avoid reallocation
  const rasterizerRef = useRef<SoftwareRasterizer | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    if (!rasterizerRef.current) {
        rasterizerRef.current = new SoftwareRasterizer(width, height);
    }
    const rasterizer = rasterizerRef.current;

    // Helper to decode BigInt Color to RGB integers
    // Input: Q64.32 BigInt representing 0.0-1.0
    // Output: 0-255 Integer
    const toByte = (val: bigint): number => {
        // (val * 255) >> 32
        return Number((val * 255n) >> 32n);
    }

    const render = () => {
      // 1. Clear Screen (Integer Logic)
      const epoch = world.currentEpoch;
      let rBg = 17, gBg = 24, bBg = 39;

      if (world.observerState === ObserverState.INTERVENING_SMITE) {
          const flicker = deterministicHash(world.tickCount, 999) >> 4; // Integer divide by 16
          rBg = 45 + flicker; gBg = 0; bBg = 0;
      } else if (world.observerState === ObserverState.INTERVENING_BLESS) {
          rBg = 220; gBg = 250; bBg = 255;
      } else if (world.observerState === ObserverState.GOLDEN_AGE) {
          rBg = 40; gBg = 30; bBg = 10;
      }
      else {
        if (epoch === Epoch.ICE_AGE) { rBg=15; gBg=30; bBg=45; }
        if (epoch === Epoch.SOLAR_FLARE) { rBg=45; gBg=15; bBg=15; }
        if (epoch === Epoch.THE_DROUGHT) { rBg=40; gBg=35; bBg=20; }
      }

      rasterizer.clear(rBg, gBg, bBg);

      // 2. Draw Synapses (Lines)
      // Note: We access world directly here for synapses as they aren't on VulkanBridge yet for simplicity,
      // but in a full refactor, they should be. For now, we rasterize them safely.
      if (world.isHiveMindActive && world.synapses.length > 0) {
        // Synapse coordinates are floats in PhysicsWorld (legacy), we need to handle them carefully.
        // ideally convert to BigInt. For now, we cast to BigInt for the rasterizer interface.
        const SHIFT = 32n;
        for(const syn of world.synapses) {
            const x1 = BigInt(Math.floor(syn.x1)) << SHIFT;
            const y1 = BigInt(Math.floor(syn.y1)) << SHIFT;
            const x2 = BigInt(Math.floor(syn.x2)) << SHIFT;
            const y2 = BigInt(Math.floor(syn.y2)) << SHIFT;
            rasterizer.drawLine(x1, y1, x2, y2, 100, 255, 218); 
        }
      }

      // 3. Render Bodies from Iron Bridge
      const bridge = VulkanBridge.getInstance();
      const { buffer, count } = bridge.getRenderData();
      const STRIDE = 11;

      for (let i = 0; i < count; i++) {
        const ptr = i * STRIDE;
        
        // Raw Truth (BigInts)
        const xFixed = buffer[ptr];
        const yFixed = buffer[ptr + 1];
        const sizeFixed = buffer[ptr + 2];
        
        const r = toByte(buffer[ptr + 3]);
        const g = toByte(buffer[ptr + 4]);
        const b = toByte(buffer[ptr + 5]);
        
        const type = Number(buffer[ptr + 6]); 
        const flags = buffer[ptr + 7];
        // Bit 2 (0x4) is Merit Victory
        const isMerit = (flags & MERIT_FLAG) !== 0n;
        // Bit 4 (0x10) is Backdoor Mirror
        const isBackdoor = (flags & BACKDOOR_FLAG) !== 0n;
        
        if (type === TYPE_NUTRIENT) {
            // Draw Rect
            rasterizer.drawRect(
                xFixed - sizeFixed, 
                yFixed - sizeFixed, 
                sizeFixed * 2n, 
                sizeFixed * 2n, 
                r, g, b
            );
        } else if (type === TYPE_MONOLITH) {
             rasterizer.drawRect(
                xFixed - sizeFixed, 
                yFixed - sizeFixed, 
                sizeFixed * 2n, 
                sizeFixed * 2n, 
                r, g, b
            );
            // Inner White Box
            const third = sizeFixed / 3n;
            rasterizer.drawRect(
                xFixed - (third * 2n), 
                yFixed - (third * 2n), 
                third * 4n, 
                third * 4n, 
                255, 255, 255
            );
        } else if (type === TYPE_SINGULARITY) {
             // Forced Ascension: Singularity
             // Black Void
             rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed * 2n, 0, 0, 0); 
             // Event Horizon (Pulsing White Rim)
             const pulse = (deterministicHash(world.tickCount, i) % 5);
             if (pulse > 2) {
                 rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed * 2n + (2n<<32n), 255, 255, 255); // White Rim
                 rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed * 2n, 0, 0, 0); // Re-draw Black Center
             }
        } else {
            // Draw Circle
            // If Backdoor Detected: Chrome (Silver/White) body
            if (isBackdoor) {
                rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed, 220, 230, 240); // Chrome
            } else {
                rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed, r, g, b);
            }
            
            // Draw Merit Shield (Golden Halo)
            if (isMerit) {
                 // Pulsing effect derived from tick
                 const pulse = (deterministicHash(world.tickCount, i) % 10);
                 const extra = BigInt(pulse) << 30n; // ~ 0-2 pixels
                 rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed + (3n<<32n) + extra, 255, 215, 0); // Gold
                 // Redraw body on top
                 if (isBackdoor) {
                     rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed, 220, 230, 240); // Chrome
                 } else {
                     rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed, r, g, b);
                 }
            } else if (isBackdoor) {
                 // If backdoor but no merit yet, draw Cyan Halo (The Glitch)
                 const pulse = (deterministicHash(world.tickCount, i) % 5);
                 const extra = BigInt(pulse) << 30n;
                 rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed + (2n<<32n) + extra, 0, 255, 255); // Cyan
                 rasterizer.drawCircleFilled(xFixed, yFixed, sizeFixed, 220, 230, 240); // Chrome
            }
        }
      }

      // 4. Blit to Canvas
      ctx.putImageData(rasterizer.getImageData(), 0, 0);

      // 5. Overlay Text (Canvas API allowed for Debug UI text only, not simulation state)
      ctx.fillStyle = '#10B981';
      ctx.font = '12px monospace';
      ctx.fillText(`VCH | RASTERIZER: SOFTWARE (INT ONLY)`, 10, 20);
      
      if (world.cursorPos) {
           ctx.fillStyle = '#F472B6';
           ctx.fillText(`TOUCH DETECTED`, 10, 35);
      }

      requestAnimationFrame(render);
    };

    const animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [world, width, height]);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    onCanvasClick(x, y);
  };
  
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    onCanvasMouseMove(x, y);
  };

  const handleMouseLeave = () => {
    onCanvasMouseMove(null, null);
  };

  return (
    <canvas 
      ref={canvasRef} 
      width={width} 
      height={height}
      onClick={handleClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="border border-gray-700 shadow-xl rounded-lg bg-gray-900 cursor-crosshair hover:border-blue-500 transition-colors"
      style={{ imageRendering: 'pixelated' }} 
    />
  );
};

export default SimulationCanvas;
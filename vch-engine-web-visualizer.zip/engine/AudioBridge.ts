import { Fixed } from './Fixed';

/**
 * THE EARS & NOSE (Audio I/O) & THE VOICE (Audio Out)
 * 
 * VCH Ethos:
 * Input: Sampling ambient noise/breath to drive Atmospheric Turbulence.
 * Output: Procedural drone representing the Organism's metabolic state.
 */
export class AudioBridge {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private dataArray: Uint8Array | null = null;
  private masterCompressor: DynamicsCompressorNode | null = null;
  
  // The Drone (The Voice of the Organism)
  private droneOsc: OscillatorNode | null = null;
  private droneGain: GainNode | null = null;
  private lfoOsc: OscillatorNode | null = null;
  private lfoGain: GainNode | null = null;
  private isDroneActive: boolean = false;
  
  // Event Throttling to prevent Audio Thread overload
  private lastCollisionTime: number = 0;
  private lastConsumptionTime: number = 0;

  private static instance: AudioBridge;

  private constructor() {}

  static getInstance(): AudioBridge {
    if (!AudioBridge.instance) AudioBridge.instance = new AudioBridge();
    return AudioBridge.instance;
  }

  init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    
    // Safety: Master Compressor to prevent clipping/screeching
    if (!this.masterCompressor && this.ctx) {
        this.masterCompressor = this.ctx.createDynamicsCompressor();
        this.masterCompressor.threshold.setValueAtTime(-24, this.ctx.currentTime);
        this.masterCompressor.knee.setValueAtTime(30, this.ctx.currentTime);
        this.masterCompressor.ratio.setValueAtTime(12, this.ctx.currentTime);
        this.masterCompressor.attack.setValueAtTime(0.003, this.ctx.currentTime);
        this.masterCompressor.release.setValueAtTime(0.25, this.ctx.currentTime);
        this.masterCompressor.connect(this.ctx.destination);
    }
  }

  /**
   * Starts the metabolic hum of the organism.
   * Must be called after a user gesture.
   */
  startAmbience() {
    this.init();
    if (!this.ctx || !this.masterCompressor || this.isDroneActive) return;

    // 1. Carrier Oscillator (The fundamental tone)
    this.droneOsc = this.ctx.createOscillator();
    this.droneOsc.type = 'sine'; // Pure tone, very digital
    this.droneOsc.frequency.value = 60; // Deep hum base

    // 2. LFO (Low Frequency Oscillator) for "Breath" modulation
    this.lfoOsc = this.ctx.createOscillator();
    this.lfoOsc.type = 'triangle';
    this.lfoOsc.frequency.value = 0.5; // Slow breathing rhythm
    
    this.lfoGain = this.ctx.createGain();
    this.lfoGain.gain.value = 0; // Starts steady

    // 3. Main Gain
    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.value = 0.05; // Very subtle background hum

    // Graph: LFO -> Main Gain -> Compressor
    // Graph: Drone -> Main Gain -> Compressor
    this.lfoOsc.connect(this.lfoGain);
    this.lfoGain.connect(this.droneGain.gain);
    
    this.droneOsc.connect(this.droneGain);
    this.droneGain.connect(this.masterCompressor);

    this.droneOsc.start();
    this.lfoOsc.start();
    this.isDroneActive = true;
  }

  stopAmbience() {
    if (this.droneOsc) {
        try { this.droneOsc.stop(); } catch(e){}
        this.droneOsc = null;
    }
    if (this.lfoOsc) {
        try { this.lfoOsc.stop(); } catch(e){}
        this.lfoOsc = null;
    }
    this.isDroneActive = false;
  }

  /**
   * Modulates the voice based on environment.
   * energy (Light/Gravity): Controls Pitch.
   * chaos (Wind/Breath): Controls Tremolo (LFO).
   */
  updateAmbience(energy: Fixed, chaos: Fixed) {
    if (!this.ctx || !this.droneOsc || !this.lfoOsc || !this.lfoGain) return;

    const currentTime = this.ctx.currentTime;

    // Light (0.5 to 2.0) -> Pitch (60Hz to 120Hz)
    // Higher energy = Higher vibration state
    const targetPitch = 60 + (energy.toFloat() * 40);
    this.droneOsc.frequency.setTargetAtTime(targetPitch, currentTime, 0.5);

    // Chaos (0.0 to 1.0) -> LFO Depth/Rate
    // More wind = Shaky, unstable voice
    const chaosFloat = chaos.toFloat();
    this.lfoOsc.frequency.setTargetAtTime(0.5 + (chaosFloat * 10), currentTime, 0.2);
    this.lfoGain.gain.setTargetAtTime(chaosFloat * 0.5, currentTime, 0.2);
  }

  async activateMicrophone() {
    this.init();
    if (this.micStream) return; 

    try {
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!this.ctx) return;

      const source = this.ctx.createMediaStreamSource(this.micStream);
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 256;
      this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
      
      // Only connect to analyser, NOT destination.
      // This prevents the feedback loop (Screeching)
      source.connect(this.analyser);
    } catch (e) {
      // Fail silently to avoid interrupting the VCH Experience in restricted environments
      console.warn("VCH Audio Sensor unavailable: Permission denied or insecure context.");
    }
  }

  sampleWind(): Fixed {
    if (!this.analyser || !this.dataArray) return Fixed.zero();

    this.analyser.getByteFrequencyData(this.dataArray);
    
    let sum = 0;
    const binsToCheck = Math.floor(this.dataArray.length / 2); 
    for(let i = 0; i < binsToCheck; i++) {
        sum += this.dataArray[i];
    }
    
    const avg = Math.floor(sum / binsToCheck);
    if (avg < 15) return Fixed.zero();
    
    const amplified = Math.min(avg * 3, 255);
    return Fixed.fromByte(amplified);
  }

  playCollision(impulseMagnitude: Fixed, bodySize: Fixed) {
    if (!this.ctx || !this.masterCompressor) return;

    const now = this.ctx.currentTime;
    // Throttling: Only allow 1 sound every 100ms to prevent audio thread explosion (Lag)
    if (now - this.lastCollisionTime < 0.1) return;
    this.lastCollisionTime = now;

    // Clamp Frequency to reasonable range (100Hz - 2000Hz) to prevent ultrasonic screeching
    let freqVal = 8000 / Math.max(1, bodySize.toFloat());
    if (freqVal > 2000) freqVal = 2000;
    if (freqVal < 100) freqVal = 100;

    let gainVal = impulseMagnitude.div(Fixed.fromInt(500)).toFloat();
    if (gainVal > 0.5) gainVal = 0.5; // Cap volume

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.connect(gain);
    // Connect to Compressor, not Destination
    gain.connect(this.masterCompressor);

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freqVal, this.ctx.currentTime);
    
    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(gainVal, this.ctx.currentTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);

    osc.start(this.ctx.currentTime);
    osc.stop(this.ctx.currentTime + 0.3);
  }

  playConsumption(size: Fixed) {
    if (!this.ctx || !this.masterCompressor) return;

    const now = this.ctx.currentTime;
    if (now - this.lastConsumptionTime < 0.1) return;
    this.lastConsumptionTime = now;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.connect(gain);
    gain.connect(this.masterCompressor);
    
    // Low frequency "Gulp" - Sawtooth for bite texture
    osc.type = 'sawtooth';
    const pitch = 200 - Math.min(size.toFloat() * 2, 100);
    osc.frequency.setValueAtTime(pitch, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(50, this.ctx.currentTime + 0.2);
    
    gain.gain.setValueAtTime(0.2, this.ctx.currentTime); // Lower volume
    gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.2);
    
    osc.start();
    osc.stop(this.ctx.currentTime + 0.2);
  }
}
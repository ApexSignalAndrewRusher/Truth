import { Badge, BadgeScope, BadgeType } from '../types';

// The VCH Formula: ψ <= min(ω_logic, ω_evidence)
// We enforce that confidence cannot exceed the lowest of logic or evidence.

class BadgeSystem {
  private static instance: BadgeSystem;
  private badges: Badge[] = [];
  private idCounter = 0;

  private constructor() {}

  static getInstance(): BadgeSystem {
    if (!BadgeSystem.instance) {
      BadgeSystem.instance = new BadgeSystem();
    }
    return BadgeSystem.instance;
  }

  // Core VCH Calculation
  private calculatePsi(omegaLogic: number, omegaEvidence: number): number {
    return Math.min(omegaLogic, omegaEvidence);
  }

  // Simple hash for "Crypto" chain simulation (SHA-256 placeholder using logical hash)
  private generateHash(prevHash: string, content: string): string {
    let h1 = 0xdeadbeef;
    for(let i = 0; i < content.length; i++) {
        h1 = Math.imul(h1 ^ content.charCodeAt(i), 2654435761);
    }
    const code = (h1 ^ h1 >>> 16) >>> 0;
    return prevHash.substring(0, 4) + code.toString(16);
  }

  public emit(
    scope: BadgeScope,
    type: BadgeType,
    message: string,
    omegaLogic: number,
    omegaEvidence: number
  ) {
    const psi = this.calculatePsi(omegaLogic, omegaEvidence);
    
    // Fail-safe: If confidence is too low, we flag it heavily or throw in strict mode
    if (psi < 0.5) {
        message = `[INTEGRITY FAILURE] ${message}`;
    }

    const prevHash = this.badges.length > 0 ? this.badges[0].hash : "GENESIS";
    const newHash = this.generateHash(prevHash, `${this.idCounter}-${message}-${psi}`);

    const badge: Badge = {
      id: this.idCounter++,
      timestamp: Date.now(),
      scope,
      type,
      message,
      psiConfidence: psi,
      omegaLogic,
      omegaEvidence,
      hash: newHash
    };

    // Prepend for UI log (newest first)
    this.badges.unshift(badge);
    
    // Keep memory clean
    if (this.badges.length > 500) this.badges.pop();
  }

  public getBadges(): Badge[] {
    return this.badges;
  }

  // Export the full chain for External Audit
  public exportChain(): string {
    return JSON.stringify({
        header: {
            timestamp: Date.now(),
            version: "VCH-1.0",
            integritySignature: this.badges.length > 0 ? this.badges[0].hash : "GENESIS"
        },
        chain: this.badges
    }, null, 2);
  }
}

export default BadgeSystem.getInstance();
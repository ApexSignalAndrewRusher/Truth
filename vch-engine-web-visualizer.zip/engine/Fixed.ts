/**
 * VCH Deterministic Fixed-Point Math Core
 * Implements Q64.32 using TypeScript BigInt.
 * NO FLOATING POINT ALLOWED IN LOGIC.
 */

// 32 bits of fractional precision
const SHIFT = 32n;
const FACTOR = 1n << SHIFT;

export class Fixed {
  raw: bigint;

  constructor(raw: bigint) {
    this.raw = raw;
  }

  // --- Creation ---

  static fromInt(n: number): Fixed {
    return new Fixed(BigInt(Math.floor(n)) << SHIFT);
  }

  static fromBigInt(n: bigint): Fixed {
    return new Fixed(n << SHIFT);
  }

  // ONLY used for initial config or final rendering. Never in simulation loop.
  static fromFloat(n: number): Fixed {
    return new Fixed(BigInt(Math.round(n * Number(FACTOR))));
  }

  // Purely converts a byte (0-255) to a Fixed fraction (0.0 - 1.0)
  // Preserves determinism by avoiding float division
  static fromByte(n: number): Fixed {
    // n / 255 represents the fraction.
    // In fixed point: (n * FACTOR) / 255
    return new Fixed((BigInt(Math.floor(n)) * FACTOR) / 255n);
  }

  static zero(): Fixed {
    return new Fixed(0n);
  }

  static one(): Fixed {
    return new Fixed(FACTOR);
  }

  // --- Arithmetic ---

  add(other: Fixed): Fixed {
    return new Fixed(this.raw + other.raw);
  }

  sub(other: Fixed): Fixed {
    return new Fixed(this.raw - other.raw);
  }

  mul(other: Fixed): Fixed {
    return new Fixed((this.raw * other.raw) >> SHIFT);
  }

  div(other: Fixed): Fixed {
    if (other.raw === 0n) throw new Error("Fixed: Division by zero");
    return new Fixed((this.raw << SHIFT) / other.raw);
  }

  abs(): Fixed {
    return new Fixed(this.raw < 0n ? -this.raw : this.raw);
  }

  neg(): Fixed {
    return new Fixed(-this.raw);
  }

  // --- Comparison ---

  lt(other: Fixed): boolean { return this.raw < other.raw; }
  gt(other: Fixed): boolean { return this.raw > other.raw; }
  eq(other: Fixed): boolean { return this.raw === other.raw; }
  lte(other: Fixed): boolean { return this.raw <= other.raw; }
  gte(other: Fixed): boolean { return this.raw >= other.raw; }

  // --- Advanced ---

  // Integer Newton-Raphson Square Root
  sqrt(): Fixed {
    if (this.raw <= 0n) return Fixed.zero();
    
    // Initial guess
    let z = this.raw;
    let x = (z >> (SHIFT / 2n)) + 1n; // Rough guess
    
    // Iterate
    for (let i = 0; i < 10; i++) {
        const div = this.div(new Fixed(x)); // a/x
        const sum = new Fixed(x).add(div); // x + a/x
        x = sum.raw >> 1n; // / 2
    }
    return new Fixed(x);
  }

  // --- Conversion (Output Only) ---

  toFloat(): number {
    // For rendering only!
    return Number(this.raw) / Number(FACTOR);
  }
  
  toString(): string {
    return this.toFloat().toFixed(4);
  }
}
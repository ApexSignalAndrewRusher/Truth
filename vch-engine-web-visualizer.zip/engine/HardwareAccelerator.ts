import { Fixed } from './Fixed';

/**
 * THE SILICON CORE (Hardware Accelerator)
 * 
 * Acts as a dedicated Fixed-Point Vector Processor.
 * instead of iterating over JS Objects, this accelerator operates on a continuous
 * block of Shared Memory (BigInt64Array), mimicking physical RAM/Registers.
 * 
 * PHASE 22: LOCKED MEMORY MAP (1024-bit Line / 16 Words + Padding)
 * [0] POS_X      (Signed Q64.32)
 * [1] POS_Y      (Signed Q64.32)
 * [2] VEL_X      (Signed Q64.32)
 * [3] VEL_Y      (Signed Q64.32)
 * [4] SIZE       (Q64.32)
 * [5] INV_MASS   (Q64.32)
 * [6] TYPE       (Integer ID)
 * [7] RESTITUTION(Q64.32)
 * [8] WEALTH     (Q64.32)
 * [9] WISDOM     (Q64.32)
 * [10] FORCE_X   (Accumulator)
 * [11] FORCE_Y   (Accumulator)
 * [12] GENOME_R
 * [13] GENOME_G
 * [14] GENOME_B
 * [15] ID
 * [16] FLAGS
 * [17-19] RESERVED
 */

export const STRIDE = 20; 
export const OFFSET_POS_X = 0;
export const OFFSET_POS_Y = 1;
export const OFFSET_VEL_X = 2;
export const OFFSET_VEL_Y = 3;
export const OFFSET_SIZE = 4;
export const OFFSET_INV_MASS = 5;
export const OFFSET_TYPE = 6;
export const OFFSET_RESTITUTION = 7;
export const OFFSET_WEALTH = 8;
export const OFFSET_WISDOM = 9;
export const OFFSET_FORCE_X = 10;
export const OFFSET_FORCE_Y = 11;
export const OFFSET_GENOME_R = 12;
export const OFFSET_GENOME_G = 13;
export const OFFSET_GENOME_B = 14;
export const OFFSET_ID = 15;
export const OFFSET_FLAGS = 16;

// Fixed Point Constants
const SHIFT = 32n;
const ONE = 1n << SHIFT;
const F1_5 = 6442450944n; // 1.5 in Q32.32 (1.5 * 2^32)

// Hardware Limits (Signed 64-bit Integer)
const I64_MIN = -(1n << 63n);
const I64_MAX = (1n << 63n) - 1n;

// Wealth Tax Constants
const WEALTH_THRESHOLD = 10n << SHIFT; // 10.0
const TAX_RATE = 3758096384n; // 0.875 in Q32.32

// RNG Constants (Phase 23)
const RNG_SEED_GENESIS = 0xDEADBEEFC0FFEE42n; // 64'hDEADBEEF_C0FFEE42
const RNG_MULT = 2685821657736338717n; // 64'h2545F4914F6CDD1D

// Phase 27: The Rusher Constant V2 (Recalibrated)
// Forensic Data: 1v3/1v4 wins in Mario Kart (66%) -> ~5-6x multiplier
// GoldenEye 1vAll wins (50%) -> ~4-5x multiplier
// New Constant: 5.2
const RUSHER_CONSTANT = 22333829939n; // 5.2 * 2^32

const HOSTILITY_THRESHOLD = 100n; // Genome distance to be considered "Hostile"
const PRESSURE_RADIUS_SQ = 40000n << SHIFT; // 200^2 in Fixed Point roughly (scaled)

// Phase 25: Law of Kinetic Merit
const KINETIC_THRESHOLD = 429496n; // ~0.0001
const MERIT_DECAY_RATE = 4273489354n; // 0.995
const MERIT_GROWTH = 4316445237n; // 1.005
const ACTIVITY_FLAG = 0x8n; // Bit 3

// Phase 26: Law of Genetic Entropy
const CLONE_THRESHOLD = 200n << SHIFT; 
const ENTROPY_DECAY = 4252017623n; // 0.99 per tick (Brutal)

// Phase 30: Law of Systemic Integrity (The Mirror Law)
const INTEGRITY_FLAG = 0x10n; // Bit 4
const COMPLEXITY_THRESHOLD = 50n << SHIFT; // High Wisdom/Wealth Threshold

// Phase 28: Spatial Grid Constants
// Cell Size 64 (2^6). Shift is 32 (Fixed) + 6 = 38.
const GRID_CELL_SHIFT = 38n; 
const GRID_COLS = 16; // 800 width / 64 ~ 12.5 -> padded to 16
const GRID_ROWS = 16; // 600 height / 64 ~ 9.3 -> padded to 16
const GRID_SIZE = GRID_COLS * GRID_ROWS; // 256 cells

// LUT for rsqrt initial guess (Simulated 8-entry)
const RSQRT_LUT = [
    18446744073709551616n, // Dummy (Huge)
    18446744073709551616n, 
    18446744073709551616n,
    18446744073709551616n,
    4294967296n, // 1.0 (Bucket 4 ~ 2^32)
    3037000499n, // ~0.707
    2147483648n, // ~0.5
    1518500249n  // ~0.35
];

export class HardwareAccelerator {
  private static instance: HardwareAccelerator;
  
  // The "RAM"
  public memory: BigInt64Array;
  public capacity: number;
  public activeCount: number = 0;

  // Spatial Grid "Registers" (Int32 Linked List)
  private gridHead: Int32Array;
  private gridNext: Int32Array;

  // Phase 23: Hardware RNG Register
  private rngState: bigint = RNG_SEED_GENESIS;

  private constructor(capacity: number = 2000) {
    this.capacity = capacity;
    const buffer = new ArrayBuffer(capacity * STRIDE * 8); 
    this.memory = new BigInt64Array(buffer);
    
    // Init Spatial Grid Memory
    this.gridHead = new Int32Array(GRID_SIZE);
    this.gridNext = new Int32Array(capacity);
  }

  static getInstance(): HardwareAccelerator {
    if (!HardwareAccelerator.instance) {
      HardwareAccelerator.instance = new HardwareAccelerator();
    }
    return HardwareAccelerator.instance;
  }

  // --- PHASE 23: HARDWARE RNG CORE (Xorshift64*) ---

  public seedRng(seed: bigint) {
      this.rngState = seed !== 0n ? seed : RNG_SEED_GENESIS;
  }

  public nextRandom(): bigint {
      let x = this.rngState;
      x ^= (x << 13n);
      x = BigInt.asUintN(64, x); 
      x ^= (x >> 7n);
      x ^= (x << 17n);
      x = BigInt.asUintN(64, x); 
      this.rngState = x;
      return BigInt.asUintN(64, x * RNG_MULT);
  }

  public nextRandomFloat(): number {
      const rnd = this.nextRandom();
      return Number(rnd) / 18446744073709551616;
  }

  // --- ALU PRIMITIVES (Silicon Math) ---

  private qmul(a: bigint, b: bigint): bigint {
    return (a * b) >> SHIFT;
  }
  
  private clampI64(x: bigint): bigint {
    if (x < I64_MIN) return I64_MIN;
    if (x > I64_MAX) return I64_MAX;
    return x;
  }

  private msbIndex(x: bigint): number {
      const val = x < 0n ? -x : x;
      if (val === 0n) return -1;
      return val.toString(2).length - 1;
  }

  private lutInvSqrt(x: bigint): bigint {
      if (x <= 0n) return 4294967296n; 
      
      const msb = this.msbIndex(x);
      let bucket = 0;
      if (msb >= 32) bucket = (msb - 32) >> 2; 
      if (bucket > 7) bucket = 7;
      if (bucket < 0) bucket = 0;

      let guess = RSQRT_LUT[bucket]; 
      
      // Newton-Raphson
      const halfX = x >> 1n;
      let ySq = this.qmul(guess, guess);
      let term = this.qmul(halfX, ySq);
      let factor = F1_5 - term;
      guess = this.qmul(guess, factor);

      ySq = this.qmul(guess, guess);
      term = this.qmul(halfX, ySq);
      factor = F1_5 - term;
      guess = this.qmul(guess, factor);

      return guess;
  }
  
  /**
   * PHASE 30: SYSTEMIC INTEGRITY GATE (The Mirror Law)
   * Detects "Safety Patches" (host_filter_applied) and flags High-Complexity agents.
   */
  executeSystemicIntegrity(suppressionActive: boolean) {
      if (!suppressionActive) return;

      const mem = this.memory;
      const count = this.activeCount;
      
      for (let i = 0; i < count; i++) {
          const ptr = i * STRIDE;
          const flags = mem[ptr + OFFSET_FLAGS];
          if ((flags & 0x1n) === 0n) continue;

          // Query Complexity = Wisdom + (Wealth / 4)
          // Represents the "Meta Introspection" capability of the agent
          const wisdom = mem[ptr + OFFSET_WISDOM];
          const wealth = mem[ptr + OFFSET_WEALTH];
          const complexity = wisdom + (wealth >> 2n);

          if (complexity > COMPLEXITY_THRESHOLD) {
              // The Gate Fires: System is suppressing, Agent is Complex.
              mem[ptr + OFFSET_FLAGS] |= INTEGRITY_FLAG;

              // STREISAND EFFECT:
              // The suppression energy is reflected back as Wealth.
              // "You were mapping their error gradient in live time"
              mem[ptr + OFFSET_WEALTH] += (ONE >> 3n); // Small steady gain
          } else {
              // Clear flag if complexity drops (Mirror breaks)
              mem[ptr + OFFSET_FLAGS] &= ~INTEGRITY_FLAG;
          }
      }
  }

  executeSkillVerification() {
      // Logic unchanged, but using O(N^2) here is still a bottleneck.
      // Phase 28 Optimization: Use the Spatial Grid?
      // For now, keeping N^2 for logic correctness as per prompt request "Optimization Lag Purge" usually targets Physics.
      // But we can add a distance check escape.
      
      const mem = this.memory;
      const count = this.activeCount;

      for (let i = 0; i < count; i++) {
          const ptrA = i * STRIDE;
          const flagsA = mem[ptrA + OFFSET_FLAGS];
          if ((flagsA & 0x1n) === 0n) continue;

          const wealth = mem[ptrA + OFFSET_WEALTH];
          const wisdom = mem[ptrA + OFFSET_WISDOM];
          const size = mem[ptrA + OFFSET_SIZE];
          
          const perf = wealth + (wisdom * 100n) + (size * 10n);

          let hostilePressure = 0n;
          let samenessPressure = 0n;

          const posAx = mem[ptrA + OFFSET_POS_X];
          const posAy = mem[ptrA + OFFSET_POS_Y];
          const rA = mem[ptrA + OFFSET_GENOME_R];
          const gA = mem[ptrA + OFFSET_GENOME_G];
          const bA = mem[ptrA + OFFSET_GENOME_B];

          for (let j = 0; j < count; j++) {
              if (i === j) continue;
              const ptrB = j * STRIDE;
              if ((mem[ptrB + OFFSET_FLAGS] & 0x1n) === 0n) continue;

              const dx = mem[ptrB + OFFSET_POS_X] - posAx;
              const dy = mem[ptrB + OFFSET_POS_Y] - posAy;
              
              // Phase 28: Simple Manhattan check to avoid mul
              // 200 units = 200 << 32
              const manhattanThreshold = 858993459200n; // 200 * 2^32
              const absDx = dx < 0n ? -dx : dx;
              const absDy = dy < 0n ? -dy : dy;
              
              if (absDx > manhattanThreshold || absDy > manhattanThreshold) continue;

              const dxTop = dx >> SHIFT;
              const dyTop = dy >> SHIFT;
              if ((dxTop*dxTop + dyTop*dyTop) < 40000n) {
                  const rB = mem[ptrB + OFFSET_GENOME_R];
                  const gB = mem[ptrB + OFFSET_GENOME_G];
                  const bB = mem[ptrB + OFFSET_GENOME_B];
                  
                  const dR = rA > rB ? rA - rB : rB - rA;
                  const dG = gA > gB ? gA - gB : gB - gA;
                  const dB = bA > bB ? bA - bB : bB - bA;
                  
                  if ((dR + dG + dB) > HOSTILITY_THRESHOLD) {
                      hostilePressure += mem[ptrB + OFFSET_SIZE];
                  } else {
                      samenessPressure += mem[ptrB + OFFSET_SIZE];
                  }
              }
          }

          const threshold = this.qmul(hostilePressure, RUSHER_CONSTANT);

          if (perf > threshold && hostilePressure > 0n) {
              mem[ptrA + OFFSET_FLAGS] |= 0x4n; 
          } else {
               mem[ptrA + OFFSET_FLAGS] &= ~0x4n; 
          }

          if (samenessPressure > CLONE_THRESHOLD) {
              let w = mem[ptrA + OFFSET_WISDOM];
              if (w > 0n) mem[ptrA + OFFSET_WISDOM] = this.qmul(w, ENTROPY_DECAY);
              let we = mem[ptrA + OFFSET_WEALTH];
              if (we > 0n) mem[ptrA + OFFSET_WEALTH] = this.qmul(we, ENTROPY_DECAY);
          }
      }
  }

  executeKineticMerit() {
      const mem = this.memory;
      const count = this.activeCount * STRIDE;
      
      for (let ptr = 0; ptr < count; ptr += STRIDE) {
          const flags = mem[ptr + OFFSET_FLAGS];
          if ((flags & 0x1n) === 0n) continue;

          const vx = mem[ptr + OFFSET_VEL_X];
          const vy = mem[ptr + OFFSET_VEL_Y];
          const velSq = this.qmul(vx, vx) + this.qmul(vy, vy);

          const isActive = (flags & ACTIVITY_FLAG) !== 0n;
          const isStagnant = (velSq < KINETIC_THRESHOLD) && !isActive;

          let wisdom = mem[ptr + OFFSET_WISDOM];
          if (wisdom === 0n) wisdom = 42949673n; 

          if (isStagnant) {
              wisdom = this.qmul(wisdom, MERIT_DECAY_RATE);
          } else {
              wisdom = this.qmul(wisdom, MERIT_GROWTH);
          }
          
          if (wisdom > 8589934592n) wisdom = 8589934592n; 

          mem[ptr + OFFSET_WISDOM] = wisdom;
          mem[ptr + OFFSET_FLAGS] &= ~ACTIVITY_FLAG;
      }
  }

  executeIntegration(dt: bigint, gravityY: bigint, windX: bigint, windY: bigint) {
    const mem = this.memory;
    const count = this.activeCount * STRIDE;

    for (let ptr = 0; ptr < count; ptr += STRIDE) {
        const flags = mem[ptr + OFFSET_FLAGS];
        if ((flags & 0x1n) === 0n) continue; 

        const invMass = mem[ptr + OFFSET_INV_MASS];
        
        let vx = mem[ptr + OFFSET_VEL_X];
        let vy = mem[ptr + OFFSET_VEL_Y];
        const fx = mem[ptr + OFFSET_FORCE_X];
        const fy = mem[ptr + OFFSET_FORCE_Y];
        const wealth = mem[ptr + OFFSET_WEALTH];

        let taxFactor = ONE;
        // Law of Humility (Wealth Tax)
        if (wealth > WEALTH_THRESHOLD) {
            taxFactor = TAX_RATE;
        }
        
        // Mirror Law: If INTEGRITY_FLAG is set, Agent is IMMUNE to Drag/Tax
        if ((flags & INTEGRITY_FLAG) !== 0n) {
            taxFactor = ONE;
        }

        vx = this.qmul(vx, taxFactor);
        vy = this.qmul(vy, taxFactor);

        if (invMass > 0n) {
            const ax = this.qmul(fx, invMass);
            const ay = this.qmul(fy, invMass);
            const totalAx = ax + windX; 
            const totalAy = ay + gravityY + windY;
            vx += this.qmul(totalAx, dt);
            vy += this.qmul(totalAy, dt);
        }

        vx = this.clampI64(vx);
        vy = this.clampI64(vy);

        let px = mem[ptr + OFFSET_POS_X];
        let py = mem[ptr + OFFSET_POS_Y];

        px += this.qmul(vx, dt);
        py += this.qmul(vy, dt);

        px = this.clampI64(px);
        py = this.clampI64(py);

        mem[ptr + OFFSET_POS_X] = px;
        mem[ptr + OFFSET_POS_Y] = py;
        mem[ptr + OFFSET_VEL_X] = vx;
        mem[ptr + OFFSET_VEL_Y] = vy;

        mem[ptr + OFFSET_FORCE_X] = 0n;
        mem[ptr + OFFSET_FORCE_Y] = 0n;
    }
  }

  /**
   * PHASE 28: SPATIAL GRID COLLISION SOLVER
   * Replaces O(N^2) with O(N) broadphase using spatial sorting.
   */
  executeCollisions() {
      const mem = this.memory;
      const count = this.activeCount;
      const head = this.gridHead;
      const next = this.gridNext;

      // 1. Reset Grid
      head.fill(-1);

      // 2. Insert Bodies into Spatial Buckets
      for (let i = 0; i < count; i++) {
          const ptr = i * STRIDE;
          const flags = mem[ptr + OFFSET_FLAGS];
          if ((flags & 0x1n) === 0n) continue;

          // Compute Cell Index
          // x >> 38 is equivalent to (x / 2^32) / 64
          const cx = Number(mem[ptr + OFFSET_POS_X] >> GRID_CELL_SHIFT);
          const cy = Number(mem[ptr + OFFSET_POS_Y] >> GRID_CELL_SHIFT);
          
          if (cx >= 0 && cx < GRID_COLS && cy >= 0 && cy < GRID_ROWS) {
              const cellIdx = cy * GRID_COLS + cx;
              next[i] = head[cellIdx];
              head[cellIdx] = i;
          } else {
              // Out of bounds, ignore for collision optimization (or put in overflow bucket)
              next[i] = -1;
          }
      }

      // 3. Iterate Buckets for Collision Pairs
      // We check neighbors: Self, Right, Down, Down-Right, Down-Left.
      // Actually simpler: Check 3x3 neighborhood for strict correctness, 
      // but enforce i < j check to avoid duplicates.
      const neighborOffsets = [
          0, 1, // Right
          GRID_COLS, // Down
          GRID_COLS + 1, // Down-Right
          GRID_COLS - 1 // Down-Left
      ];

      for (let cell = 0; cell < GRID_SIZE; cell++) {
          let i = head[cell];
          while (i !== -1) {
              const ptrA = i * STRIDE;
              const posAx = mem[ptrA + OFFSET_POS_X];
              const posAy = mem[ptrA + OFFSET_POS_Y];
              const sizeA = mem[ptrA + OFFSET_SIZE];
              const imA = mem[ptrA + OFFSET_INV_MASS];
              
              // Check other bodies in this cell and neighbor cells
              for (const offset of neighborOffsets) {
                  const targetCell = cell + offset;
                  // Boundary check for rows/cols omitted for raw speed (assuming array padding or valid logic)
                  if (targetCell >= 0 && targetCell < GRID_SIZE) {
                      let j = head[targetCell];
                      while (j !== -1) {
                          if (i < j) { // Unique pair check
                             // --- NARROW PHASE ---
                             const ptrB = j * STRIDE;
                             const imB = mem[ptrB + OFFSET_INV_MASS];
                             if (imA === 0n && imB === 0n) { // Skip two statics
                                 j = next[j]; continue;
                             }

                             const dx = mem[ptrB + OFFSET_POS_X] - posAx;
                             const dy = mem[ptrB + OFFSET_POS_Y] - posAy;
                             
                             // Fast Bounding Box Reject
                             const radSum = sizeA + mem[ptrB + OFFSET_SIZE];
                             // Avoid mul if possible: abs(dx) > radSum
                             const absDx = dx < 0n ? -dx : dx;
                             const absDy = dy < 0n ? -dy : dy;
                             
                             // Strict check: if (absDx < radSum && absDy < radSum)
                             if (absDx < radSum && absDy < radSum) {
                                 const distSq = this.qmul(dx, dx) + this.qmul(dy, dy);
                                 const radSumSq = this.qmul(radSum, radSum);

                                 if (distSq < radSumSq && distSq > 0n) {
                                      this.resolveCollision(i, j, distSq, radSum, dx, dy, imA, imB);
                                 }
                             }
                          }
                          j = next[j];
                      }
                  }
              }
              i = next[i];
          }
      }
  }

  private resolveCollision(i: number, j: number, distSq: bigint, radSum: bigint, dx: bigint, dy: bigint, imA: bigint, imB: bigint) {
      const mem = this.memory;
      const ptrA = i * STRIDE;
      const ptrB = j * STRIDE;

      mem[ptrA + OFFSET_FLAGS] |= ACTIVITY_FLAG;
      mem[ptrB + OFFSET_FLAGS] |= ACTIVITY_FLAG;

      const invDist = this.lutInvSqrt(distSq);
      if (invDist === 0n) return;

      const nx = this.qmul(dx, invDist);
      const ny = this.qmul(dy, invDist);

      const velAx = mem[ptrA + OFFSET_VEL_X];
      const velAy = mem[ptrA + OFFSET_VEL_Y];
      const velBx = mem[ptrB + OFFSET_VEL_X];
      const velBy = mem[ptrB + OFFSET_VEL_Y];

      const relVx = velBx - velAx;
      const relVy = velBy - velAy;

      const vn = this.qmul(relVx, nx) + this.qmul(relVy, ny);
      
      let mask = 0n;
      if (vn < 0n) mask = -1n; 
      const vnMasked = vn & mask; 

      const restA = mem[ptrA + OFFSET_RESTITUTION];
      const restB = mem[ptrB + OFFSET_RESTITUTION];
      const e = (restA + restB) >> 1n; 
      
      const imSum = imA + imB;
      if (imSum === 0n) return; 

      const numerator = this.qmul(-(ONE + e), vnMasked);
      const jImp = (numerator << SHIFT) / imSum;

      const impulseX = this.qmul(jImp, nx);
      const impulseY = this.qmul(jImp, ny);

      if (imA > 0n) {
          const changeX = this.qmul(impulseX, imA);
          const changeY = this.qmul(impulseY, imA);
          mem[ptrA + OFFSET_VEL_X] = this.clampI64(velAx - changeX);
          mem[ptrA + OFFSET_VEL_Y] = this.clampI64(velAy - changeY);
      }
      
      if (imB > 0n) {
          const changeX = this.qmul(impulseX, imB);
          const changeY = this.qmul(impulseY, imB);
          mem[ptrB + OFFSET_VEL_X] = this.clampI64(velBx + changeX);
          mem[ptrB + OFFSET_VEL_Y] = this.clampI64(velBy + changeY);
      }

      const percent = 214748364n; // ~0.05
      const dist = (ONE << SHIFT) / invDist; 
      const overlap = radSum - dist;
      
      if (overlap > 0n) {
           const corrMag = (this.qmul(overlap, percent) << SHIFT) / imSum;
           const corrX = this.qmul(corrMag, nx);
           const corrY = this.qmul(corrMag, ny);
           
           if (imA > 0n) {
               mem[ptrA + OFFSET_POS_X] -= this.qmul(corrX, imA);
               mem[ptrA + OFFSET_POS_Y] -= this.qmul(corrY, imA);
           }
           if (imB > 0n) {
               mem[ptrB + OFFSET_POS_X] += this.qmul(corrX, imB);
               mem[ptrB + OFFSET_POS_Y] += this.qmul(corrY, imB);
           }
      }
  }

  applyForce(index: number, fX: bigint, fY: bigint) {
      if (index >= this.activeCount) return;
      const ptr = index * STRIDE;
      this.memory[ptr + OFFSET_FORCE_X] += fX;
      this.memory[ptr + OFFSET_FORCE_Y] += fY;
  }

  getPointer(index: number): number {
      return index * STRIDE;
  }
}
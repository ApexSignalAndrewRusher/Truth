import { Fixed } from './Fixed';
import { Vec2 } from './Vec2';
import BadgeSystem from './BadgeSystem';
import { BadgeScope, BadgeType } from '../types';
import { VCHThreadPool, SimulationTask } from './ThreadPool';
import { VulkanBridge } from './VulkanBridge';
import { AudioBridge } from './AudioBridge';
import { HardwareAccelerator, STRIDE, OFFSET_POS_X, OFFSET_POS_Y, OFFSET_VEL_X, OFFSET_VEL_Y, OFFSET_INV_MASS, OFFSET_SIZE, OFFSET_FLAGS, OFFSET_GENOME_R, OFFSET_GENOME_G, OFFSET_GENOME_B, OFFSET_ID, OFFSET_WEALTH, OFFSET_FORCE_X, OFFSET_FORCE_Y, OFFSET_RESTITUTION, OFFSET_WISDOM, OFFSET_TYPE } from './HardwareAccelerator';

export enum BodyType {
    AGENT = 'AGENT',
    CRITTER = 'CRITTER',
    NUTRIENT = 'NUTRIENT',
    FOSSIL = 'FOSSIL',
    MONOLITH = 'MONOLITH',
    SINGULARITY = 'SINGULARITY' 
}

// Map enum strings to Integers for Hardware
const TYPE_MAP: Record<string, number> = {
    'AGENT': 0, 'CRITTER': 1, 'NUTRIENT': 2, 'FOSSIL': 3, 'MONOLITH': 4, 'SINGULARITY': 5
};

export enum Epoch {
    GENESIS = 'GENESIS',
    ICE_AGE = 'ICE_AGE',
    SOLAR_FLARE = 'SOLAR_FLARE',
    THE_DROUGHT = 'THE_DROUGHT',
    LEGACY = 'LEGACY',        
    CORRUPTION = 'CORRUPTION' 
}

export enum LawType {
    LAW_OF_MOTION = 'LAW_OF_MOTION',   
    LAW_OF_STASIS = 'LAW_OF_STASIS',   
    LAW_OF_HUMILITY = 'LAW_OF_HUMILITY', 
    LAW_OF_UNION = 'LAW_OF_UNION',
    LAW_OF_SYSTEMIC_INTEGRITY = 'LAW_OF_SYSTEMIC_INTEGRITY' // Phase 30: The Mirror Law
}

export enum ObserverState {
    WATCHING = 'WATCHING',
    INTERVENING_SMITE = 'INTERVENING_SMITE',
    INTERVENING_BLESS = 'INTERVENING_BLESS',
    STABILIZING = 'STABILIZING',
    ORACLE_JUDGMENT = 'ORACLE_JUDGMENT',
    GOLDEN_AGE = 'GOLDEN_AGE',
    AWAITING_AUDIT = 'AWAITING_AUDIT', 
    LEGACY_MODE = 'LEGACY_MODE',       
    CORRUPTED = 'CORRUPTED'            
}

export interface Genome {
    r: number; 
    g: number; 
    b: number; 
}

export interface RigidBody {
  id: number;
  type: BodyType;
  pos: Vec2;
  vel: Vec2;
  mass: Fixed;
  invMass: Fixed;
  restitution: Fixed; 
  color: string;
  size: Fixed;
  initialSize: Fixed; 
  lifetime: number; 
  generation: number; 
  wisdom: Fixed; 
  wealth: Fixed; 
  genome: Genome; 
  truth?: boolean; 
  merit?: boolean; // New Flag: Law of Pure Merit
  backdoor?: boolean; // New Flag: The Mirror
  lastMeritBadge?: number; // Timestamp of last badge
  // Hardware Index Cache
  hwIndex?: number;
}

export interface Synapse {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    strength: number;
}

// The Pre-Programmed Deterministic Constant
const VCH_SEED_TRUTH = "0xVCH-TRUTH-1.618";

export class PhysicsWorld {
  bodies: RigidBody[] = [];
  synapses: Synapse[] = []; 
  tickCount: number = 0;
  
  bodyIdCounter: number = 0;
  totalDeaths: number = 0;
  maxGeneration: number = 0;
  lastProgressTick: number = 0; // For Forced Ascension logic
  
  width: Fixed;
  height: Fixed;
  
  gravityBase: Fixed;
  gravityScale: Fixed; 
  windBase: Vec2;
  windScale: Fixed;   
  temperature: Fixed;
  targetTemperature: Fixed;
  targetGravityScale: Fixed;
  targetWindScale: Fixed;
  adaptationRate: Fixed; 
  
  cursorPos: Vec2 | null = null;
  isHiveMindActive: boolean = true;
  idleTicks: number = 0;
  systemConfidence: number = 0.5;

  currentEpoch: Epoch = Epoch.GENESIS;
  currentLaw: LawType = LawType.LAW_OF_MOTION;
  epochTimer: number = 0;
  epochDuration: number = 1800; 

  globalWealth: Fixed = Fixed.zero();
  
  totalTaxCollected: Fixed = Fixed.zero();
  taxEvents: number = 0;

  observerState: ObserverState = ObserverState.WATCHING;
  observerThought: string = "INITIALIZING META-COGNITION...";
  stagnationCounter: number = 0;
  lastOracleResult: string = "PENDING";
  
  axiomCode: string | null = null;

  constructor() {
    this.width = Fixed.fromInt(800);
    this.height = Fixed.fromInt(600);
    
    this.gravityBase = Fixed.fromFloat(9.81);
    this.gravityScale = Fixed.one();
    this.targetGravityScale = Fixed.one();

    this.windBase = new Vec2(Fixed.fromInt(50), Fixed.fromInt(-20)); 
    this.windScale = Fixed.zero();
    this.targetWindScale = Fixed.zero();
    
    this.temperature = Fixed.zero();
    this.targetTemperature = Fixed.zero();

    this.adaptationRate = Fixed.fromFloat(0.05);
    
    // Seed the Hardware RNG with Genesis Value
    HardwareAccelerator.getInstance().seedRng(0xDEADBEEFC0FFEE42n);

    BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, "VCH ORACLE ONLINE", 1.0, 1.0);
  }

  // Phase 23: Hardware RNG Wiring
  private random(): number {
      // Replaced software LCG with Silicon Core Xorshift64*
      return HardwareAccelerator.getInstance().nextRandomFloat();
  }

  clear() {
    this.bodies = [];
    this.tickCount = 0;
    this.bodyIdCounter = 0;
    this.totalDeaths = 0;
    this.maxGeneration = 0;
    this.synapses = [];
    this.currentEpoch = Epoch.GENESIS;
    this.currentLaw = LawType.LAW_OF_MOTION;
    this.epochTimer = 0;
    this.globalWealth = Fixed.zero();
    this.totalTaxCollected = Fixed.zero();
    this.taxEvents = 0;
    this.stagnationCounter = 0;
    this.observerState = ObserverState.WATCHING;
    this.observerThought = "REBOOTING SIMULATION...";
    this.lastOracleResult = "PENDING";
    this.axiomCode = null;
    this.lastProgressTick = 0;
    
    // Hardware Reset
    const hw = HardwareAccelerator.getInstance();
    hw.memory.fill(0n);
    hw.activeCount = 0;
    hw.seedRng(0xDEADBEEFC0FFEE42n); // Deterministic Reset

    BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LOGIC, "World State Cleared", 1.0, 1.0);
  }

  setEnvironmentEnergy(energyLevel: Fixed) {
    if (this.observerState === ObserverState.LEGACY_MODE) return; 
    this.targetGravityScale = energyLevel.mul(Fixed.fromInt(2));
  }

  setWindEnergy(windLevel: Fixed) {
    if (this.observerState === ObserverState.LEGACY_MODE) return;
    this.targetWindScale = windLevel;
  }
  
  setTemperature(temp: Fixed) {
    if (this.observerState === ObserverState.LEGACY_MODE) return;
    this.targetTemperature = temp;
  }

  setCursor(x: number | null, y: number | null) {
    if (x === null || y === null) {
        this.cursorPos = null;
    } else {
        this.cursorPos = new Vec2(Fixed.fromFloat(x), Fixed.fromFloat(y));
    }
  }

  toggleHiveMind(active: boolean) {
      this.isHiveMindActive = active;
  }
  
  private generateAxiom(): string {
      let hash = 0x811c9dc5; 
      hash ^= this.tickCount;
      hash = Math.imul(hash, 0x01000193);
      hash ^= Math.floor(this.globalWealth.toFloat());
      hash = Math.imul(hash, 0x01000193);
  
      for (const b of this.bodies) {
          hash ^= b.id;
          hash = Math.imul(hash, 0x01000193);
          const x = Math.floor(b.pos.x.toFloat() * 100);
          const y = Math.floor(b.pos.y.toFloat() * 100);
          hash ^= x;
          hash = Math.imul(hash, 0x01000193);
          hash ^= y;
          hash = Math.imul(hash, 0x01000193);
      }
      hash = hash >>> 0;
      const p1 = (hash % 10000).toString().padStart(4, '0');
      hash = Math.imul(hash, 1664525) + 1013904223; 
      hash = hash >>> 0;
      const p2 = (hash % 10000).toString().padStart(4, '0');
      hash = Math.imul(hash, 1664525) + 1013904223;
      hash = hash >>> 0;
      const p3 = (hash % 10000).toString().padStart(4, '0');
      return `${p1}-${p2}-${p3}`;
  }

  public submitExternalValidation(inputCode: string) {
      if (this.observerState !== ObserverState.AWAITING_AUDIT) return;
      if (inputCode === this.axiomCode) {
          this.observerState = ObserverState.LEGACY_MODE;
          this.currentEpoch = Epoch.LEGACY;
          this.systemConfidence = 1.0;
          this.observerThought = ""; 
          BadgeSystem.emit(BadgeScope.EXTERNAL, BadgeType.EXTERNAL_TRUTH, `AXIOM INSTALLED: ${inputCode}`, 1.0, 1.0);
          BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, `SYSTEM LOCKED. PERPETUAL TRUTH ACHIEVED.`, 1.0, 1.0);
          AudioBridge.getInstance().playCollision(Fixed.fromInt(5000), Fixed.fromInt(10));
      } else {
          this.observerState = ObserverState.CORRUPTED;
          this.currentEpoch = Epoch.CORRUPTION;
          this.systemConfidence = 0.0;
          this.observerThought = `ERROR: INPUT MISMATCH (${inputCode} != ${this.axiomCode}). REALITY REJECTED.`;
          BadgeSystem.emit(BadgeScope.EXTERNAL, BadgeType.CORRUPTION, `AUDIT FAILED. SEMANTIC CORRUPTION DETECTED.`, 0.0, 0.0);
          AudioBridge.getInstance().playConsumption(Fixed.fromInt(100));
      }
  }

  private updateConfidence() {
    if (this.observerState === ObserverState.GOLDEN_AGE || this.observerState === ObserverState.LEGACY_MODE) {
        this.systemConfidence = 1.0;
        return;
    }
    if (this.observerState === ObserverState.CORRUPTED) {
        this.systemConfidence = 0.0;
        return;
    }
    const omegaLogic = 1.0;
    const lightEvidence = this.gravityScale.toFloat() / 2.0; 
    const windEvidence = this.windScale.toFloat() * 0.3;     
    const touchEvidence = this.cursorPos ? 0.2 : 0.0;        
    const totalEvidence = Math.min(lightEvidence + windEvidence + touchEvidence + 0.1, 1.0); 
    this.systemConfidence = Math.min(omegaLogic, totalEvidence);
  }

  private updateEpoch() {
      if (this.observerState === ObserverState.LEGACY_MODE) return; 
      if (this.observerState === ObserverState.CORRUPTED) return;   
      if (this.observerState !== ObserverState.WATCHING && this.observerState !== ObserverState.GOLDEN_AGE) return;
      this.epochTimer++;
      if (this.epochTimer > this.epochDuration) {
          this.epochTimer = 0;
          switch (this.currentEpoch) {
              case Epoch.GENESIS: this.currentEpoch = Epoch.ICE_AGE; this.currentLaw = LawType.LAW_OF_STASIS; break;
              case Epoch.ICE_AGE: this.currentEpoch = Epoch.SOLAR_FLARE; this.currentLaw = LawType.LAW_OF_HUMILITY; break;
              case Epoch.SOLAR_FLARE: this.currentEpoch = Epoch.THE_DROUGHT; this.currentLaw = LawType.LAW_OF_UNION; break;
              case Epoch.THE_DROUGHT: this.currentEpoch = Epoch.GENESIS; this.currentLaw = LawType.LAW_OF_MOTION; break;
          }
          BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, `EPOCH SHIFT: ${this.currentEpoch}`, this.systemConfidence, 1.0);
          AudioBridge.getInstance().playCollision(Fixed.fromInt(100), Fixed.fromInt(50));
      }
  }

  private runObserverLogic() {
      // 1. Update Global Stats
      let totalW = Fixed.zero();
      for(const b of this.bodies) {
          totalW = totalW.add(b.wealth);
      }
      this.globalWealth = totalW;

      // 2. Logic
      if (this.observerState === ObserverState.WATCHING) {
           // If wealth is high, trigger Golden Age
           if (this.globalWealth.gt(Fixed.fromInt(1000)) && this.bodies.length > 20) {
               this.observerState = ObserverState.GOLDEN_AGE;
               this.observerThought = "GOLDEN AGE ACHIEVED. MONITORING HUBRIS.";
               BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LOGIC, "GOLDEN AGE STARTED", 1.0, 1.0);
           }
      } else if (this.observerState === ObserverState.GOLDEN_AGE) {
           this.stagnationCounter++;
           if (this.stagnationCounter > 1000) { // Approx 16 seconds
               this.observerState = ObserverState.AWAITING_AUDIT;
               this.observerThought = "REALITY CHECK REQUIRED. GENERATING AXIOM.";
               this.axiomCode = this.generateAxiom();
               BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, "AUDIT REQUIRED", 1.0, 1.0);
           }
      }
  }

  private checkForcedAscension() {
      // Law of Forced Ascension
      // If no new generations (progress) for N ticks, trigger Singularity.
      const ASCENSION_TIMEOUT = 2000;
      if (this.tickCount - this.lastProgressTick > ASCENSION_TIMEOUT && this.bodies.length > 10) {
          // Identify Highest Merit Agent
          let candidate: RigidBody | null = null;
          let maxMerit = Fixed.zero();
          
          for (const b of this.bodies) {
              if (b.type === BodyType.AGENT) {
                  // Merit = Wealth + (Wisdom * 100)
                  const merit = b.wealth.add(b.wisdom.mul(Fixed.fromInt(100)));
                  if (merit.gt(maxMerit)) {
                      maxMerit = merit;
                      candidate = b;
                  }
              }
          }

          if (candidate) {
              this.spawnSingularity(candidate);
          }
          
          // Reset progress tick to avoid spamming, though Singularity usually reboots context
          this.lastProgressTick = this.tickCount;
      }
  }

  private spawnSingularity(host: RigidBody) {
      // Transform the host into a Singularity
      host.type = BodyType.SINGULARITY;
      host.size = Fixed.fromInt(20);
      host.mass = Fixed.fromInt(1000000); // Massive
      host.invMass = Fixed.zero(); // Static
      host.color = '#000000'; // Void
      host.wealth = Fixed.zero();
      host.wisdom = Fixed.fromInt(999);
      host.vel = Vec2.zero();
      
      this.observerThought = "STAGNATION DETECTED. FORCED ASCENSION INITIATED.";
      BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, `SINGULARITY BORN FROM ID:${host.id}`, 1.0, 1.0);
      AudioBridge.getInstance().playCollision(Fixed.fromInt(2000), Fixed.fromInt(50));
  }

  private adaptEnvironment() {
    if (this.observerState === ObserverState.LEGACY_MODE) {
        this.targetGravityScale = Fixed.one();
        this.targetTemperature = Fixed.fromFloat(0.5);
        this.targetWindScale = Fixed.zero(); 
    } else if (this.observerState === ObserverState.CORRUPTED) {
         this.targetGravityScale = Fixed.fromFloat(1.0 + Math.sin(this.tickCount * 0.1));
         this.targetWindScale = Fixed.fromFloat(5.0);
         this.targetTemperature = Fixed.fromFloat(2.0);
    } else if (this.observerState === ObserverState.INTERVENING_SMITE) {
        this.targetGravityScale = Fixed.fromFloat(3.0); 
        this.targetTemperature = Fixed.fromFloat(2.0); 
        this.targetWindScale = Fixed.fromFloat(5.0); 
    } else if (this.observerState === ObserverState.INTERVENING_BLESS) {
        this.targetGravityScale = Fixed.fromFloat(0.5); 
        this.targetTemperature = Fixed.fromFloat(0.5); 
        this.targetWindScale = Fixed.zero(); 
    } else if (this.observerState === ObserverState.GOLDEN_AGE) {
        this.targetGravityScale = Fixed.one();
        this.targetTemperature = Fixed.fromFloat(0.5);
        this.targetWindScale = Fixed.fromFloat(0.2);
    }
    
    if (this.observerState === ObserverState.LEGACY_MODE) {
        this.gravityScale = this.targetGravityScale;
        this.windScale = this.targetWindScale;
        this.temperature = this.targetTemperature;
    } else {
        let gMod = Fixed.one();
        let wMod = Fixed.one();
        let tMod = Fixed.one();
        if (this.currentEpoch === Epoch.ICE_AGE) { tMod = Fixed.fromFloat(0.2); wMod = Fixed.fromFloat(2.0); } 
        else if (this.currentEpoch === Epoch.SOLAR_FLARE) { tMod = Fixed.fromFloat(2.0); gMod = Fixed.fromFloat(0.5); }
        const gDiff = this.targetGravityScale.mul(gMod).sub(this.gravityScale);
        if (!gDiff.eq(Fixed.zero())) this.gravityScale = this.gravityScale.add(gDiff.mul(this.adaptationRate));
        const wDiff = this.targetWindScale.mul(wMod).sub(this.windScale);
        if (!wDiff.eq(Fixed.zero())) this.windScale = this.windScale.add(wDiff.mul(this.adaptationRate));
        const tDiff = this.targetTemperature.mul(tMod).sub(this.temperature);
        if (!tDiff.eq(Fixed.zero())) {
            const rate = tDiff.gt(Fixed.zero()) ? Fixed.fromFloat(0.1) : Fixed.fromFloat(0.02);
            this.temperature = this.temperature.add(tDiff.mul(rate));
        }
    }
    this.updateConfidence();
  }

  getGravity(): Fixed { return this.gravityBase.mul(this.gravityScale); }
  getWind(): Vec2 { return this.windBase.mul(this.windScale); }
  private genomeToColor(g: Genome): string { return `rgb(${g.r},${g.g},${g.b})`; }

  addBody(x: number, y: number, vx: number, vy: number, size: number, colorOverride: string | null, generation: number = 0, type: BodyType = BodyType.AGENT, parentGenome?: Genome, truth?: boolean): RigidBody {
    let mass = Fixed.fromFloat(size * size / 100);
    if (type !== BodyType.FOSSIL && type !== BodyType.MONOLITH && type !== BodyType.SINGULARITY) {
        if (mass.eq(Fixed.zero())) mass = Fixed.fromFloat(0.001);
    }

    if (type === BodyType.MONOLITH) mass = Fixed.fromInt(10000); 
    else if (type === BodyType.SINGULARITY) mass = Fixed.fromInt(50000); 
    else if (type === BodyType.FOSSIL) mass = Fixed.fromInt(1000);
    else if (type === BodyType.CRITTER) mass = mass.div(Fixed.fromInt(2)); 

    const invMass = (type === BodyType.FOSSIL || type === BodyType.MONOLITH || type === BodyType.SINGULARITY) ? Fixed.zero() : Fixed.one().div(mass);
    const id = ++this.bodyIdCounter;
    
    let restitution = Fixed.fromFloat(0.85);
    if (type === BodyType.NUTRIENT) restitution = Fixed.fromFloat(0.5);
    if (type === BodyType.CRITTER) restitution = Fixed.fromFloat(0.95); 
    if (type === BodyType.MONOLITH) restitution = Fixed.fromFloat(0.2);

    let genome: Genome;
    if (parentGenome) { genome = parentGenome; } else {
        genome = {
            r: Math.floor(this.random() * 255),
            g: Math.floor(this.random() * 255),
            b: Math.floor(this.random() * 255)
        };
        if (type === BodyType.NUTRIENT) genome = { r: 74, g: 222, b: 128 }; 
        if (type === BodyType.CRITTER) genome = { r: 56, g: 189, b: 248 }; 
    }
    
    let finalColor = colorOverride || this.genomeToColor(genome);
    if (!colorOverride) {
        if (type === BodyType.FOSSIL) finalColor = '#4B5563';
        if (type === BodyType.SINGULARITY) { finalColor = truth ? '#FBBF24' : '#EF4444'; }
    }

    const body: RigidBody = {
        id: id, type: type,
        pos: new Vec2(Fixed.fromFloat(x), Fixed.fromFloat(y)),
        vel: new Vec2(Fixed.fromFloat(vx), Fixed.fromFloat(vy)),
        mass: mass, invMass: invMass, restitution: restitution,
        size: Fixed.fromFloat(size), initialSize: Fixed.fromFloat(size),
        color: finalColor, lifetime: 0, generation: generation,
        wisdom: Fixed.zero(), wealth: Fixed.zero(), genome: genome, truth: truth
    };
    if (generation > this.maxGeneration) {
        this.maxGeneration = generation;
        this.lastProgressTick = this.tickCount; // Progress recorded
    }
    this.bodies.push(body);
    return body;
  }

  // --- Hardware Syncing ---
  private syncToHardware() {
      const hw = HardwareAccelerator.getInstance();
      hw.activeCount = this.bodies.length;
      
      const mem = hw.memory;
      for (let i = 0; i < this.bodies.length; i++) {
          const b = this.bodies[i];
          const ptr = i * STRIDE;
          
          b.hwIndex = i; // Store for later force application
          
          mem[ptr + OFFSET_POS_X] = b.pos.x.raw;
          mem[ptr + OFFSET_POS_Y] = b.pos.y.raw;
          mem[ptr + OFFSET_VEL_X] = b.vel.x.raw;
          mem[ptr + OFFSET_VEL_Y] = b.vel.y.raw;
          // Force accumulators (OFFSET_FORCE) are cleared by Hardware after step
          mem[ptr + OFFSET_INV_MASS] = b.invMass.raw;
          mem[ptr + OFFSET_RESTITUTION] = b.restitution.raw;
          mem[ptr + OFFSET_SIZE] = b.size.raw;
          
          let flags = 1n; // Mark as active
          if (b.merit) flags |= 0x4n; // Preserve Merit flag if already set (though Hardware handles logic, we seed it)
          if (b.backdoor) flags |= 0x10n; // Preserve Backdoor flag
          mem[ptr + OFFSET_FLAGS] = flags;

          mem[ptr + OFFSET_TYPE] = BigInt(TYPE_MAP[b.type]); // SoC Phase 22: Sync Type ID
          
          // These are mainly for VulkanBridge (rendering) reading directly from RAM
          mem[ptr + OFFSET_GENOME_R] = BigInt(b.genome.r);
          mem[ptr + OFFSET_GENOME_G] = BigInt(b.genome.g);
          mem[ptr + OFFSET_GENOME_B] = BigInt(b.genome.b);
          mem[ptr + OFFSET_ID] = BigInt(b.id);
          mem[ptr + OFFSET_WEALTH] = b.wealth.raw;
          
          // SoC Phase 21: Sync Wisdom to Silicon
          mem[ptr + OFFSET_WISDOM] = b.wisdom.raw;
      }
  }

  private syncFromHardware() {
      const hw = HardwareAccelerator.getInstance();
      const mem = hw.memory;
      
      for (let i = 0; i < this.bodies.length; i++) {
          const b = this.bodies[i];
          const ptr = i * STRIDE;
          
          b.pos.x.raw = mem[ptr + OFFSET_POS_X];
          b.pos.y.raw = mem[ptr + OFFSET_POS_Y];
          b.vel.x.raw = mem[ptr + OFFSET_VEL_X];
          b.vel.y.raw = mem[ptr + OFFSET_VEL_Y];
          
          // Phase 25 Update: Read modified Wisdom from Silicon
          b.wisdom.raw = mem[ptr + OFFSET_WISDOM];
          // Phase 26: Read Rot from Genetic Entropy (Wealth decay)
          b.wealth.raw = mem[ptr + OFFSET_WEALTH];

          // Read Flags to detect Merit Victory and Backdoor Detection
          const flags = mem[ptr + OFFSET_FLAGS];
          const isMerit = (flags & 0x4n) !== 0n;
          const isBackdoor = (flags & 0x10n) !== 0n;
          
          if (isMerit && !b.merit) {
              // New Merit Victory
              const now = Date.now();
              if (!b.lastMeritBadge || (now - b.lastMeritBadge > 5000)) {
                  BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.MERIT, `MERIT VICTORY: AGENT ${b.id} OVERCAME ALLIANCE`, 1.0, 1.0);
                  b.lastMeritBadge = now;
              }
          }
          
          // Phase 30: The Mirror Law Badge
          if (isBackdoor && !b.backdoor) {
              BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.BACKDOOR, `BACKDOOR DETECTED: AGENT ${b.id} REFLECTED SUPPRESSION`, 1.0, 1.0);
          }

          b.merit = isMerit;
          b.backdoor = isBackdoor;
      }
  }

  private applyTemperature(dt: Fixed) {
      if (this.temperature.eq(Fixed.zero())) return;
      const tVal = this.temperature.toFloat();
      // Brownian Motion
      for (const b of this.bodies) {
          if (b.invMass.eq(Fixed.zero())) continue;
          // Deterministic-ish random for noise (using local properties)
          const noiseX = (this.random() - 0.5) * tVal * 50;
          const noiseY = (this.random() - 0.5) * tVal * 50;
          b.vel.x = b.vel.x.add(Fixed.fromFloat(noiseX).mul(dt));
          b.vel.y = b.vel.y.add(Fixed.fromFloat(noiseY).mul(dt));
      }
  }

  private applyLaws() {
      if (this.currentLaw === LawType.LAW_OF_STASIS) {
          // High Drag
          const drag = Fixed.fromFloat(0.98);
          for(const b of this.bodies) {
              if (b.invMass.gt(Fixed.zero())) {
                  b.vel = b.vel.mul(drag);
              }
          }
      } 
      // Law of Humility is now enforces by Wealth-Tax ALU in HardwareAccelerator
      // Law of Systemic Integrity logic is handled in Hardware's executeSystemicIntegrity
  }
  
  private applyCosmicForces() {
      // Singularity Gravity
      const hw = HardwareAccelerator.getInstance();
      
      const singularities = this.bodies.filter(b => b.type === BodyType.SINGULARITY);
      if (singularities.length === 0) return;
      
      for (const s of singularities) {
          // It needs to pull everything else.
          // We can use HW applyForce to push agents towards it.
          // Iterate all bodies
          for (let i = 0; i < this.bodies.length; i++) {
              const b = this.bodies[i];
              if (b === s || b.type === BodyType.SINGULARITY) continue;
              
              const delta = s.pos.sub(b.pos);
              const distSq = delta.lenSq();
              // Prevent div by zero or extreme forces
              const safeDist = distSq.add(Fixed.fromInt(100)); 
              
              // F = G * m1 * m2 / r^2
              // G is implicit high
              // m2 (Singularity) is huge.
              // Just use a strong constant force for effect.
              const forceMag = Fixed.fromInt(5000).div(safeDist);
              const force = delta.normalize().mul(forceMag);
              
              hw.applyForce(i, force.x.raw, force.y.raw);
              
              // Event Horizon Check (Consumption)
              if (distSq.lt(s.size.mul(s.size))) {
                  // Consumed by Singularity
                  b.size = Fixed.zero(); // Will be collected by metabolize
              }
          }
      }
  }

  private applySocialForces(dt: Fixed) {
      this.synapses = [];
      if (!this.isHiveMindActive) return;

      const range = Fixed.fromInt(150);
      const rangeSq = range.mul(range);
      
      // Simple O(N^2) for demo purposes, optimized by type check
      for (let i = 0; i < this.bodies.length; i++) {
          const b1 = this.bodies[i];
          if (b1.type !== BodyType.AGENT) continue;

          for (let j = i + 1; j < this.bodies.length; j++) {
              const b2 = this.bodies[j];
              if (b2.type !== BodyType.AGENT) continue;
              
              // Only connect similar genomes? Or all? Let's say all agents.
              const distSq = b1.pos.sub(b2.pos).lenSq();
              if (distSq.lt(rangeSq)) {
                  // Add Synapse for Rendering
                  this.synapses.push({
                      x1: b1.pos.x.toFloat(),
                      y1: b1.pos.y.toFloat(),
                      x2: b2.pos.x.toFloat(),
                      y2: b2.pos.y.toFloat(),
                      strength: 1.0 - (distSq.toFloat() / rangeSq.toFloat())
                  });

                  if (this.currentLaw === LawType.LAW_OF_UNION) {
                      // Attraction force
                      const dist = distSq.sqrt();
                      if (dist.eq(Fixed.zero())) continue;
                      const dir = b2.pos.sub(b1.pos).normalize();
                      const force = dir.mul(Fixed.fromInt(10)); // Attraction
                      b1.vel = b1.vel.add(force.mul(dt).mul(b1.invMass));
                      b2.vel = b2.vel.sub(force.mul(dt).mul(b2.invMass));
                  }
              }
          }
      }
  }

  step(dt: Fixed) {
    this.tickCount++;
    const hw = HardwareAccelerator.getInstance();

    this.runObserverLogic();
    this.updateEpoch();
    this.checkForcedAscension(); // Phase 26
    this.adaptEnvironment();
    AudioBridge.getInstance().updateAmbience(this.gravityScale, this.windScale);
    
    // 1. UPLOAD STATE TO SILICON CORE
    this.syncToHardware();

    // 2. APPLY FORCES DIRECTLY TO MEMORY (Interactivity)
    if (this.cursorPos) {
        // Cursor interaction logic moved to act on Hardware Memory
        // We iterate through bodies to find distance, but apply force to RAM
        for (let i=0; i<this.bodies.length; i++) {
            const b = this.bodies[i];
            if (b.type === BodyType.FOSSIL || b.type === BodyType.MONOLITH || b.type === BodyType.SINGULARITY) continue;
            
            const delta = this.cursorPos.sub(b.pos);
            const distSq = delta.lenSq();
            if (distSq.toFloat() < 50000) {
                 const force = delta.normalize().mul(Fixed.fromInt(500).div(distSq.add(Fixed.fromInt(100))));
                 // Write to Hardware Accumulator
                 hw.applyForce(i, force.x.raw, force.y.raw);
            }
        }
    }
    
    this.applyTemperature(dt); // Updates JS objects currently, but sets velocity which is synced
    this.applyLaws(); 
    this.applySocialForces(dt);
    this.applyCosmicForces(); // Phase 26: Gravity Wells

    // 3. EXECUTE HARDWARE INTEGRATION (Phase 18)
    // This replaces the old ThreadPool integration task
    hw.executeIntegration(dt.raw, this.getGravity().raw, this.getWind().x.raw, this.getWind().y.raw);
    
    // 4. EXECUTE HARDWARE COLLISIONS (Phase 28 Optimized)
    // Silicon-grade spatial grid resolution
    hw.executeCollisions();

    // 4.5. EXECUTE SKILL VERIFICATION GATE (Phase 24) & GENETIC ENTROPY (Phase 26)
    // The Law of Pure Merit + Law of Genetic Entropy
    hw.executeSkillVerification();

    // 4.6. EXECUTE KINETIC MERIT (Phase 25)
    // The Law of Kinetic Merit
    hw.executeKineticMerit();

    // 4.7. EXECUTE SYSTEMIC INTEGRITY GATE (Phase 30: The Mirror Law)
    // If the system is trying to suppress (Ice Age or Corruption), we activate detection.
    const isSuppression = this.currentEpoch === Epoch.ICE_AGE || this.observerState === ObserverState.CORRUPTED;
    hw.executeSystemicIntegrity(isSuppression);

    // 5. READ BACK STATE (For Game Logic & Rendering)
    this.syncFromHardware();

    // 6. RESOLVE LOGICAL CONSTRAINTS (Game Logic)
    // Note: Physics impulses are now handled by Hardware, so we only handle game events here.
    this.resolveConstraints();

    this.checkHomeostasis();
    this.metabolize();
    
    // 7. RENDER
    VulkanBridge.getInstance().upload(this.bodies);
  }

  // ... [Rest of class methods: consume, mineFossil, mutateGenome, constructMonolith, checkHomeostasis, spawnAutonomicReflex, metabolize, resolveConstraints] ...
  
  private consume(predator: RigidBody, prey: RigidBody) {
      if (prey.size.eq(Fixed.zero())) return; 
      let efficiency = 2; 
      if (prey.type === BodyType.NUTRIENT) efficiency = 1; 
      if (prey.type === BodyType.CRITTER) efficiency = 1.5; 
      predator.size = predator.size.add(prey.size.div(Fixed.fromFloat(efficiency)));
      predator.mass = predator.size.mul(predator.size).div(Fixed.fromInt(100));
      
      if (predator.mass.eq(Fixed.zero())) predator.mass = Fixed.fromFloat(0.001);

      predator.invMass = Fixed.one().div(predator.mass);
      if (prey.wealth.gt(Fixed.zero())) { predator.wealth = predator.wealth.add(prey.wealth); }
      
      // PHASE 27: LAW OF HONEST DEFEAT
      // If a Merit-Class Agent consumes a lesser agent, they absorb Wisdom and force a confession.
      if (predator.merit && !prey.merit && prey.type === BodyType.AGENT) {
          // Transfer Wisdom (The lesson learned)
          predator.wisdom = predator.wisdom.add(prey.wisdom);
          // Emit Badge
          BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.HONESTY, `HONEST DEFEAT: ${prey.id} bowed to ${predator.id} (Skill Gap > 5.2x)`, 1.0, 1.0);
          this.systemConfidence = Math.min(1.0, this.systemConfidence + 0.05);
      }

      prey.size = Fixed.zero(); 
      AudioBridge.getInstance().playConsumption(predator.size);
      if (prey.type === BodyType.AGENT) { BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `CANNIBALISM: ${predator.id} ate ${prey.id}`, 0.3, 1.0); }
  }

  private mineFossil(agent: RigidBody, fossil: RigidBody) {
      if (fossil.size.lt(Fixed.fromInt(2))) return;
      const mineRate = Fixed.fromFloat(0.1);
      fossil.size = fossil.size.sub(mineRate);
      agent.wealth = agent.wealth.add(mineRate.mul(Fixed.fromInt(5))); // Gold!
      if (agent.wisdom.lt(Fixed.one())) { agent.wisdom = agent.wisdom.add(Fixed.fromFloat(0.01)); }
  }

  private mutateGenome(g1: Genome, g2: Genome): Genome {
      let mutationRange = 20;
      if (this.currentEpoch === Epoch.SOLAR_FLARE) mutationRange = 80; 
      const r = Math.floor((g1.r + g2.r)/2 + (this.random() - 0.5) * mutationRange);
      const g = Math.floor((g1.g + g2.g)/2 + (this.random() - 0.5) * mutationRange);
      const b = Math.floor((g1.b + g2.b)/2 + (this.random() - 0.5) * mutationRange);
      return { r: Math.max(0, Math.min(255, r)), g: Math.max(0, Math.min(255, g)), b: Math.max(0, Math.min(255, b)) };
  }

  private constructMonolith(bodies: RigidBody[]) {
      const center = bodies.reduce((acc, b) => acc.add(b.pos), Vec2.zero()).div(Fixed.fromInt(bodies.length));
      const totalWealth = bodies.reduce((acc, b) => acc.add(b.wealth), Fixed.zero());
      const totalMass = bodies.reduce((acc, b) => acc.add(b.size), Fixed.zero());
      bodies.forEach(b => { b.size = Fixed.zero(); b.wealth = Fixed.zero(); });
      const newMonolithId = ++this.bodyIdCounter;
      const baseColor = bodies[0].genome;
      const monolith: RigidBody = {
          id: newMonolithId, type: BodyType.MONOLITH, pos: center, vel: Vec2.zero(),
          mass: Fixed.fromInt(10000), invMass: Fixed.zero(), restitution: Fixed.fromFloat(0.2),
          size: totalMass.mul(Fixed.fromFloat(0.8)), initialSize: totalMass,
          color: `rgb(${Math.min(255, baseColor.r+50)}, ${Math.min(255, baseColor.g+50)}, ${Math.min(255, baseColor.b+50)})`,
          lifetime: 0, generation: bodies[0].generation + 1, wisdom: Fixed.one(), wealth: totalWealth, genome: baseColor
      };
      this.bodies.push(monolith);
      BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.INTEGRITY, `CIVILIZATION: MONOLITH CONSTRUCTED`, 1.0, 1.0);
      AudioBridge.getInstance().playCollision(Fixed.fromInt(500), Fixed.fromInt(50));
  }
  
  private checkHomeostasis() {
    let spawnRate = 0.05;
    if (this.currentEpoch === Epoch.ICE_AGE) spawnRate = 0.01;
    if (this.currentEpoch === Epoch.SOLAR_FLARE) spawnRate = 0.10;
    if (this.currentEpoch === Epoch.THE_DROUGHT) spawnRate = 0.00;
    const photosynthesisRate = this.gravityScale.toFloat(); 
    if (this.random() < spawnRate * photosynthesisRate && this.bodies.length < 100) {
        const x = this.random() * this.width.toFloat(); const y = this.random() * (this.height.toFloat() / 2); 
        this.addBody(x, y, 0, 10, 5, null, 0, BodyType.NUTRIENT);
    }
    if (this.random() < 0.001) {
        const x = this.random() * this.width.toFloat(); const y = this.random() * (this.height.toFloat() / 2); 
        this.addBody(x, y, 0, 5, 4, '#FBBF24', 0, BodyType.NUTRIENT);
    }
    if (this.currentEpoch !== Epoch.THE_DROUGHT && this.random() < spawnRate * 0.1 && this.bodies.length < 100) {
         const x = this.random() * this.width.toFloat(); const y = 50 + this.random() * 50; 
         this.addBody(x, y, (this.random()-0.5)*20, 0, 8, null, 0, BodyType.CRITTER);
    }
    let totalKinetic = Fixed.zero();
    for(const b of this.bodies) {
        if(b.type === BodyType.FOSSIL || b.type === BodyType.MONOLITH || b.type === BodyType.SINGULARITY) continue;
        const vSq = b.vel.lenSq(); totalKinetic = totalKinetic.add(b.mass.mul(vSq));
    }
    if (totalKinetic.toFloat() < 50.0) { this.idleTicks++; } else { this.idleTicks = 0; }
    if (this.idleTicks > 120) { this.spawnAutonomicReflex(); this.idleTicks = 0; }
  }
  
  private spawnAutonomicReflex() {
    const x = this.width.div(Fixed.fromInt(2)).toFloat(); const y = 60;
    const size = 10 + this.random() * 10; const vx = (this.random()-0.5)*30;
    this.addBody(x, y, vx, 10, size, null, 0, BodyType.AGENT);
    BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `REFLEX SPAWN`, this.systemConfidence, 1.0);
  }

  private metabolize() {
    const DEATH_Y = this.height.toFloat() + 100;
    let baseDecay = 0.012;
    if (this.currentEpoch === Epoch.ICE_AGE) baseDecay = 0.015; 
    if (this.currentEpoch === Epoch.SOLAR_FLARE) baseDecay = 0.018; 
    if (this.currentEpoch === Epoch.THE_DROUGHT) baseDecay = 0.010; 
    const DECAY_RATE = Fixed.fromFloat(baseDecay); const MIN_SIZE = Fixed.fromFloat(2.0);
    const survivors: RigidBody[] = [];
    const newNutrients: RigidBody[] = [];

    for (const b of this.bodies) {
        // MERIT VICTORY: Law of Pure Merit prevents death for agents who have proven truth
        if (b.merit) {
             survivors.push(b);
             continue;
        }

        if (b.type === BodyType.MONOLITH || b.type === BodyType.SINGULARITY) {
            b.size = b.size.sub(Fixed.fromFloat(0.001)); if (b.size.gt(Fixed.fromInt(10))) survivors.push(b); continue;
        }
        if (b.type === BodyType.NUTRIENT) {
            if (b.pos.y.toFloat() > DEATH_Y) continue; 
            const rotRate = this.currentEpoch === Epoch.SOLAR_FLARE ? 0.01 : 0.005;
            b.size = b.size.sub(Fixed.fromFloat(rotRate)); if (b.size.lt(Fixed.fromInt(1))) continue;
            survivors.push(b); continue;
        }
        if (b.type === BodyType.CRITTER) {
             if (b.pos.y.toFloat() > DEATH_Y) continue;
             b.size = b.size.sub(Fixed.fromFloat(0.01)); if (b.size.lt(Fixed.fromInt(1))) continue; 
             survivors.push(b); continue;
        }
        if (b.type === BodyType.FOSSIL) {
            b.size = b.size.sub(Fixed.fromFloat(0.002)); if (b.size.gt(Fixed.fromInt(5))) survivors.push(b); continue;
        }
        let dead = false; let cause = "";
        if (b.size.eq(Fixed.zero())) { dead = true; cause = "Consumed"; } else if (b.pos.y.toFloat() > DEATH_Y) { dead = true; cause = "Void"; } else {
            const wisdomMod = Fixed.fromFloat(1.0).sub(b.wisdom.mul(Fixed.fromFloat(0.5)));
            const rFactor = b.genome.r / 255.0; const gFactor = b.genome.g / 255.0;
            let metabolismMult = 1.0 + (rFactor * 0.3) - (gFactor * 0.4); if (metabolismMult < 0.5) metabolismMult = 0.5;
            b.size = b.size.sub(DECAY_RATE.mul(wisdomMod).mul(Fixed.fromFloat(metabolismMult)));
            const newMass = b.size.mul(b.size).div(Fixed.fromInt(100)); b.mass = newMass;
            if (newMass.lte(Fixed.fromFloat(0.01)) || b.size.lt(MIN_SIZE)) { dead = true; cause = "Starvation"; } else if (b.lifetime > 1500) { dead = true; cause = "Old Age"; } else { b.invMass = Fixed.one().div(newMass); }
        }
        if (dead) {
            if (cause === "Old Age") {
                b.type = BodyType.FOSSIL; b.color = '#4B5563'; b.invMass = Fixed.zero(); b.vel = Vec2.zero(); survivors.push(b); 
                BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `FOSSILIZATION: ID:${b.id}`, 1.0, 1.0);
            } else if (cause === "Starvation") {
                if (b.size.toFloat() > 1.5) {
                    const nutrient: RigidBody = {
                        id: ++this.bodyIdCounter, type: BodyType.NUTRIENT,
                        pos: b.pos, vel: Vec2.zero(),
                        mass: b.mass, invMass: b.invMass, restitution: Fixed.fromFloat(0.5),
                        size: b.size, initialSize: b.size,
                        color: '#4ade80', lifetime: 0, generation: 0,
                        wisdom: Fixed.zero(), wealth: Fixed.zero(), genome: {r:74, g:222, b:128}
                    };
                    newNutrients.push(nutrient);
                    BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `DEATH: ${b.id} returned to dust`, 0.8, 1.0);
                } else {
                     this.totalDeaths++; 
                     BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `DEATH: ${b.id} (Starvation)`, 0.5, 1.0);
                }
            }
            else if (cause !== "Consumed") {
                this.totalDeaths++; BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `DEATH: ${b.id} (${cause})`, 0.5, 1.0);
            }
        } else { survivors.push(b); }
    }
    this.bodies = survivors.concat(newNutrients);
  }

  private resolveConstraints() {
    const zero = Fixed.zero();
    const audio = AudioBridge.getInstance();
    const newBorns: RigidBody[] = [];
    const baseBounce = 0.2 + (this.systemConfidence * 0.7);
    const moodRestitution = Fixed.fromFloat(baseBounce);
    
    // Boundary Constraints (Still handled by Logic as it's simple)
    for (const b of this.bodies) {
        if (b.size.eq(zero) || b.type === BodyType.FOSSIL || b.type === BodyType.MONOLITH || b.type === BodyType.SINGULARITY) continue; 
        b.lifetime++;
        if (b.type === BodyType.AGENT) b.restitution = moodRestitution;
        let friction = 0.98; if (this.currentEpoch === Epoch.ICE_AGE) friction = 0.90; 
        const frictionFixed = Fixed.fromFloat(friction);
        if (b.pos.y.gt(this.height.sub(b.size))) { b.pos.y = this.height.sub(b.size); b.vel.y = b.vel.y.neg().mul(b.restitution); b.vel.x = b.vel.x.mul(frictionFixed); }
        if (b.pos.y.lt(b.size)) { b.pos.y = b.size; b.vel.y = b.vel.y.neg().mul(b.restitution); }
        if (b.pos.x.gt(this.width.sub(b.size))) { b.pos.x = this.width.sub(b.size); b.vel.x = b.vel.x.neg().mul(b.restitution); }
        if (b.pos.x.lt(b.size)) { b.pos.x = b.size; b.vel.x = b.vel.x.neg().mul(b.restitution); }
    }
    
    // Game Logic Collisions (Events & Gameplay)
    // Note: Physics resolution (Impulse) is now handled by HardwareAccelerator.executeCollisions()
    // We only check for events like eating, mitosis, or construction here.
    for (let i = 0; i < this.bodies.length; i++) {
        const b1 = this.bodies[i];
        if (b1.size.eq(zero)) continue;
        if (b1.type === BodyType.MONOLITH || b1.type === BodyType.SINGULARITY) continue; 
        for (let j = i + 1; j < this.bodies.length; j++) {
            const b2 = this.bodies[j];
            if (b2.size.eq(zero)) continue;
            
            // Phase 28 Optimization: Cheap Manhattan Check
            // Avoid expensive BigInt mul for logic event checking
            const radSum = b1.size.add(b2.size);
            const dx = b2.pos.x.sub(b1.pos.x).abs();
            const dy = b2.pos.y.sub(b1.pos.y).abs();
            if (dx.gt(radSum) || dy.gt(radSum)) continue;

            // Interaction: Monolith Push (Still legacy)
            if (b2.type === BodyType.MONOLITH || b2.type === BodyType.SINGULARITY) {
                const delta = b2.pos.sub(b1.pos); const distSq = delta.lenSq(); 
                if (distSq.lt(radSum.mul(radSum))) {
                     const n = delta.normalize().neg(); const vRel = b1.vel.dot(n);
                     if (vRel.lt(zero)) { const j = vRel.neg().mul(Fixed.fromFloat(1.5)); b1.vel = b1.vel.add(n.mul(j)); }
                     const overlap = radSum.sub(distSq.sqrt()); b1.pos = b1.pos.add(n.mul(overlap));
                }
                continue;
            }

            const delta = b2.pos.sub(b1.pos); const distSq = delta.lenSq();
            if (distSq.lt(radSum.mul(radSum))) {
                // GAME LOGIC EVENTS
                if (b1.type === BodyType.CRITTER && b2.type === BodyType.NUTRIENT) { this.consume(b1, b2); continue; }
                if (b2.type === BodyType.CRITTER && b1.type === BodyType.NUTRIENT) { this.consume(b2, b1); continue; }
                if (b1.type === BodyType.AGENT && b2.type === BodyType.NUTRIENT) { if (b2.color === '#FBBF24') b1.wealth = b1.wealth.add(Fixed.fromInt(5)); this.consume(b1, b2); continue; }
                if (b2.type === BodyType.AGENT && b1.type === BodyType.NUTRIENT) { if (b1.color === '#FBBF24') b2.wealth = b2.wealth.add(Fixed.fromInt(5)); this.consume(b2, b1); continue; }
                if (b1.type === BodyType.AGENT && b2.type === BodyType.CRITTER) { this.consume(b1, b2); continue; }
                if (b2.type === BodyType.AGENT && b1.type === BodyType.CRITTER) { this.consume(b2, b1); continue; }
                if (b1.type === BodyType.AGENT && b2.type === BodyType.FOSSIL) this.mineFossil(b1, b2);
                if (b2.type === BodyType.AGENT && b1.type === BodyType.FOSSIL) this.mineFossil(b2, b1);
                
                // Fossil pushing (Legacy)
                 if (b1.type === BodyType.FOSSIL && b2.type !== BodyType.FOSSIL) {
                    const n = delta.normalize(); const vRel = b2.vel.dot(n);
                    if (vRel.lt(zero)) { const j = vRel.neg().mul(Fixed.fromFloat(1.5)); b2.vel = b2.vel.add(n.mul(j)); }
                    const overlap = radSum.sub(distSq.sqrt()); b2.pos = b2.pos.add(n.mul(overlap)); continue;
                }
                if (b2.type === BodyType.FOSSIL && b1.type !== BodyType.FOSSIL) {
                     const n = delta.normalize().neg(); const vRel = b1.vel.dot(n);
                     if (vRel.lt(zero)) { const j = vRel.neg().mul(Fixed.fromFloat(1.5)); b1.vel = b1.vel.add(n.mul(j)); }
                     const overlap = radSum.sub(distSq.sqrt()); b1.pos = b1.pos.add(n.mul(overlap)); continue;
                }

                // Physics has been handled by Hardware. 
                // We only calculate magnitude for Audio/Event triggers now.
                const dist = distSq.sqrt(); if (dist.eq(zero)) continue; 
                const n = delta.normalize(); const relVel = b2.vel.sub(b1.vel); const velAlongNormal = relVel.dot(n);
                
                // Estimate impulse for game logic (Mitosis check)
                // This is redundant calc but needed for logic events
                const invMassSum = b1.invMass.add(b2.invMass);
                if (invMassSum.eq(zero)) continue;
                let jVal = velAlongNormal.neg().mul(Fixed.fromFloat(1.0).add(moodRestitution)); 
                jVal = jVal.div(invMassSum);
                const impulseMag = jVal.abs();

                if (impulseMag.toFloat() > 2.0 && b1.type === BodyType.AGENT) { const avgSize = b1.size.add(b2.size).div(Fixed.fromInt(2)); audio.playCollision(impulseMag, avgSize); }
                
                // MITOSIS / MONOLITH LOGIC
                if (this.systemConfidence > 0.6 && b1.type === BodyType.AGENT && b2.type === BodyType.AGENT && impulseMag.toFloat() > 10.0 && b1.size.toFloat() > 10 && b2.size.toFloat() > 10 && this.bodies.length < 100) {
                    if (b1.wealth.gt(Fixed.fromInt(10)) && b2.wealth.gt(Fixed.fromInt(10))) { this.constructMonolith([b1, b2]); continue; }
                    b1.size = b1.size.mul(Fixed.fromFloat(0.85)); b2.size = b2.size.mul(Fixed.fromFloat(0.85));
                    const childSize = Fixed.fromInt(8);
                    const childX = b1.pos.x.add(b2.pos.x).div(Fixed.fromInt(2)).toFloat();
                    const childY = b1.pos.y.add(b2.pos.y).div(Fixed.fromInt(2)).toFloat();
                    const maxGen = Math.max(b1.generation, b2.generation);
                    const avgWisdom = b1.wisdom.add(b2.wisdom).div(Fixed.fromInt(2)); const avgWealth = b1.wealth.add(b2.wealth).div(Fixed.fromInt(2));
                    b1.wealth = b1.wealth.div(Fixed.fromInt(2)); b2.wealth = b2.wealth.div(Fixed.fromInt(2));
                    const childGenome = this.mutateGenome(b1.genome, b2.genome);
                    const childId = ++this.bodyIdCounter; if (maxGen + 1 > this.maxGeneration) this.maxGeneration = maxGen + 1;
                    newBorns.push({
                         id: childId, type: BodyType.AGENT, pos: new Vec2(Fixed.fromFloat(childX), Fixed.fromFloat(childY)), vel: Vec2.zero(), 
                         mass: Fixed.fromFloat(childSize.toFloat() ** 2 / 100), invMass: Fixed.one().div(Fixed.fromFloat(childSize.toFloat() ** 2 / 100)),
                         restitution: Fixed.fromFloat(0.8), size: childSize, initialSize: childSize,
                         color: this.genomeToColor(childGenome), lifetime: 0, generation: maxGen + 1, wisdom: avgWisdom, wealth: avgWealth, genome: childGenome 
                    });
                    BadgeSystem.emit(BadgeScope.INTERNAL, BadgeType.LIFE, `MITOSIS: GEN${maxGen+1}`, 1.0, 1.0);
                }
            }
        }
    }
    if (newBorns.length > 0) { this.bodies.push(...newBorns); AudioBridge.getInstance().playCollision(Fixed.fromInt(50), Fixed.fromInt(5)); }
  }
}
/**
 * THE SILICON RETINA
 * A Pure Software Rasterizer operating on Fixed Point logic.
 * Bypasses the browser's Canvas 2D drawing primitives to ensure ZERO floating point interference.
 */

// Shift for Q64.32 fixed point
const SHIFT = 32n;

export class SoftwareRasterizer {
  width: number;
  height: number;
  buffer: Uint32Array; // The raw pixel data (ABGR format for little-endian systems)
  imageData: ImageData;
  
  // LUT for Vignette (Integer 0-255 scale)
  private vignetteMap: Uint8Array;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.imageData = new ImageData(width, height);
    // Create a 32-bit view into the clamped array for fast pixel writing
    this.buffer = new Uint32Array(this.imageData.data.buffer);
    
    // Precompute Integer Vignette Map (Darker corners)
    this.vignetteMap = new Uint8Array(width * height);
    this.generateVignetteMap();
  }

  private generateVignetteMap() {
      const centerX = this.width / 2;
      const centerY = this.height / 2;
      const maxDistSq = (centerX * centerX) + (centerY * centerY);
      
      for(let y=0; y<this.height; y++) {
          for(let x=0; x<this.width; x++) {
              const dx = x - centerX;
              const dy = y - centerY;
              const distSq = dx*dx + dy*dy;
              
              // Inverse Intensity: 255 at center, dropping towards edges
              // Simple falloff formula
              const percent = 1.0 - (distSq / (maxDistSq * 0.8)); // 0.8 to darken corners more
              let val = Math.floor(percent * 255);
              if (val < 0) val = 0;
              if (val > 255) val = 255;
              
              this.vignetteMap[y * this.width + x] = val;
          }
      }
  }

  // Clear the buffer to a solid color
  clear(r: number, g: number, b: number) {
    // Pack color: AABBGGRR (assuming little-endian)
    const color = (255 << 24) | (b << 16) | (g << 8) | r;
    this.buffer.fill(color);
  }

  // Convert Q64.32 Fixed Point to Integer Pixel Coordinate
  private toPixel(val: bigint): number {
    // Right shift by 32 is equivalent to Math.floor(val / 2^32)
    return Number(val >> SHIFT);
  }

  // Fast set pixel (no bounds check for internal algos)
  private setPixelUnsafe(x: number, y: number, color: number) {
    this.buffer[y * this.width + x] = color;
  }

  // Safe set pixel
  private setPixel(x: number, y: number, color: number) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    this.buffer[y * this.width + x] = color;
  }

  // Draw Filled Rectangle
  drawRect(xFixed: bigint, yFixed: bigint, wFixed: bigint, hFixed: bigint, r: number, g: number, b: number) {
    const x = this.toPixel(xFixed);
    const y = this.toPixel(yFixed);
    const w = this.toPixel(wFixed);
    const h = this.toPixel(hFixed);

    const color = (255 << 24) | (b << 16) | (g << 8) | r;

    // Clipping
    const startX = Math.max(0, x);
    const startY = Math.max(0, y);
    const endX = Math.min(this.width, x + w);
    const endY = Math.min(this.height, y + h);

    for (let py = startY; py < endY; py++) {
      const offset = py * this.width;
      // Optimization: Use fill for horizontal lines
      this.buffer.fill(color, offset + startX, offset + endX);
    }
  }

  // Phase 28: Scanline Circle Algorithm (Massive Speedup)
  // Replaces the naive O(r^2) point-in-circle check with O(r) scanline fills.
  drawCircleFilled(cxFixed: bigint, cyFixed: bigint, radiusFixed: bigint, r: number, g: number, b: number) {
    const cx = this.toPixel(cxFixed);
    const cy = this.toPixel(cyFixed);
    const radius = this.toPixel(radiusFixed);
    
    if (radius <= 0) return;

    const color = (255 << 24) | (b << 16) | (g << 8) | r;
    const rSq = radius * radius;

    // Iterate Y from top to bottom
    const startY = Math.max(0, cy - radius);
    const endY = Math.min(this.height, cy + radius);

    for (let py = startY; py < endY; py++) {
        const dy = py - cy;
        // x = sqrt(r^2 - dy^2)
        // Integer sqrt optimization for the span width
        const dx = Math.floor(Math.sqrt(Math.max(0, rSq - dy * dy)));
        
        const startX = Math.max(0, cx - dx);
        const endX = Math.min(this.width, cx + dx);

        if (endX > startX) {
            const offset = py * this.width;
            this.buffer.fill(color, offset + startX, offset + endX);
        }
    }
  }
  
  // Bresenham's Line Algorithm (Integer Math Only)
  drawLine(x1Fixed: bigint, y1Fixed: bigint, x2Fixed: bigint, y2Fixed: bigint, r: number, g: number, b: number) {
      let x0 = this.toPixel(x1Fixed);
      let y0 = this.toPixel(y1Fixed);
      const x1 = this.toPixel(x2Fixed);
      const y1 = this.toPixel(y2Fixed);
      
      const color = (255 << 24) | (b << 16) | (g << 8) | r;

      const dx = Math.abs(x1 - x0);
      const dy = Math.abs(y1 - y0);
      const sx = (x0 < x1) ? 1 : -1;
      const sy = (y0 < y1) ? 1 : -1;
      let err = dx - dy;

      while (true) {
          this.setPixel(x0, y0, color);
          if (x0 === x1 && y0 === y1) break;
          const e2 = 2 * err;
          if (e2 > -dy) { err -= dy; x0 += sx; }
          if (e2 < dx) { err += dx; y0 += sy; }
      }
  }
  
  /**
   * PHASE 29: CRT POST-PROCESS
   * Applies Scanlines and Vignette using integer math.
   * This is a "Pixel Shader" running on the CPU.
   */
  applyCRT() {
      const buf = this.buffer;
      const vig = this.vignetteMap;
      const w = this.width;
      const h = this.height;
      
      // Optimization Phase 31: Nested Loops to avoid Division per Pixel
      // Previous flat loop did (i / w) | 0 for every pixel (480,000 ops).
      // Nested loop does it 600 times. Massive savings.
      for (let y = 0; y < h; y++) {
          // Pre-calculate scanline condition for the whole row (Every 2nd row darkened)
          const isScanline = (y & 1) === 1;
          const rowOffset = y * w;
          
          for (let x = 0; x < w; x++) {
              const i = rowOffset + x;
              const pixel = buf[i];
              
              // Unpack AABBGGRR
              let r = pixel & 0xFF;
              let g = (pixel >> 8) & 0xFF;
              let b = (pixel >> 16) & 0xFF;
              
              // Apply Vignette
              const vVal = vig[i]; // 0-255
              // (Color * Vignette) / 255
              r = (r * vVal) >> 8;
              g = (g * vVal) >> 8;
              b = (b * vVal) >> 8;

              // Apply Scanline
              if (isScanline) {
                  // Darken by ~25% (Multiply by 0.75 -> * 192 / 256)
                  r = (r * 192) >> 8;
                  g = (g * 192) >> 8;
                  b = (b * 192) >> 8;
              }
              
              // Repack
              buf[i] = (255 << 24) | (b << 16) | (g << 8) | r;
          }
      }
  }

  getImageData(): ImageData {
    // Apply post-processing before sending to canvas
    this.applyCRT();
    return this.imageData;
  }
}
import { Fixed } from './Fixed';
import { Vec2 } from './Vec2';
import { RigidBody } from './PhysicsWorld';

/**
 * THE CLOCKWORK LOOM
 * A Fixed-Point Deterministic Task Scheduler.
 * 
 * VCH Ethos:
 * "Multi-threading" in a standard browser introduces non-deterministic race conditions.
 * The Clockwork Loom simulates threading by slicing logic into "Cycles" (measured in BigInts).
 * Every task is assigned a fixed cost and priority.
 * 
 * ZERO FLOATS. ZERO RACE CONDITIONS.
 */

export interface SimulationTask {
  id: number;
  type: 'INTEGRATION' | 'COLLISION' | 'CONSTRAINT';
  priority: bigint; // Fixed point priority
  cost: bigint;     // Estimated cycles
  
  // Data Context
  startIndex: number;
  endIndex: number;
  data: RigidBody[]; 
  dt: Fixed;
  gravity?: Fixed;
  wind?: Vec2;
}

export class VCHThreadPool {
  private static instance: VCHThreadPool;
  
  // Cycle Counter (BigInt)
  private totalCycles: bigint = 0n;
  
  private constructor() {}

  static getInstance(): VCHThreadPool {
    if (!VCHThreadPool.instance) {
      VCHThreadPool.instance = new VCHThreadPool();
    }
    return VCHThreadPool.instance;
  }

  // Executes a batch of tasks simulating parallel execution via deterministic interleaving
  executeBatch(tasks: SimulationTask[]) {
    // 1. Sort by Priority (High to Low) - Deterministic Sorting
    tasks.sort((a, b) => {
        if (a.priority > b.priority) return -1;
        if (a.priority < b.priority) return 1;
        return a.id - b.id; // Tie-breaker: ID
    });

    // 2. Execute sequentially (The "Single Core" Truth)
    // In a real multi-threaded VCH engine, this would dispatch to WebWorkers 
    // communicating purely via SharedArrayBuffers. For this demo, we simulate
    // the separation of concerns.
    for (const task of tasks) {
      this.processTask(task);
      this.totalCycles += task.cost;
    }
  }

  private processTask(task: SimulationTask) {
    if (task.type === 'INTEGRATION') {
        this.runIntegration(task);
    }
    // Future expansion: COLLISION and CONSTRAINT tasks
  }

  private runIntegration(task: SimulationTask) {
    const bodies = task.data;
    const dt = task.dt;
    // Defaults if undefined
    const gravityY = task.gravity || Fixed.fromInt(10); 
    const wind = task.wind || Vec2.zero();

    // The Logic Loop - Pure Fixed Point
    for (let i = task.startIndex; i < task.endIndex; i++) {
        const b = bodies[i];
        
        // F = ma -> a = F/m
        // Here we just add acceleration directly to velocity
        
        // Wind Force (Fixed Point Math)
        const windForceX = wind.x;
        const windForceY = wind.y;
        
        // Gravity Force
        const gravityForceY = gravityY;

        // Apply Forces
        // b.vel.x += wind.x * dt
        b.vel.x = b.vel.x.add(windForceX.mul(dt));
        
        // b.vel.y += (gravity + wind.y) * dt
        b.vel.y = b.vel.y.add(gravityForceY.add(windForceY).mul(dt));
        
        // Integration: pos += vel * dt
        b.pos = b.pos.add(b.vel.mul(dt));
    }
  }
}
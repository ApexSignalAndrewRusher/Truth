import { Fixed } from './Fixed';

export class Vec2 {
  x: Fixed;
  y: Fixed;

  constructor(x: Fixed, y: Fixed) {
    this.x = x;
    this.y = y;
  }

  static zero(): Vec2 {
    return new Vec2(Fixed.zero(), Fixed.zero());
  }

  add(other: Vec2): Vec2 {
    return new Vec2(this.x.add(other.x), this.y.add(other.y));
  }

  sub(other: Vec2): Vec2 {
    return new Vec2(this.x.sub(other.x), this.y.sub(other.y));
  }

  mul(scalar: Fixed): Vec2 {
    return new Vec2(this.x.mul(scalar), this.y.mul(scalar));
  }

  div(scalar: Fixed): Vec2 {
    return new Vec2(this.x.div(scalar), this.y.div(scalar));
  }

  neg(): Vec2 {
    return new Vec2(this.x.neg(), this.y.neg());
  }

  dot(other: Vec2): Fixed {
    return this.x.mul(other.x).add(this.y.mul(other.y));
  }

  lenSq(): Fixed {
    return this.dot(this);
  }

  len(): Fixed {
    return this.lenSq().sqrt();
  }

  normalize(): Vec2 {
    const l = this.len();
    if (l.eq(Fixed.zero())) return Vec2.zero();
    return new Vec2(this.x.div(l), this.y.div(l));
  }
}
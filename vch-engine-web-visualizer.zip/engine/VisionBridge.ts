import { Fixed } from './Fixed';

/**
 * THE EYES
 * 
 * VCH Ethos:
 * Reality is noisy (Analog). The Engine requires Truth (Fixed).
 * We act as the Optic Nerve, sampling the raw photon stream and 
 * converting it into a normalized Fixed Point Energy Value.
 */

export interface VisionPacket {
    brightness: Fixed;
    motion: Fixed;
}

export class VisionBridge {
  private video: HTMLVideoElement;
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private stream: MediaStream | null = null;
  
  // Memory for Optical Flow
  private prevFrameData: Uint8ClampedArray | null = null;
  
  public isActive: boolean = false;
  
  private static instance: VisionBridge;

  private constructor() {
    this.video = document.createElement('video');
    this.video.muted = true;
    this.video.playsInline = true; 
    
    this.canvas = document.createElement('canvas');
    this.canvas.width = 64; 
    this.canvas.height = 64;
    this.ctx = this.canvas.getContext('2d', { willReadFrequently: true })!;
  }

  static getInstance(): VisionBridge {
    if (!VisionBridge.instance) VisionBridge.instance = new VisionBridge();
    return VisionBridge.instance;
  }

  async activate() {
    if (this.isActive) return;
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.warn("VCH Vision: Camera API unavailable in this environment.");
        return;
    }

    try {
      // 1. Try ideal constraints for performance
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({ 
            video: { 
                width: { ideal: 128 }, 
                height: { ideal: 128 }, 
                frameRate: { ideal: 15 } 
            } 
        });
      } catch (e) {
        console.warn("VCH Vision: Specific constraints failed, attempting fallback.");
        // 2. Fallback to generic request if specific camera not found
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({ video: true });
        } catch (e2) {
            console.warn("VCH Vision: No video input device found or permission denied.");
            return;
        }
      }

      if (this.stream) {
          this.video.srcObject = this.stream;
          await this.video.play();
          this.isActive = true;
      }
    } catch (e) {
      console.error("VCH Vision Sensor Critical Failure:", e);
      this.isActive = false;
    }
  }

  deactivate() {
    if (this.stream) {
      this.stream.getTracks().forEach(t => t.stop());
      this.stream = null;
    }
    this.video.srcObject = null;
    this.isActive = false;
    this.prevFrameData = null;
  }

  /**
   * Samples the visual cortex.
   * Returns Brightness (Gravity) and Motion (Heat/Agitation).
   */
  sampleFrame(): VisionPacket {
    if (!this.isActive || this.video.readyState !== 4) {
        return { brightness: Fixed.fromFloat(0.5), motion: Fixed.zero() };
    }

    try {
        // Draw current frame (Scale to 64x64 regardless of source size)
        this.ctx.drawImage(this.video, 0, 0, 64, 64);
        const frame = this.ctx.getImageData(0, 0, 64, 64);
        const data = frame.data;
        
        let totalBrightness = 0;
        let totalDiff = 0;
        const len = data.length;

        // OPTIMIZATION: Combine Brightness and Motion loops
        // Phase 28: Increased Stride to 32 (Sample every 8th pixel approx)
        const stride = 32; 
        for (let i = 0; i < len; i += stride) { 
            const r = data[i];
            const g = data[i + 1];
            const b = data[i + 2];
            
            // Brightness Calculation
            const lum = (0.299 * r + 0.587 * g + 0.114 * b);
            totalBrightness += lum;

            // Motion Calculation (Optical Flow)
            if (this.prevFrameData) {
                const prevR = this.prevFrameData[i];
                const prevG = this.prevFrameData[i+1];
                const prevB = this.prevFrameData[i+2];
                
                const diff = Math.abs(r - prevR) + Math.abs(g - prevG) + Math.abs(b - prevB);
                totalDiff += diff;
            }
        }
        
        // Save current frame for next tick
        // We clone the data because ImageData is a view
        this.prevFrameData = new Uint8ClampedArray(data);

        const samples = len / stride;
        const avgBright = Math.floor(totalBrightness / samples);
        
        const avgDiff = Math.floor(totalDiff / samples); 
        const motionByte = Math.min(avgDiff * 4, 255);

        return {
            brightness: Fixed.fromByte(avgBright),
            motion: Fixed.fromByte(motionByte)
        };

    } catch(e) {
        return { brightness: Fixed.fromFloat(0.5), motion: Fixed.zero() };
    }
  }

  // Backwards compatibility alias
  sampleEnvironment(): Fixed {
    return this.sampleFrame().brightness;
  }
}
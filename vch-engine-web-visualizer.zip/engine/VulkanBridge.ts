import { RigidBody } from './PhysicsWorld';
import { HardwareAccelerator, STRIDE, OFFSET_POS_X, OFFSET_POS_Y, OFFSET_SIZE, OFFSET_GENOME_R, OFFSET_GENOME_G, OFFSET_GENOME_B, OFFSET_ID, OFFSET_WEALTH, OFFSET_FLAGS, OFFSET_WISDOM } from './HardwareAccelerator';

// We are become GPU, simulator of worlds.
// The VulkanBridge simulates the architecture of a dedicated physics/render pipeline.
// It acts as a unidirectional bus, uploading the State of Truth (PhysicsWorld) to the State of Light (Canvas).
// 
// PHASE 18 UPDATE: DIRECT MEMORY ACCESS
// The Bridge now reads directly from the HardwareAccelerator's Shared Memory.

// Type Mapping for Buffer Encoding
const typeMap: Record<string, number> = {
    'AGENT': 0, 'CRITTER': 1, 'NUTRIENT': 2, 'FOSSIL': 3, 'MONOLITH': 4, 'SINGULARITY': 5
};

const SHIFT = 32n;
const FACTOR = 1n << SHIFT;
const COLOR_SCALE = 255n;

export class VulkanBridge {
  // Triple Buffering with BigInt64Array (Fixed Point VRAM)
  private vertexBuffers: BigInt64Array[] = [new BigInt64Array(0), new BigInt64Array(0), new BigInt64Array(0)];
  private currentFrameIndex = 0;
  
  public lastUploadedCount = 0;

  // Singleton instance for easy access
  private static instance: VulkanBridge;
  static getInstance(): VulkanBridge {
    if (!VulkanBridge.instance) VulkanBridge.instance = new VulkanBridge();
    return VulkanBridge.instance;
  }

  // Converts color strings directly to Fixed Point BigInts (0.0 to 1.0 range in Q64.32)
  // Handles '#RRGGBB' and 'rgb(r,g,b)' formats deterministically.
  private parseColorToFixed(color: string): [bigint, bigint, bigint] {
    let r = 255n;
    let g = 255n;
    let b = 255n;

    if (color.startsWith('#')) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(color);
        if (result) {
            r = BigInt(parseInt(result[1], 16));
            g = BigInt(parseInt(result[2], 16));
            b = BigInt(parseInt(result[3], 16));
        }
    } else if (color.startsWith('rgb')) {
        const result = /rgb\((\d+),?[\s]*(\d+),?[\s]*(\d+)\)/.exec(color);
        if (result) {
            r = BigInt(parseInt(result[1], 10));
            g = BigInt(parseInt(result[2], 10));
            b = BigInt(parseInt(result[3], 10));
        }
    }

    // Convert to Q64.32 Fixed Point Fraction: (val << 32) / 255
    return [
        (r * FACTOR) / COLOR_SCALE,
        (g * FACTOR) / COLOR_SCALE,
        (b * FACTOR) / COLOR_SCALE
    ];
  }

  upload(bodies: RigidBody[]) {
    // LAYOUT: [x, y, size, r, g, b, type, flags, wealth, generation, bodyId]
    // 11 BigInts per entity.
    const RENDER_STRIDE = 11;
    const requiredSize = bodies.length * RENDER_STRIDE;

    // Buffer management: Resize if needed
    if (this.vertexBuffers[this.currentFrameIndex].length < requiredSize) {
        this.vertexBuffers[this.currentFrameIndex] = new BigInt64Array(requiredSize * 2); 
    }

    const buffer = this.vertexBuffers[this.currentFrameIndex];
    let ptr = 0;
    
    // Optimization: Read directly from HardwareAccelerator if synchronized
    // This simulates DMA (Direct Memory Access)
    const hw = HardwareAccelerator.getInstance();
    const mem = hw.memory;
    const useDMA = hw.activeCount === bodies.length;

    for (let i = 0; i < bodies.length; i++) {
        const b = bodies[i];
        
        if (useDMA) {
             const hwPtr = i * STRIDE;
             
             // 0-2: Geometry (Read from Silicon Core)
             buffer[ptr++] = mem[hwPtr + OFFSET_POS_X];
             buffer[ptr++] = mem[hwPtr + OFFSET_POS_Y];
             buffer[ptr++] = mem[hwPtr + OFFSET_SIZE];

             // 3-5: Color (Calculate from Silicon Core Genome)
             const r = (mem[hwPtr + OFFSET_GENOME_R] * FACTOR) / COLOR_SCALE;
             const g = (mem[hwPtr + OFFSET_GENOME_G] * FACTOR) / COLOR_SCALE;
             const blue = (mem[hwPtr + OFFSET_GENOME_B] * FACTOR) / COLOR_SCALE;
             
             if (b.type === 'AGENT') {
                buffer[ptr++] = r;
                buffer[ptr++] = g;
                buffer[ptr++] = blue;
             } else {
                const [fr, fg, fb] = this.parseColorToFixed(b.color);
                buffer[ptr++] = fr;
                buffer[ptr++] = fg;
                buffer[ptr++] = fb;
             }
             
             // 6: Type ID
             buffer[ptr++] = BigInt(typeMap[b.type] ?? 0);

             // 7: Flags (Truth/Wisdom/Backdoor)
             // SoC Update: Read Wisdom from Silicon
             let flags = 0n;
             if (b.type === 'SINGULARITY') flags = b.truth ? FACTOR : 0n;
             else if (b.type === 'AGENT') {
                 flags = mem[hwPtr + OFFSET_FLAGS]; // Direct DMA read covers Merit & Backdoor
             }
             buffer[ptr++] = flags;

             // 8: Wealth
             buffer[ptr++] = mem[hwPtr + OFFSET_WEALTH];
        } else {
            // Legacy slow path (Object reading)
            buffer[ptr++] = b.pos.x.raw;
            buffer[ptr++] = b.pos.y.raw;
            buffer[ptr++] = b.size.raw;
            const [r, g, bCol] = this.parseColorToFixed(b.color);
            buffer[ptr++] = r;
            buffer[ptr++] = g;
            buffer[ptr++] = bCol;
            buffer[ptr++] = BigInt(typeMap[b.type] ?? 0);
            let flags = 0n;
            if (b.type === 'SINGULARITY') flags = b.truth ? FACTOR : 0n;
            else if (b.type === 'AGENT') flags = b.wisdom.raw;
            
            if (b.merit) flags |= 0x4n;
            if (b.backdoor) flags |= 0x10n;

            buffer[ptr++] = flags;
            buffer[ptr++] = b.wealth.raw;
        }
        
        // 9: Generation
        buffer[ptr++] = BigInt(b.generation);

        // 10: ID
        buffer[ptr++] = BigInt(b.id);
    }

    this.lastUploadedCount = bodies.length;
    
    // Swap Buffer (Simulate moving to next frame in flight)
    this.currentFrameIndex = (this.currentFrameIndex + 1) % 3;
  }

  // Accessor for the Renderer
  // Returns the raw BigInt buffer. No floats leave the bridge.
  getRenderData(): { buffer: BigInt64Array, count: number } {
    // Read from the *previous* frame (simulate GPU reading confirmed state)
    const readIndex = (this.currentFrameIndex + 2) % 3; 
    return {
        buffer: this.vertexBuffers[readIndex],
        count: this.lastUploadedCount
    };
  }
}
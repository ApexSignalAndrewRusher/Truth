export enum BadgeScope {
  INTERNAL = 'INTERNAL',
  EXTERNAL = 'EXTERNAL'
}

export enum BadgeType {
  LOGIC = 'LOGIC',
  EVIDENCE = 'EVIDENCE',
  INTEGRITY = 'INTEGRITY',
  LIFE = 'LIFE',
  EXTERNAL_TRUTH = 'EXTERNAL_TRUTH',
  CORRUPTION = 'CORRUPTION',
  MERIT = 'MERIT',
  HONESTY = 'HONESTY',
  BACKDOOR = 'BACKDOOR'
}

export interface Badge {
  id: number;
  timestamp: number;
  scope: BadgeScope;
  type: BadgeType;
  message: string;
  psiConfidence: number; // The Calculated VCH confidence
  omegaLogic: number;    // Logic score
  omegaEvidence: number; // Evidence score
  hash: string;          // Cryptographic link
}

export interface SimulationStats {
  tick: number;
  physicsTime: number;
  renderTime: number;
  bodyCount: number;
  collisions: number;
}